"""Read-only, buffered R3 snapshots of the published network state."""
from __future__ import annotations
import csv
import hashlib
import json
import math
import re
import subprocess
from collections.abc import Mapping
from pathlib import Path

FORMAT_VERSION = "r3-cluster-snapshot-v1"
CLUSTER_FIELDS = ("seed", "time_us", "time_s", "epoch", "cluster_id", "ch_id", "member_ids", "member_count")
NODE_FIELDS = ("seed", "time_us", "time_s", "epoch", "node_id", "cluster_id", "ch_id", "cluster_role", "is_backbone_connector")


def _primitive(value):
    """Copy into JSON primitives, with no retained simulation object references."""
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if hasattr(value, "identifier"):
        return _primitive(value.identifier)
    if isinstance(value, Mapping):
        copied = {}
        for key, item in value.items():
            primitive_key = _primitive(key)
            if isinstance(primitive_key, (dict, list)):
                raise TypeError("mapping keys must convert to scalar JSON values")
            encoded_key = str(primitive_key)
            if encoded_key in copied:
                raise ValueError("mapping keys collide after JSON string encoding")
            copied[encoded_key] = _primitive(item)
        return copied
    if isinstance(value, (set, frozenset)):
        copied = [_primitive(item) for item in value]
        return sorted(copied, key=lambda item: json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=False))
    if isinstance(value, (tuple, list)):
        return [_primitive(item) for item in value]
    raise TypeError("unsupported snapshot value type: {}".format(type(value).__name__))


def _identifier(value):
    return None if value is None else _primitive(getattr(value, "identifier", value))


def _stable_id_key(value):
    return (type(value).__name__, json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False))


def _config_file_info():
    config = __import__("utils.config", fromlist=["__file__"])
    path = Path(config.__file__).resolve()
    try:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        digest = "unavailable"
    return {"path": str(path), "sha256": digest}


def _git_commit(repo_root):
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=str(repo_root), check=True,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=5,
        )
        return result.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return "unknown"


class ClusterSnapshotLogger:
    """Accumulates detached primitive rows and exports once after simulation."""
    def __init__(self, simulator):
        self.simulator = simulator
        self.cluster_rows = []
        self.node_rows = []
        self.backbone_rows = []
        self.record_error_count = 0
        self.record_errors = []

    def record_completed_snapshot(self, cluster_manager):
        """Read finalized state; perform no simulation action."""
        try:
            time_us = _primitive(self.simulator.env.now)
            time_s = float(time_us) / 1e6
            seed = _primitive(getattr(self.simulator, "seed", None))
            epoch = int(cluster_manager.round_counter)
            drones = tuple(cluster_manager.active_drones())
            head_by_id = {}
            for drone in drones:
                if getattr(drone, "cluster_role", None) == "CH":
                    head_by_id[_identifier(drone)] = drone

            cluster_rows = []
            for ch_id in sorted(head_by_id, key=_stable_id_key):
                head = head_by_id[ch_id]
                raw_members = tuple(getattr(head, "cluster_members", ()) or ())
                member_ids = [_identifier(member) for member in raw_members]
                if ch_id not in member_ids:
                    member_ids.append(ch_id)
                member_ids = sorted(set(member_ids), key=_stable_id_key)
                cluster_rows.append({
                    "seed": seed, "time_us": time_us, "time_s": time_s, "epoch": epoch,
                    "cluster_id": _primitive(getattr(head, "cluster_id", None)),
                    "ch_id": ch_id,
                    "member_ids": json.dumps(member_ids, ensure_ascii=False, separators=(",", ":")),
                    "member_count": len(member_ids),
                })

            node_rows = []
            for drone in drones:
                node_rows.append({
                    "seed": seed, "time_us": time_us, "time_s": time_s, "epoch": epoch,
                    "node_id": _identifier(drone),
                    "cluster_id": _primitive(getattr(drone, "cluster_id", None)),
                    "ch_id": _identifier(getattr(drone, "cluster_head", None)),
                    "cluster_role": _primitive(getattr(drone, "cluster_role", None)),
                    "is_backbone_connector": bool(getattr(drone, "is_backbone_connector", False)),
                })

            snapshot = cluster_manager.backbone_planner.active_snapshot
            backbone_row = {
                "seed": seed, "time_us": time_us, "time_s": time_s, "epoch": epoch,
                "cluster_heads": _primitive(snapshot.cluster_heads),
                "backbone_relays": _primitive(snapshot.backbone_relays),
                "cluster_membership": _primitive(snapshot.cluster_membership),
                "paths_to_bs": _primitive(snapshot.paths_to_bs),
                "routes": _primitive(snapshot.routes),
            }
            # Append only detached rows after the whole snapshot converts.
            self.cluster_rows.extend(cluster_rows)
            self.node_rows.extend(node_rows)
            self.backbone_rows.append(backbone_row)
        except Exception as error:
            self.record_error_count += 1
            if len(self.record_errors) < 20:
                self.record_errors.append({
                    "epoch": getattr(cluster_manager, "round_counter", None),
                    "error_type": type(error).__name__, "message": str(error),
                })

    @staticmethod
    def output_path(output_dir, experiment_name):
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(experiment_name)).strip("._") or "run"
        return Path(output_dir) / "cluster_snapshot_logs" / safe_name

    @classmethod
    def ensure_output_available(cls, output_dir, experiment_name):
        target = cls.output_path(output_dir, experiment_name)
        if target.exists():
            raise FileExistsError("R3 snapshot output already exists: {}".format(target))
        return target

    @staticmethod
    def _write_csv(path, fields, rows):
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)

    def export(self, output_dir, experiment_name, duration_us, cluster_interval_us,
               snapshot_source_available=True):
        target = self.ensure_output_available(output_dir, experiment_name)
        target.mkdir(parents=True, exist_ok=False)
        output_files = ["run_manifest.json"]
        if snapshot_source_available:
            self._write_csv(target / "cluster_snapshots.csv", CLUSTER_FIELDS, self.cluster_rows)
            self._write_csv(target / "node_roles.csv", NODE_FIELDS, self.node_rows)
            with (target / "backbone_snapshots.jsonl").open("w", encoding="utf-8", newline="\n") as stream:
                for row in self.backbone_rows:
                    stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
                    stream.write("\n")
            output_files = [
                "cluster_snapshots.csv", "node_roles.csv",
                "backbone_snapshots.jsonl", "run_manifest.json",
            ]

        simulator = self.simulator
        config = __import__("utils.config", fromlist=["ROUTING_PROTOCOL"])
        repo_root = Path(__file__).resolve().parents[2]
        experiment_config = {
            "routing_protocol": _primitive(getattr(config, "ROUTING_PROTOCOL", None)),
            "cluster_algorithm": _primitive(getattr(config, "CLUSTER_ALGORITHM", None)),
            "predictor_mode": _primitive(getattr(config, "PREDICTOR_MODE", None)),
            "mobility_trace_mode": _primitive(getattr(config, "MOBILITY_TRACE_MODE", None)),
            "mobility_trace_file": _primitive(getattr(config, "MOBILITY_TRACE_FILE", None)),
            "data_packet_rate": _primitive(getattr(config, "DATA_PACKET_RATE", None)),
            "communication_range": _primitive(getattr(config, "COMMUNICATION_RANGE", None)),
        }
        manifest = {
            "schema_version": FORMAT_VERSION,
            "format_version": FORMAT_VERSION,
            "git_commit": _git_commit(repo_root),
            "seed": _primitive(getattr(simulator, "seed", None)),
            "N_UAV": int(getattr(simulator, "n_drones", len(simulator.drones))),
            "N_UAV_includes_base_station": True,
            "active_uav_count": sum(not getattr(drone, "is_base_station", False)
                                    for drone in simulator.drones),
            "simulator_node_count": len(simulator.drones),
            "simulation_duration": {
                "value": float(duration_us) / 1e6,
                "unit": "s",
                "time_us": _primitive(duration_us),
            },
            "simulation_duration_us": _primitive(duration_us),
            "simulation_duration_s": float(duration_us) / 1e6,
            "cluster_interval": {
                "value": float(cluster_interval_us) / 1e6,
                "unit": "s",
                "time_us": _primitive(cluster_interval_us),
            },
            "cluster_interval_us": _primitive(cluster_interval_us),
            "config_file_info": _config_file_info(),
            "experiment_config": experiment_config,
            "effective_configuration": experiment_config,
            "logging_enabled": True,
            "logger_enabled": True,
            "snapshot_source_available": bool(snapshot_source_available),
            "service_uav_definition": "undefined",
            "output_files": output_files,
            "record_error_count": self.record_error_count,
            "record_errors_sample": self.record_errors,
            "snapshot_count": len(self.backbone_rows) if snapshot_source_available else 0,
        }
        with (target / "run_manifest.json").open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(manifest, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
        return target

