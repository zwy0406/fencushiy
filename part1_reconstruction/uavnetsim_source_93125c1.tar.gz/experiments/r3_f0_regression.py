"""Behavioral F0 regression for R3 read-only snapshot logging.

Runs each historical F0 method/seed in isolated output folders and compares the
original metrics artifacts. The added R3 files live beside (not inside) metrics.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
import filecmp
import json
import subprocess
import sys
from pathlib import Path

from openpyxl import load_workbook


METHODS = {
    "dsdv": ("DSDV", "DSDV", False),
    "mobic": ("DSDV", "MOBIC", True),
    "original_mwmp": ("DSDV", "ORIGINAL_MWMP", True),
    "torp_like": ("TORP_LIKE", "TORP_LIKE", False),
    "proposed": ("DSDV", "PROPOSED", True),
}
SEEDS = tuple(range(2030, 2040))


def _xlsx_cells(path):
    workbook = load_workbook(path, read_only=True, data_only=False)
    try:
        return [(sheet.title, list(sheet.values)) for sheet in workbook.worksheets]
    finally:
        workbook.close()


def compare_metrics(method, seed, output, f0_root):
    name = f"matrix_{method}_seed{seed}"
    expected = f0_root / method / f"seed{seed}" / "metrics"
    actual = output / "metrics"
    if not expected.is_dir() or not actual.is_dir():
        raise RuntimeError(f"missing metrics: {expected} or {actual}")
    expected_files = {p.name for p in expected.iterdir() if p.is_file()}
    actual_files = {p.name for p in actual.iterdir() if p.is_file()}
    if expected_files != actual_files:
        raise RuntimeError(
            f"metrics file set differs for {method}/seed{seed}: "
            f"missing={sorted(expected_files-actual_files)}, extra={sorted(actual_files-expected_files)}"
        )
    for filename in sorted(expected_files):
        old, new = expected / filename, actual / filename
        if filename.endswith(".xlsx"):
            if _xlsx_cells(old) != _xlsx_cells(new):
                raise RuntimeError(f"XLSX cells differ: {method}/seed{seed}/{filename}")
        elif not filecmp.cmp(old, new, shallow=False):
            raise RuntimeError(f"artifact bytes differ: {method}/seed{seed}/{filename}")

    packet_file = "packet_outcomes.csv"
    if packet_file not in expected_files:
        raise RuntimeError(f"historical packet ledger missing: {expected}/{packet_file}")
    with (expected / packet_file).open(encoding="utf-8", newline="") as stream:
        old_packets = list(csv.DictReader(stream))
    with (actual / packet_file).open(encoding="utf-8", newline="") as stream:
        new_packets = list(csv.DictReader(stream))
    old_sequence = [(row["packet_id"], row["creation_time"]) for row in old_packets]
    new_sequence = [(row["packet_id"], row["creation_time"]) for row in new_packets]
    if old_sequence != new_sequence:
        raise RuntimeError(f"packet ID/generation-time sequence differs: {method}/seed{seed}")

    r3_dir = output / "cluster_snapshot_logs" / name
    manifest_path = r3_dir / "run_manifest.json"
    if not manifest_path.is_file():
        raise RuntimeError(f"missing run manifest: {method}/seed{seed}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expects_snapshots = METHODS[method][2]
    if bool(manifest["snapshot_source_available"]) != expects_snapshots:
        raise RuntimeError(f"snapshot source availability mismatch: {method}/seed{seed}")
    if expects_snapshots:
        for filename in ("cluster_snapshots.csv", "node_roles.csv", "backbone_snapshots.jsonl"):
            if not (r3_dir / filename).is_file():
                raise RuntimeError(f"missing R3 artifact: {method}/seed{seed}/{filename}")
        if manifest["record_error_count"] != 0 or manifest["snapshot_count"] <= 0:
            raise RuntimeError(f"R3 recording errors or empty snapshots: {method}/seed{seed}")
        with (r3_dir / "backbone_snapshots.jsonl").open(encoding="utf-8") as stream:
            lines = [json.loads(line) for line in stream if line.strip()]
        if len(lines) != manifest["snapshot_count"]:
            raise RuntimeError(f"backbone count mismatch: {method}/seed{seed}")
        with (r3_dir / "cluster_snapshots.csv").open(encoding="utf-8", newline="") as stream:
            clusters = list(csv.DictReader(stream))
        with (r3_dir / "node_roles.csv").open(encoding="utf-8", newline="") as stream:
            nodes = list(csv.DictReader(stream))
        for row in clusters:
            members = json.loads(row["member_ids"])
            if int(row["ch_id"]) not in members or int(row["member_count"]) != len(members):
                raise RuntimeError(f"cluster membership invariant failed: {method}/seed{seed}")
        if len(nodes) != manifest["snapshot_count"] * manifest["active_uav_count"]:
            raise RuntimeError(f"node-role row count mismatch: {method}/seed{seed}")

    return {
        "method": method, "seed": seed, "metrics_files_exact": len(expected_files),
        "packet_records": len(old_packets), "packet_id_and_generation_times_equal": True,
        "xlsx_cells_equal": True, "r3_snapshot_source_available": expects_snapshots,
        "r3_snapshot_count": manifest["snapshot_count"],
        "r3_record_error_count": manifest.get("record_error_count", 0),
    }


def run_one(method, seed, repo_root, f0_root, output_root):
    protocol, method_arg, _ = METHODS[method]
    output = output_root / method / f"seed{seed}"
    name = f"matrix_{method}_seed{seed}"
    trace = f0_root / "mobility_traces" / f"seed{seed}_n80_v15.json"
    if not trace.is_file():
        raise RuntimeError(f"historical trace absent: {trace}")

    if output.exists():
        if not (output / "metrics").is_dir():
            raise RuntimeError(f"partial output preserved for inspection: {output}")
        return compare_metrics(method, seed, output, f0_root)

    output.mkdir(parents=True)
    command = [
        sys.executable, "-m", "experiments.run_experiment",
        "--protocol", protocol, "--method", method_arg, "--packet-diagnostics",
        "--cluster-snapshot-logging", "--seed", str(seed), "--n-drones", "80",
        "--output-dir", str(output), "--speed", "15", "--experiment-name", name,
        "--predictor-mode", "kinematic", "--traffic-rate", "2",
        "--comm-range", "250", "--sim-time-s", "300",
        "--mobility-trace-mode", "replay", "--mobility-trace-file", str(trace),
    ]
    log = output / "regression.log"
    with log.open("w", encoding="utf-8") as stream:
        completed = subprocess.run(
            command, cwd=str(repo_root), stdout=stream, stderr=subprocess.STDOUT,
        )
    if completed.returncode:
        raise RuntimeError(
            f"run failed ({completed.returncode}) for {method}/seed{seed}; "
            f"preserved log: {log}"
        )
    return compare_metrics(method, seed, output, f0_root)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--f0-root", type=Path, default=None)
    parser.add_argument("--output-root", type=Path, default=None)
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    repo_root = args.repo_root.resolve()
    f0_root = (args.f0_root or repo_root / "results/f0_formal_a3_seeds2030_2039_20261005").resolve()
    output_root = (args.output_root or repo_root / "results/r3_f0_logging_seeds2030_2039_20261105").resolve()
    tasks = [(method, seed) for seed in SEEDS for method in METHODS]

    for method, seed in tasks:
        reference = f0_root / method / f"seed{seed}" / "metrics"
        trace = f0_root / "mobility_traces" / f"seed{seed}_n80_v15.json"
        if not reference.is_dir() or not trace.is_file():
            raise RuntimeError(f"preflight missing F0 data: {method}/seed{seed}")
    print(f"preflight OK: {len(tasks)} F0 method-seed pairs; output={output_root}")
    if args.preflight:
        return

    output_root.mkdir(parents=True, exist_ok=True)
    progress_path = output_root / "r3_f0_regression_progress.json"
    completed = []
    for seed in SEEDS:
        futures = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for method in METHODS:
                future = pool.submit(run_one, method, seed, repo_root, f0_root, output_root)
                futures[future] = method
            failures = []
            for future in concurrent.futures.as_completed(futures):
                try:
                    completed.append(future.result())
                    print(f"PASS seed{seed} {futures[future]}", flush=True)
                except Exception as error:
                    failures.append((futures[future], repr(error)))
                    print(f"FAIL seed{seed} {futures[future]}: {error}", flush=True)
        progress_path.write_text(json.dumps(completed, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        if failures:
            raise RuntimeError(f"seed{seed} failed; no later seed launched: {failures}")

    report = {
        "result": "PASS" if len(completed) == len(tasks) else "INCOMPLETE",
        "completed_pairs": len(completed), "expected_pairs": len(tasks),
        "seeds": list(SEEDS), "methods": list(METHODS),
        "sim_time_s": 300, "n_drones_including_bs": 80,
        "mobility_trace": "historical F0 replay",
        "metrics_comparison": "CSV/other files byte-identical; XLSX cell-identical",
        "packet_sequence": "packet_id and creation_time identical",
        "event_count_comparison": "unavailable; simulator exposes no reliable event counter",
        "pairs": completed,
    }
    (output_root / "r3_f0_regression_report.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8",
    )
    print(json.dumps({k: report[k] for k in ("result", "completed_pairs", "expected_pairs")}, sort_keys=True))


if __name__ == "__main__":
    main()

