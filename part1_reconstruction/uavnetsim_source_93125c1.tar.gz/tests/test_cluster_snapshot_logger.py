import csv
import json
import tempfile
import unittest
from pathlib import Path
from types import MappingProxyType, SimpleNamespace

from topology.mwmp_dca.cluster_snapshot_logger import ClusterSnapshotLogger


class ClusterSnapshotLoggerTests(unittest.TestCase):
    def make_fixture(self):
        env = SimpleNamespace(now=2_000_000)
        ch = SimpleNamespace(
            identifier=4, cluster_id=4, cluster_role="CH",
            cluster_head=None, cluster_members=[],
            is_backbone_connector=False,
        )
        cm = SimpleNamespace(
            identifier=9, cluster_id=4, cluster_role="CM",
            cluster_head=ch, cluster_members=[],
            is_backbone_connector=True,
        )
        # CH appears in the actual member list for this fixture.
        ch.cluster_members.extend([ch, cm])
        snapshot = SimpleNamespace(
            cluster_heads=frozenset({4}),
            backbone_relays=frozenset({9}),
            cluster_membership=MappingProxyType({4: (4, 9)}),
            paths_to_bs=MappingProxyType({4: (4, 9, 0)}),
            routes=MappingProxyType({
                4: MappingProxyType({0: 9}),
                9: MappingProxyType({0: 0}),
            }),
        )
        manager = SimpleNamespace(
            round_counter=2,
            active_drones=lambda: [ch, cm],
            backbone_planner=SimpleNamespace(active_snapshot=snapshot),
        )
        simulator = SimpleNamespace(env=env, seed=17, drones=[ch, cm])
        return simulator, manager, ch, cm

    def test_records_detached_rows_and_ch_in_member_list(self):
        simulator, manager, ch, cm = self.make_fixture()
        logger = ClusterSnapshotLogger(simulator)
        original_members = list(ch.cluster_members)
        logger.record_completed_snapshot(manager)

        self.assertEqual(ch.cluster_members, original_members)
        self.assertEqual(logger.cluster_rows[0]["member_ids"], "[4,9]")
        self.assertEqual(logger.cluster_rows[0]["member_count"], 2)
        self.assertEqual(logger.node_rows[1]["ch_id"], 4)
        self.assertTrue(logger.node_rows[1]["is_backbone_connector"])
        self.assertEqual(logger.backbone_rows[0]["routes"], {"4": {"0": 9}, "9": {"0": 0}})
        self.assertEqual(logger.backbone_rows[0]["paths_to_bs"], {"4": [4, 9, 0]})

        # Subsequent simulation mutation cannot change buffered records.
        ch.cluster_members.clear()
        self.assertEqual(logger.cluster_rows[0]["member_ids"], "[4,9]")
        self.assertEqual(logger.backbone_rows[0]["routes"], {"4": {"0": 9}, "9": {"0": 0}})
        self.assertEqual(logger.record_error_count, 0)

    def test_export_writes_required_schema_and_manifest(self):
        simulator, manager, _, _ = self.make_fixture()
        logger = ClusterSnapshotLogger(simulator)
        logger.record_completed_snapshot(manager)
        with tempfile.TemporaryDirectory() as tmp:
            out = logger.export(tmp, "unit-seed17", 5_000_000, 1_000_000)
            self.assertEqual(Path(out).name, "unit-seed17")
            with (Path(out) / "cluster_snapshots.csv").open(encoding="utf-8", newline="") as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(rows[0]["time_us"], "2000000")
            self.assertEqual(rows[0]["time_s"], "2.0")
            self.assertEqual(json.loads(rows[0]["member_ids"]), [4, 9])
            with (Path(out) / "node_roles.csv").open(encoding="utf-8", newline="") as f:
                node_rows = list(csv.DictReader(f))
            self.assertEqual(len(node_rows), 2)
            with (Path(out) / "backbone_snapshots.jsonl").open(encoding="utf-8") as f:
                backbone = json.loads(f.readline())
            self.assertEqual(backbone["cluster_membership"], {"4": [4, 9]})
            manifest = json.loads((Path(out) / "run_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["seed"], 17)
            self.assertEqual(manifest["N_UAV"], 2)
            self.assertEqual(manifest["service_uav_definition"], "undefined")
            self.assertEqual(manifest["snapshot_count"], 1)
            self.assertEqual(manifest["schema_version"], "r3-cluster-snapshot-v1")
            self.assertTrue(manifest["logging_enabled"])
            self.assertEqual(manifest["simulation_duration"]["value"], 5.0)
            self.assertEqual(manifest["simulation_duration"]["unit"], "s")
            self.assertEqual(manifest["cluster_interval"]["time_us"], 1_000_000)
            self.assertEqual(manifest["experiment_config"], manifest["effective_configuration"])

    def test_ch_is_inserted_in_copy_if_source_list_omits_it(self):
        simulator, manager, ch, _ = self.make_fixture()
        ch.cluster_members[:] = [manager.active_drones()[1]]
        logger = ClusterSnapshotLogger(simulator)
        logger.record_completed_snapshot(manager)
        self.assertEqual(logger.cluster_rows[0]["member_ids"], "[4,9]")
        self.assertEqual(ch.cluster_members, [manager.active_drones()[1]])


if __name__ == "__main__":
    unittest.main()

