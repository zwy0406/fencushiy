# TAE-MWMP-DCA 正式冻结与实施计划

> 状态：Frozen
> 执行环境：服务器 Conda 环境 `fc`
> 定位：Hierarchical Hybrid Networking

## 1. 架构与边界

分簇由 UAV 基于局部邻居状态分布式选举；骨干路径由 BS-assisted planner 统一计算。第一部分正式评分仅保留 E、Q、D、TLET、Mrel。GAT、GA、PoI-aware score 不进入主体。Kinematic predictor 为默认预测器；LSTM 是否进入扩展实验只由 E8 决定。

链路质量：
[
Q_{ij}=clip((\gamma_{ij}-6)/(30-6),0,1).
]
6 dB 是当前 2-Mbps IEEE 802.11b 解码门限；30 dB 是固定归一化饱和值 `gamma_sat`，不是网络最大 SNR，正式实验不得动态修改。

相对移动性：
[
m_{ij}^{pred}=clip(|\hat d_{ij}(t+T_p)-d_{ij}(t)|/R_{data},0,1),
\quad M_i^{rel}=|\mathcal N_i|^{-1}\sum_jm_{ij}^{pred}.
]

CH 评分与 Service Guard：
[
S_i^{net}=w_EE_i+w_QQ_i+w_DD_i+w_TT_i+w_M(1-M_i^{rel}),\quad \sum_kw_k=1,
]
[
U_i^{CH}=(1-\alpha_S)S_i^{net}+\alpha_S(1-B_i^{svc}).
]
Service Guard 使用 `alpha_S`；骨干 burden 使用 `lambda_B`，二者不得混用。CH rotation 常规条件仅为 score margin 与 persistence；紧急条件仅为总电池低于 25% 或 TLET 低于安全比例。

## 2. ETX 期望通信能耗

每条有向边保存最近 20 个完成的 data+ACK 单播事务。ACK 到达记成功，ACK timeout 记失败，每次重传是独立尝试。统计超过 5 s 未更新即失效。
[
\hat p_{ij}^{succ}=(n_{succ}+1)/(n_{attempt}+2).
]
无样本时为 0.5：
[
ETX_{ij}=\min(5,1/\max(\hat p_{ij}^{succ},10^{-6})),
]
[
E_{ij}^{exp}=ETX_{ij}E_{ref}^{comm},\qquad \widetilde E_{ij}^{comm}=ETX_{ij}/5.
]
Q 表示当前物理质量；ETX 表示历史事务可靠性，包括干扰、碰撞和 ACK 丢失。二者独立且不得互相替代。

## 3. 固定参考量

Application payload 为 1024 Bytes。加入当前 UavNetSim 的 IP、MAC、PHY header 后，on-air data frame 为：
[
8192+160+112+192=8656\ bit.
]
ACK 长度 240 bit 是当前 UavNetSim 配置，不表述为 IEEE 802.11b 标准固定长度。在 `P_tx=P_rx=0.1 W`、`R_b=2 Mbps` 下：
[
E_{ref}^{comm}=(P_{tx}+P_{rx})(8656+240)/(2\times10^6)=0.8896\ mJ.
]
时延归一化为 (widetilde D_{ij}=\min(1,D_{ij}/0.5s))。D 是队列等待、MAC 接入、序列化和 ACK 时间的 EWMA；无历史时使用解析 MAC 基线。

## 4. 能耗架构

UAV 只有一个真实电池：
[
E_i^{bat}=E_i^0-E_i^{prop}-E_i^{data}-E_i^{ctrl}.
]
`residual_energy` 保持总电池含义，用于 CH/BR 资格、评分和 25% 紧急门限。每个 Drone 维护 `propulsion_energy`、`communication_energy`、`data_energy`、`control_energy`、`tx_energy`、`rx_energy`、`relay_role_energy`。

第一部分评价对象：
[
E_i^{net}=E_i^{data}+E_i^{ctrl}=E_i^{tx}+E_i^{rx},\qquad E_{pkt}=\sum_iE_i^{net}/N_{delivered}.
]
`N_delivered=0` 时输出 NaN，并将 run 标记无效。`relay_role_energy` 包含转发非本机源数据的 TX/RX/ACK，以及担任 CH/BR 时的分簇与骨干控制能耗。角色公平性：
[
J_{relay,E}=(\sum_iE_{i,relay})^2/(M\sum_iE_{i,relay}^2).
]
25% 门限仅是安全触发器；节能结论主要由 E_pkt、data/control energy 和 J_relay,E 支撑。

## 5. 实现接口

固定配置：`RECEIVING_POWER=0.1`、`LINK_SUCCESS_WINDOW=20`、`LINK_STATS_STALE=5e6`、`LINK_SUCCESS_EPSILON=1e-6`、`ENERGY_DELAY_REF=0.5`、`ALLOW_MODEL_FALLBACK=False`。

`consume_energy` 必须显式提供 `source=propulsion|data|control`、`direction=tx|rx|None` 和 `role_energy`，不设分类默认值。PHY 每次发送尝试扣 TX；预定单播接收端进入 reception 后扣一次 RX，无论解码是否成功。广播/组播只对实际进入对应信道 reception 的节点扣 RX；第一版不计普通旁听节点。使用 `(packet_id, transmission_attempt, receiver_id)` 去重。ACK 按关联数据包计入 data；分簇、路由和骨干报文计入 control。

共享 `LinkReliabilityTracker` 由 MAC 在尝试、ACK 成功和 timeout 时更新；Backbone Planner 只读统计快照。

## 6. 骨干与 Relay Hold

骨干逻辑拆入独立 BS-assisted planner，在 CH、候选 BR 与 BS 的有向图上执行 Weighted Dijkstra：
[
c_{ij}=\lambda_E\widetilde E_{ij}^{comm}+\lambda_Q(1-Q_{ij})+\lambda_T(1-T_{ij})+\lambda_BB_j^{svc}+\lambda_D\widetilde D_{ij}.
]
Relay Hold 保留短期 persistence，并在电池不足、TLET 过低、burden 超限或失去骨干/BS 连接时提前释放。

## 7. 实验与统计

正式主矩阵固定为 DSDV、MOBIC、Original MWMP-DCA、TORP-like、Proposed。TDC-MOPSO/MDCS 仅作历史诊断。

- 核心：E1、E2、E3、E7、E8、E10。
- 第二优先级：E4、E5、E6。
- E9 在算法完全冻结后执行。
- E11 是大论文最终必做的跨章节验证，但不阻塞当前 P1-P10。
- E8 保留 Current-only、Kinematic-TLET、Oracle-TLET，据此决定 LSTM 资格。
- 每个矩阵先跑 3 个 paired seeds，再跑 10 个正式 paired seeds。
- 普通指标报告 mean ± SD；Delta PDR、Delta E_pkt、Delta R_BS 使用 paired-seed Student-t 95% CI。

正式实验禁止模型、算法和参数静默 fallback。E0 只校验参数分布和饱和比例；正式实验开始后不得静默改参。

## 8. 验证门槛

单测覆盖 ACK 滑窗、Beta 平滑、窗口淘汰、5 秒失效、ETX 截断、冷启动、成功接收、SINR 解码失败、ACK timeout、重传、广播、多播和 RX 去重。必须验证：
[
E^{comm}=E^{data}+E^{ctrl}=E^{tx}+E^{rx},\qquad E^0-E^{bat}=E^{prop}+E^{comm}.
]
差链路的 ETX、期望能耗和路径代价必须严格高于可靠链路。summary 输出网络、数据、控制、推进、TX、RX、角色能耗、E_pkt、有效性、J_relay,E 和账本误差。

## 9. P0-P10

1. P0：冻结配置、种子、输出 schema 与失败策略。
2. P1：五项 CH score 与 Service Guard。
3. P2：真正局部的 adaptive backoff。
4. P3：比较 TLET mean/min/25% quantile 并冻结。
5. P4：score margin、persistence 和紧急 CH rotation。
6. P5：ETX tracker、时延 EWMA 和期望通信能耗。
7. P6：BS-assisted Weighted Dijkstra planner。
8. P7：Relay Hold 提前释放。
9. P8：总电池与网络通信能耗分账。
10. P9：E0 与 3-seed 小规模筛选。
11. P10：10-seed 正式实验、配对统计和消融。

## 10. 冻结声明

本文档修订后，第一部分算法框架冻结。后续框架变化仅允许由 E0 失败、实现缺陷或明确的新实验事实触发，并必须保留配置、代码和实验记录。旧实验只用于历史诊断，不能证明修订后的 TAE-MWMP-DCA。


## 11. E0 and fair-entry lock

The experiment framework is frozen around five methods: DSDV, MOBIC, Original MWMP-DCA, TORP-like, and Proposed. Every paired run must reuse the same seed, initial positions, immutable mobility trace, traffic generation, PHY/MAC configuration, packet sizes, retransmission policy, simulation duration, and TX/RX accounting. Original MWMP-DCA means the original network-decision logic only; it uses the shared corrected energy ledger.

TORP-like is an adapted comparison method, not an exact reproduction. Its boundary is limited to a trajectory-aware feasible graph and dynamic weighted shortest-path routing using ETX-aware expected energy, delay, and TLET. It must not use Service Guard, CH clustering, or Conditional Relay Hold.

E8 compares Current-only, Kinematic-TLET, and Oracle-TLET on the same immutable realized mobility trace. Oracle mode may read future positions for prediction only and must never alter UAV motion.

E0 uses the standard point N=80, v=15 m/s, and lambda=2 packets/s/UAV with three paired seeds. The mean, minimum, and 25th-percentile TLET aggregations are compared using PDR, R_BS, R_break, CH tenure, E_pkt, CH churn, ledger error, and the TLET saturation ratio P(T_i=1). Selection is based on stable network benefit rather than PDR alone.

The E0 manifest also locks or screens R_data, C_max, (w_E,w_Q,w_D,w_T,w_M), alpha_S, H_BR, and delta_R. R_data candidates are 150, 200, 250, and 300 m; the selected range must avoid both structural disconnection and near-complete connectivity. Registered defaults are C_max=8, weights=(0.25,0.20,0.15,0.30,0.10), alpha_S=0.20, H_BR=3, and delta_R=0.08.

The three-seed stage is an engineering screen, not a significance test. Formal ten-seed runs may start only after there are no crashes or invalid configurations, R_BS is nonzero without widespread structural disconnection, absolute ledger error is below 1e-8 J, E_pkt is NaN only when no packet is delivered, and any energy reduction is not obtained by an obvious PDR sacrifice. Paired deltas use Proposed minus Baseline, so positive Delta PDR and Delta R_BS are better while negative Delta E_pkt is better.


## 12. E0 battery-horizon correction

The first formal E0 run exposed a frozen-parameter incompatibility rather than an algorithmic result. Under the adopted propulsion model, the three frozen 300-s traces require 296.9-300.6 kJ per UAV. The inherited 20-kJ battery was exhausted early and made the remaining network results invalid. Preserving a 25% emergency reserve requires at least 400.8 kJ, so the common five-method configuration is corrected to 420 kJ with a 42-kJ (10%) sleep threshold. This change is triggered by an explicit E0 failure and applies identically to every method.

Energy ledger entries are capped by physically available battery energy. Once a battery reaches zero, later demand is not recorded as consumed energy. E0 additionally rejects a run when the aggregate battery remaining ratio reaches the sleep-threshold ratio, preventing a ledger-correct but battery-depleted run from passing.


## 13. E0 communication-range selection

The paired topology screen rejects 200 m because the largest connected component contains only about 91.3-91.5% of UAVs. A 250-m range retains about 98.8-99.4% in the largest component while edge density remains about 15%, so the graph is connected without becoming near-complete. The common five-method R_data value is therefore frozen at 250 m.


## 14. Formal E0 result

The three-seed, 300-s paired E0 screen passed every hard gate. Mean aggregation is frozen for the formal algorithm: it achieved the highest mean PDR (10.486%), the lowest E_pkt (0.02793 J), lower backbone partition than q25, and a much lower TLET saturation ratio (0.166 versus 0.587). The small q25 gains in R_BS, CH tenure, and churn do not offset its lower PDR, higher E_pkt, higher partition ratio, and saturation. Minimum aggregation reduced partition ratio but materially degraded PDR and E_pkt.
