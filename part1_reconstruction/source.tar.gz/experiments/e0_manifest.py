E0_PARAMETER_REGISTER = {
    'initial_energy_j': {
        'value': 420000,
        'source': (
            'E0 propulsion-demand screen over the three frozen 300-s traces; '
            '296.9-300.6 kJ demand per UAV and a 25% emergency reserve require '
            'at least 400.8 kJ, rounded to 420 kJ'
        ),
    },
    'R_data_m': {
        'value': 250,
        'source': (
            'E0 topology screen at N=80: 200 m leaves only about 91.5% in the '
            'largest component, while 250 m gives about 99% with only 15% edge density'
        ),
        'candidates': [150, 200, 250, 300],
    },
    'C_max': {
        'value': 8,
        'source': 'frozen engineering capacity; E0 validates overload/saturation only',
    },
    'score_weights': {
        'value': {'E': 0.25, 'Q': 0.20, 'D': 0.15, 'T': 0.30, 'M': 0.10},
        'source': 'frozen W2 profile; no post-E0 tuning',
    },
    'alpha_S': {
        'value': 0.20,
        'source': 'frozen soft-guard prior; E0 validates burden distribution only',
    },
    'H_BR_rounds': {
        'value': 3,
        'source': 'existing relay-hold pilot results; conditional release remains mandatory',
    },
    'delta_R': {
        'value': 0.08,
        'source': 'existing stability-screen margin; frozen before formal matrix',
    },
}
