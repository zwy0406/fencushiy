"""Frozen E7 ablation profiles and the B0/B1 follow-up combinations."""

E7_PROFILES = {
    'A0_ORIGINAL': {
        'method': 'ORIGINAL_MWMP',
        'flags': {},
    },
    'A1_FORMAL_SCORE': {
        'method': 'PROPOSED',
        'flags': {
            'USE_SERVICE_GUARD': False,
            'USE_BACKBONE_CONNECTORS': False,
            'BACKBONE_RELAY_HOLD_ROUNDS': 0,
        },
    },
    'A2_SERVICE_GUARD': {
        'method': 'PROPOSED',
        'flags': {
            'USE_SERVICE_GUARD': True,
            'USE_BACKBONE_CONNECTORS': False,
            'BACKBONE_RELAY_HOLD_ROUNDS': 0,
        },
    },
    'A3_PREDICTIVE_BACKBONE': {
        'method': 'PROPOSED',
        'flags': {
            'USE_SERVICE_GUARD': True,
            'USE_BACKBONE_CONNECTORS': True,
            'BACKBONE_RELAY_HOLD_ROUNDS': 0,
        },
    },
    'A4_CONDITIONAL_HOLD': {
        'method': 'PROPOSED',
        'flags': {
            'USE_SERVICE_GUARD': True,
            'USE_BACKBONE_CONNECTORS': True,
            'BACKBONE_RELAY_HOLD_ROUNDS': 3,
        },
    },
    'B0_SCORE_BACKBONE': {
        'method': 'PROPOSED',
        'flags': {
            'USE_SERVICE_GUARD': False,
            'USE_BACKBONE_CONNECTORS': True,
            'BACKBONE_RELAY_HOLD_ROUNDS': 0,
        },
    },
    'B1_SCORE_BACKBONE_HOLD': {
        'method': 'PROPOSED',
        'flags': {
            'USE_SERVICE_GUARD': False,
            'USE_BACKBONE_CONNECTORS': True,
            'BACKBONE_RELAY_HOLD_ROUNDS': 3,
        },
    },
}
