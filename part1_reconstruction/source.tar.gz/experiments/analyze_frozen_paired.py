import argparse
import csv
import json
import math
import statistics
from pathlib import Path

from experiments.analyze_paired_comparison import student_t_critical_975


CORE_METRICS = {
    'pdr_percent': 'positive_is_better',
    'energy_per_delivered_packet_j': 'negative_is_better',
    'mean_bs_reachability_ratio': 'positive_is_better',
}


def load_rows(path):
    with path.open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def finite(value):
    if value is None or str(value).strip() == '':
        return None
    number = float(value)
    return number if math.isfinite(number) else None


def main():
    parser = argparse.ArgumentParser(description='Paired Student-t analysis for frozen matrix')
    parser.add_argument('--input', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--proposed', default='PROPOSED')
    args = parser.parse_args()
    rows = load_rows(Path(args.input))
    by_key = {(row['method'], int(row['seed'])): row for row in rows}
    seeds = sorted({int(row['seed']) for row in rows})
    methods = sorted({row['method'] for row in rows})
    comparisons = []
    for baseline in methods:
        if baseline == args.proposed:
            continue
        for metric, direction in CORE_METRICS.items():
            differences = []
            for seed in seeds:
                proposed = by_key.get((args.proposed, seed))
                reference = by_key.get((baseline, seed))
                if not proposed or not reference:
                    continue
                left = finite(proposed[metric])
                right = finite(reference[metric])
                if left is not None and right is not None:
                    differences.append(left - right)
            if not differences:
                continue
            mean = statistics.fmean(differences)
            sd = statistics.stdev(differences) if len(differences) > 1 else 0.0
            half_width = (
                student_t_critical_975(len(differences)) * sd /
                math.sqrt(len(differences))
                if len(differences) > 1 else 0.0
            )
            comparisons.append({
                'proposed': args.proposed,
                'baseline': baseline,
                'metric': metric,
                'direction': direction,
                'pairs': len(differences),
                'mean_delta_proposed_minus_baseline': mean,
                'ci95_low': mean - half_width,
                'ci95_high': mean + half_width,
            })
    descriptive = []
    numeric_metrics = set(CORE_METRICS) | {
        'backbone_partition_ratio', 'mean_ch_tenure_rounds',
        'cluster_head_churn_ratio', 'network_energy_j',
        'data_energy_j', 'control_energy_j', 'relay_energy_jain',
    }
    for method in methods:
        method_rows = [row for row in rows if row['method'] == method]
        for metric in sorted(numeric_metrics):
            values = [finite(row[metric]) for row in method_rows if row.get(metric)]
            values = [value for value in values if value is not None]
            if values:
                descriptive.append({
                    'method': method,
                    'metric': metric,
                    'n': len(values),
                    'mean': statistics.fmean(values),
                    'sd': statistics.stdev(values) if len(values) > 1 else 0.0,
                })
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    (output / 'paired_results.json').write_text(
        json.dumps(comparisons, indent=2), encoding='utf-8'
    )
    for name, data in (('paired_results.csv', comparisons), ('descriptive.csv', descriptive)):
        if not data:
            continue
        with (output / name).open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)
    print({'comparisons': len(comparisons), 'output': str(output)})


if __name__ == '__main__':
    main()
