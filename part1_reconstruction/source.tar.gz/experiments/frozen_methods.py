FROZEN_METHODS = {
    'DSDV': {
        'protocol': 'DSDV',
        'cluster_algorithm': 'DSDV',
    },
    'MOBIC': {
        'protocol': 'MWMP_DCA',
        'cluster_algorithm': 'MOBIC',
        'USE_BACKBONE_CONNECTORS': False,
        'BACKBONE_RELAY_HOLD_ROUNDS': 0,
        'USE_CH_ROTATION': False,
    },
    'ORIGINAL_MWMP': {
        'protocol': 'MWMP_DCA',
        'cluster_algorithm': 'MWMP_DCA',
        'MWMP_DECISION_MODE': 'original',
        'USE_BACKBONE_CONNECTORS': False,
        'BACKBONE_RELAY_HOLD_ROUNDS': 0,
    },
    'TORP_LIKE': {
        'protocol': 'TORP_LIKE',
        'cluster_algorithm': 'TORP_LIKE',
    },
    'PROPOSED': {
        'protocol': 'MWMP_DCA',
        'cluster_algorithm': 'MWMP_DCA',
        'MWMP_DECISION_MODE': 'proposed',
        'USE_BACKBONE_CONNECTORS': True,
        'BACKBONE_RELAY_HOLD_ROUNDS': 0,
    },
}


def apply_frozen_method(config, method):
    try:
        profile = FROZEN_METHODS[method]
    except KeyError as error:
        raise ValueError(f'Unknown frozen method: {method}') from error
    for key, value in profile.items():
        if key not in ('protocol', 'cluster_algorithm'):
            setattr(config, key, value)
    config.CLUSTER_ALGORITHM = profile['cluster_algorithm']
    return profile
