#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

python_bin=/root/miniconda3/envs/fc/bin/python
result_root=results/e7_b_followup_three_seed_20261001
trace_root=results/five_method_screen_centralpath_n80_20260926/mobility_traces
mkdir -p "$result_root"

run_seed() {
    local seed=$1 profile run_root summary_file
    for profile in B0_SCORE_BACKBONE B1_SCORE_BACKBONE_HOLD; do
        run_root="$result_root/seed${seed}/${profile}"
        summary_file="$run_root/metrics/e7_${profile}_seed${seed}_summary.csv"
        if [[ -e "$summary_file" ]]; then
            printf 'SKIP seed=%s profile=%s (summary exists)\n' "$seed" "$profile"
            continue
        fi
        printf 'START seed=%s profile=%s %s\n' "$seed" "$profile" "$(date -Is)"
        "$python_bin" -m experiments.run_experiment \
            --e7-profile "$profile" \
            --seed "$seed" \
            --n-drones 80 \
            --speed 15 \
            --traffic-rate 2 \
            --comm-range 250 \
            --sim-time-s 300 \
            --mobility-trace-mode replay \
            --mobility-trace-file "$trace_root/seed${seed}_n80_v15.json" \
            --output-dir "$run_root" \
            --experiment-name "e7_${profile}_seed${seed}" \
            > "$result_root/seed${seed}_${profile}.log" 2>&1
        test -s "$summary_file"
        printf 'DONE seed=%s profile=%s %s\n' "$seed" "$profile" "$(date -Is)"
    done
    touch "$result_root/seed${seed}_DONE"
}

pids=()
for seed in 2025 2026 2027; do
    test -s "$trace_root/seed${seed}_n80_v15.json"
    (run_seed "$seed") > "$result_root/worker_seed${seed}.log" 2>&1 &
    pids+=("$!")
done

failed=0
for pid in "${pids[@]}"; do
    wait "$pid" || failed=1
done
if (( failed )); then
    touch "$result_root/FINALIZER_FAILED"
    exit 1
fi
touch "$result_root/FINALIZER_DONE"
