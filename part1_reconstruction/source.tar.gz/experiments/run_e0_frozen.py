import argparse
import csv
import json
import math
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from experiments.e0_manifest import E0_PARAMETER_REGISTER
from experiments.generate_mobility_trace import generate_trace
from experiments.run_experiment import run_once
from utils import config


TLET_VARIANTS = ('mean', 'min', 'q25')
E0_METRICS = (
    'pdr_percent',
    'mean_bs_reachability_ratio',
    'backbone_partition_ratio',
    'mean_ch_tenure_rounds',
    'energy_per_delivered_packet_j',
    'tlet_saturation_ratio',
    'cluster_head_churn_ratio',
    'energy_accounting_error_j',
    'battery_remaining_ratio',
    'energy_metric_valid',
)


def parse_list(value, cast):
    return [cast(item) for item in value.split(',') if item]


def component_metrics(positions, radius):
    count = len(positions)
    adjacency = [set() for _ in positions]
    edges = 0
    for left in range(count):
        for right in range(left + 1, count):
            distance = math.dist(positions[left], positions[right])
            if distance <= radius:
                adjacency[left].add(right)
                adjacency[right].add(left)
                edges += 1
    unseen = set(range(count))
    largest = 0
    while unseen:
        stack = [unseen.pop()]
        size = 0
        while stack:
            node = stack.pop()
            size += 1
            neighbors = adjacency[node] & unseen
            unseen.difference_update(neighbors)
            stack.extend(neighbors)
        largest = max(largest, size)
    possible = count * (count - 1) / 2
    return {
        'largest_component_ratio': largest / count if count else 0.0,
        'average_degree': 2 * edges / count if count else 0.0,
        'edge_density': edges / possible if possible else 0.0,
    }


def topology_screen(trace_paths, ranges):
    rows = []
    for trace_path in trace_paths:
        payload = json.loads(trace_path.read_text(encoding='utf-8'))
        node_states = [
            states for node_id, states in payload['nodes'].items()
            if int(node_id) != config.BS_NODE_ID
        ]
        sample_count = min(len(states) for states in node_states)
        stride = 10
        for radius in ranges:
            samples = []
            for index in range(0, sample_count, stride):
                positions = [states[index]['coords'] for states in node_states]
                samples.append(component_metrics(positions, radius))
            rows.append({
                'seed': payload['seed'],
                'comm_range_m': radius,
                'largest_component_ratio': sum(row['largest_component_ratio'] for row in samples) / len(samples),
                'average_degree': sum(row['average_degree'] for row in samples) / len(samples),
                'edge_density': sum(row['edge_density'] for row in samples) / len(samples),
            })
    return rows


def write_csv(path, rows):
    fields = sorted({key for row in rows for key in row})
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def validate_run(row):
    errors = []
    delivered = int(row['datapacket_arrived'])
    energy_valid = bool(row['energy_metric_valid'])
    if energy_valid != (delivered > 0):
        errors.append('energy validity does not match delivered-packet count')
    if float(row['energy_accounting_error_j']) >= 1e-8:
        errors.append('energy ledger error exceeds 1e-8 J')
    sleep_ratio = config.ENERGY_THRESHOLD / float(config.INITIAL_ENERGY)
    if float(row.get('battery_remaining_ratio', 0.0)) <= sleep_ratio:
        errors.append('aggregate battery remaining ratio reached the sleep threshold')
    if float(row.get('mean_bs_reachability_ratio', 0.0)) <= 0.0:
        errors.append('R_BS is zero')
    if float(row.get('backbone_partition_ratio', 0.0)) >= 0.9:
        errors.append('extreme backbone partition')
    return errors


def run_tlet_task(task):
    aggregation = task['aggregation']
    seed = task['seed']
    config.TLET_AGGREGATION = aggregation
    row = run_once(
        protocol='MWMP_DCA',
        seed=seed,
        n_drones=task['n_drones'],
        output_dir=task['output_dir'],
        speed=task['speed'],
        experiment_name=f'e0_tlet_{aggregation}_seed{seed}',
        predictor_mode='kinematic',
        traffic_rate=task['traffic_rate'],
        comm_range=task['selected_range'],
        sim_time_s=task['sim_time_s'],
        method='PROPOSED',
        mobility_trace_mode='replay',
        mobility_trace_file=task['trace_path'],
    )
    row['tlet_aggregation'] = aggregation
    row['r_break'] = row.get('backbone_partition_ratio', 0.0)
    return aggregation, seed, row


def main():
    parser = argparse.ArgumentParser(description='Frozen E0 topology and TLET screen')
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--seeds', default='3031,3032,3033')
    parser.add_argument('--n-drones', type=int, default=80)
    parser.add_argument('--speed', type=float, default=15.0)
    parser.add_argument('--traffic-rate', type=float, default=2.0)
    parser.add_argument('--sim-time-s', type=float, required=True)
    parser.add_argument('--ranges', default='150,200,250,300')
    parser.add_argument('--selected-range', type=float, default=250.0)
    parser.add_argument('--workers', type=int, default=9)
    args = parser.parse_args()

    root = Path(args.output_dir)
    trace_root = root / 'mobility_traces'
    root.mkdir(parents=True, exist_ok=True)
    seeds = parse_list(args.seeds, int)
    ranges = parse_list(args.ranges, float)
    trace_paths = []
    for seed in seeds:
        path = trace_root / f'seed{seed}_n{args.n_drones}_v{args.speed:g}.json'
        if not path.exists():
            generate_trace(seed, args.n_drones, args.speed, args.sim_time_s, path)
        trace_paths.append(path)

    topology_rows = topology_screen(trace_paths, ranges)
    write_csv(root / 'e0_topology_screen.csv', topology_rows)
    tasks = []
    for aggregation in TLET_VARIANTS:
        for seed, trace_path in zip(seeds, trace_paths):
            tasks.append({
                'aggregation': aggregation,
                'seed': seed,
                'trace_path': str(trace_path),
                'n_drones': args.n_drones,
                'output_dir': str(root / aggregation / f'seed{seed}'),
                'speed': args.speed,
                'traffic_rate': args.traffic_rate,
                'selected_range': args.selected_range,
                'sim_time_s': args.sim_time_s,
            })

    result_rows = []
    gate_failures = []
    workers = max(1, min(args.workers, len(tasks)))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(run_tlet_task, task) for task in tasks]
        for future in as_completed(futures):
            aggregation, seed, row = future.result()
            result_rows.append(row)
            errors = validate_run(row)
            if errors:
                gate_failures.append({
                    'seed': seed,
                    'aggregation': aggregation,
                    'errors': errors,
                })
            print({
                'completed': f'{aggregation}/seed{seed}',
                'gate_errors': errors,
            }, flush=True)

    variant_order = {name: index for index, name in enumerate(TLET_VARIANTS)}
    result_rows.sort(key=lambda row: (
        variant_order[row['tlet_aggregation']], int(row['seed'])
    ))
    gate_failures.sort(key=lambda row: (
        variant_order[row['aggregation']], int(row['seed'])
    ))
    write_csv(root / 'e0_tlet_runs.csv', result_rows)
    report = {
        'status': 'pass' if not gate_failures else 'fail',
        'paired_seeds': seeds,
        'parallel_workers': workers,
        'standard_point': {
            'N': args.n_drones,
            'speed_mps': args.speed,
            'traffic_rate_pps': args.traffic_rate,
            'comm_range_m': args.selected_range,
        },
        'metrics': E0_METRICS,
        'parameter_register': E0_PARAMETER_REGISTER,
        'gate_failures': gate_failures,
        'selection_rule': 'stable network benefit; never select by PDR alone',
    }
    (root / 'e0_report.json').write_text(
        json.dumps(report, indent=2), encoding='utf-8'
    )
    print({'status': report['status'], 'runs': len(result_rows), 'output': str(root)})


if __name__ == '__main__':
    main()
