import argparse
import json
from pathlib import Path

import simpy

from simulator.simulator import Simulator
from utils import config


def generate_trace(seed, n_drones, speed, sim_time_s, output_path):
    config.TRACE_ONLY = True
    config.MOBILITY_TRACE_MODE = 'record'
    config.MOBILITY_TRACE_FILE = None
    config.ROUTING_PROTOCOL = 'DSDV'
    config.NUMBER_OF_DRONES = n_drones
    config.DEFAULT_UAV_SPEED = speed
    config.HETEROGENEOUS = 0
    config.ENABLE_VISUALIZATION = False
    config.ENABLE_PLOTS = False
    duration_us = int((sim_time_s + config.PREDICTION_HORIZON) * 1e6)
    config.SIM_TIME = duration_us
    env = simpy.Environment()
    channels = {
        index: simpy.Resource(env, capacity=1)
        for index in range(n_drones)
    }
    simulator = Simulator(seed, env, channels, n_drones)
    env.run(until=duration_us)
    payload = {
        'seed': seed,
        'n_drones': n_drones,
        'speed_mps': speed,
        'mobility_model': config.MOBILITY_MODEL,
        'duration_us': duration_us,
        'nodes': {
            str(drone.identifier): drone.mobility_trace
            for drone in simulator.drones
            if not drone.is_base_station
        },
    }
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, separators=(',', ':')), encoding='utf-8')
    config.TRACE_ONLY = False
    return output


def main():
    parser = argparse.ArgumentParser(description='Generate immutable E8 mobility trace')
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--n-drones', type=int, default=80)
    parser.add_argument('--speed', type=float, default=15.0)
    parser.add_argument('--sim-time-s', type=float, required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = generate_trace(
        args.seed, args.n_drones, args.speed, args.sim_time_s, args.output
    )
    print({'trace': str(output), 'nodes': args.n_drones})


if __name__ == '__main__':
    main()
