from utils import config


class ReplayMobility3D:
    """Replays an immutable mobility trace without using predictor output."""

    def __init__(self, drone):
        self.my_drone = drone
        trace = drone.simulator.mobility_trace_data['nodes'].get(
            str(drone.identifier)
        )
        if not trace:
            raise RuntimeError(
                f'Mobility trace missing node {drone.identifier}'
            )
        self.trace = trace
        drone.simulator.env.process(self.mobility_update(drone))

    def mobility_update(self, drone):
        env = drone.simulator.env
        previous_time = 0
        for state in self.trace:
            timestamp = int(state['time_us'])
            if timestamp < env.now:
                continue
            if timestamp > env.now:
                yield env.timeout(timestamp - env.now)
            drone.coords = list(state['coords'])
            drone.velocity = list(state['velocity'])
            elapsed = max(0, timestamp - previous_time)
            if elapsed:
                energy = elapsed / 1e6 * drone.energy_model.power_consumption(
                    drone.speed
                )
                drone.consume_energy(energy, source='propulsion')
            previous_time = timestamp
        remaining = max(0, config.SIM_TIME - env.now)
        if remaining:
            yield env.timeout(remaining)
