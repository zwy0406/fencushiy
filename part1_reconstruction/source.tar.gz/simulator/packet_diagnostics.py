"""Opt-in, event-only packet timing and terminal-outcome diagnostics."""

import csv
import os
from collections import Counter
from itertools import groupby


PHASES = ('queue_CM', 'queue_CH', 'queue_BR', 'queue_BS', 'mac', 'air', 'ack_retry', 'route', 'other')
DROP_REASONS = (
    'QueueOverflow', 'MaxRetry', 'RouteUnavailable', 'MigrationExhausted',
    'TTL', 'PacketLifetime', 'LoopReject', 'Other',
)
HOP_FIELDS = (
    'packet_id', 'node_id', 'role_at_service', 'enqueue_time', 'dequeue_time',
    'mac_start_time', 'tx_start_time', 'tx_end_time',
    'ack_end_or_timeout_time', 'route_wait_time', 'retry_count', 'transmission_attempt',
    'snapshot_epoch', 'outcome', 'on_delivery_path',
)


class PacketDiagnostics:
    def __init__(self, metrics):
        self.metrics = metrics
        self.packets = {}
        self.hops = []

    def _role(self, drone):
        if getattr(drone, 'is_base_station', False):
            return 'BS'
        return self.metrics._role_label(drone)

    def _trace(self, packet):
        return self.packets.get(packet.packet_id)

    @staticmethod
    def _token(packet):
        return packet._diagnostic_object_token

    def _switch(self, trace, now, phase, role=None, served_queue=False, owner_id=None):
        elapsed = now - trace['phase_start']
        if elapsed < 0:
            raise ValueError('Packet diagnostic time moved backward')
        old_phase = trace['phase']
        if old_phase is not None and elapsed:
            trace['intervals'].append((trace['phase_start'], now, old_phase, trace['phase_owner']))
        if old_phase == 'queue':
            old_phase = 'queue_' + role if served_queue else 'other'
        if old_phase is not None:
            trace['parts'][old_phase] += elapsed
        trace['phase'] = phase
        trace['phase_start'] = now
        trace['phase_owner'] = owner_id
        trace['queue_owner'] = None
        if role is not None:
            trace['role'] = role

    def _new_hop(self, trace, packet, drone, now):
        hop = dict.fromkeys(HOP_FIELDS)
        hop.update(packet_id=packet.packet_id, node_id=drone.identifier,
                   role_at_service=self._role(drone), enqueue_time=now,
                   route_wait_time=0, retry_count=0,
                   snapshot_epoch=getattr(packet, 'route_epoch', None),
                   outcome='pending', on_delivery_path=False)
        hop['_object_id'] = self._token(packet)
        self.hops.append(hop)
        trace['hops'].append(hop)
        trace['hop'] = hop
        return hop

    def generated(self, packet, drone, now):
        if packet.packet_id in self.packets:
            raise ValueError('Duplicate generated packet ID')
        packet._diagnostic_object_token = 0
        self.packets[packet.packet_id] = {
            'creation_time': now, 'deadline': packet.deadline,
            'phase': 'other', 'phase_start': now, 'role': self._role(drone),
            'phase_owner': 0, 'intervals': [],
            'root_object_id': 0, 'parents': {}, 'next_copy_token': 1,
            'queue_starts': {}, 'queue_spans': [],
            'node_id': drone.identifier,
            'queue_owner': None,
            'parts': {phase: 0 for phase in PHASES},
            'hop': None, 'hops': [], 'delivered_time': None, 'drop_reason': None,
            'drop_role': None, 'last_failure': None,
        }

    def copied(self, parent, child):
        trace = self._trace(parent)
        if trace is not None:
            token = trace['next_copy_token']
            trace['next_copy_token'] += 1
            child._diagnostic_object_token = token
            trace['parents'][token] = self._token(parent)

    def enqueued(self, packet, drone, now):
        trace = self._trace(packet)
        if trace is None or trace['delivered_time'] is not None:
            return
        prior = trace['hop']
        if prior is not None and prior.get('_route_wait_start') is not None:
            prior['route_wait_time'] += now - prior.pop('_route_wait_start')
        self._switch(trace, now, 'queue', self._role(drone), owner_id=self._token(packet))
        trace['queue_owner'] = (self._token(packet), drone.identifier)
        trace['queue_starts'][(self._token(packet), drone.identifier, 'node')] = now
        trace['node_id'] = drone.identifier
        trace['last_failure'] = None
        self._new_hop(trace, packet, drone, now)

    def dequeued(self, packet, drone, now):
        trace = self._trace(packet)
        if trace is None or trace['delivered_time'] is not None:
            return
        served_queue = trace['queue_owner'] == (self._token(packet), drone.identifier)
        self._switch(trace, now, 'route', self._role(drone), served_queue, self._token(packet))
        start = trace['queue_starts'].pop((self._token(packet), drone.identifier, 'node'), None)
        if start is not None:
            trace['queue_spans'].append((start, now, self._role(drone), self._token(packet)))
        hop = next((item for item in reversed(trace['hops'])
                    if item['node_id'] == drone.identifier
                    and item.get('_object_id') == self._token(packet)
                    and item['dequeue_time'] is None), None)
        if hop is None:
            hop = self._new_hop(trace, packet, drone, now)
        trace['hop'] = hop
        trace['node_id'] = drone.identifier
        hop['dequeue_time'] = now
        hop['role_at_service'] = self._role(drone)

    def route_unavailable(self, packet, drone, now):
        trace = self._trace(packet)
        if trace is None or trace['delivered_time'] is not None:
            return
        failure = getattr(packet, 'migration_failure_reason', None)
        if failure == 'VISITED_CONFLICT':
            trace['last_failure'] = 'LoopReject'
        elif failure:
            trace['last_failure'] = 'MigrationExhausted'
        elif trace['last_failure'] is None:
            trace['last_failure'] = 'RouteUnavailable'
        hop = trace['hop']
        if hop is not None and hop.get('_route_wait_start') is None:
            hop['_route_wait_start'] = now

    def note_failure(self, packet, reason):
        trace = self._trace(packet)
        if trace is not None and trace['delivered_time'] is None:
            trace['last_failure'] = reason

    def buffer_requested(self, packet, drone, now):
        trace = self._trace(packet)
        if trace is not None and trace['delivered_time'] is None:
            self._switch(trace, now, 'queue', self._role(drone), owner_id=self._token(packet))
            trace['queue_owner'] = (self._token(packet), drone.identifier)
            trace['queue_starts'][(self._token(packet), drone.identifier, 'buffer')] = now

    def mac_started(self, packet, drone, now, attempt):
        trace = self._trace(packet)
        if trace is None or trace['delivered_time'] is not None:
            return
        served_queue = trace['queue_owner'] == (self._token(packet), drone.identifier)
        self._switch(trace, now, 'mac', self._role(drone), served_queue, self._token(packet))
        start = trace['queue_starts'].pop((self._token(packet), drone.identifier, 'buffer'), None)
        if start is not None:
            trace['queue_spans'].append((start, now, self._role(drone), self._token(packet)))
        hop = next((item for item in reversed(trace['hops'])
                    if item['node_id'] == drone.identifier
                    and item.get('_object_id') == self._token(packet)
                    and item['mac_start_time'] is None), None)
        if hop is None:
            hop = self._new_hop(trace, packet, drone, now)
            hop['dequeue_time'] = now
        trace['hop'] = hop
        trace['node_id'] = drone.identifier
        hop['mac_start_time'] = now
        hop['role_at_service'] = self._role(drone)
        hop['retry_count'] = max(0, attempt - 1)
        hop['transmission_attempt'] = attempt
        hop['_object_id'] = self._token(packet)

    def tx_started(self, packet, drone, now):
        trace = self._trace(packet)
        if trace is None or trace['delivered_time'] is not None:
            return
        self._switch(trace, now, 'air', self._role(drone), owner_id=self._token(packet))
        for hop in reversed(trace['hops']):
            if hop['node_id'] == drone.identifier and hop.get('_object_id') == self._token(packet) and hop['tx_start_time'] is None:
                hop['tx_start_time'] = now
                hop['_phy_attempt'] = getattr(packet, '_phy_tx_attempt', None)
                hop['snapshot_epoch'] = getattr(packet, 'route_epoch', None)
                break

    def tx_ended(self, packet, drone, now):
        trace = self._trace(packet)
        if trace is None:
            return
        attempt = getattr(packet, '_phy_tx_attempt', None)
        for hop in reversed(trace['hops']):
            if (hop['node_id'] == drone.identifier and hop.get('_object_id') == self._token(packet)
                    and hop.get('_phy_attempt') == attempt and hop['tx_end_time'] is None
                    and hop['tx_start_time'] is not None):
                hop['tx_end_time'] = now
                break
        if (trace['delivered_time'] is None and trace['node_id'] == drone.identifier
                and trace['phase'] == 'air'):
            self._switch(trace, now, 'ack_retry', owner_id=self._token(packet))

    def ack_finished(self, packet, drone, now, outcome):
        trace = self._trace(packet)
        if trace is None:
            return
        attempt = getattr(packet, '_phy_tx_attempt', None)
        for hop in reversed(trace['hops']):
            if (hop['node_id'] == drone.identifier and hop.get('_phy_attempt') == attempt
                    and hop['ack_end_or_timeout_time'] is None and hop['tx_start_time'] is not None):
                hop['ack_end_or_timeout_time'] = now
                hop['outcome'] = outcome
                break
        if (trace['delivered_time'] is None and trace['node_id'] == drone.identifier
                and trace['phase'] == 'ack_retry' and outcome == 'ack'):
            self._switch(trace, now, 'other', owner_id=self._token(packet))

    def dropped(self, packet, drone, now, reason):
        trace = self._trace(packet)
        if trace is None or trace['delivered_time'] is not None:
            return
        if reason not in DROP_REASONS:
            raise ValueError('Unknown primary drop reason: ' + reason)
        if reason == 'PacketLifetime' and trace['phase'] == 'route':
            reason = trace['last_failure'] or reason
        if trace['drop_reason'] is None:
            trace['drop_reason'] = reason
            trace['drop_role'] = self._role(drone)
            if trace['hop'] is not None:
                if trace['hop'].get('_route_wait_start') is not None:
                    trace['hop']['route_wait_time'] += now - trace['hop'].pop('_route_wait_start')
                trace['hop']['outcome'] = reason

    @staticmethod
    def _causal_ids(trace, delivered_token):
        ids = []
        token = delivered_token
        while token not in ids:
            ids.append(token)
            if token == trace['root_object_id']:
                break
            token = trace['parents'].get(token)
            if token is None:
                raise ValueError('Delivered packet copy has no recorded parent')
        return {token: depth for depth, token in enumerate(reversed(ids))}

    @staticmethod
    def _causal_parts(trace, causal_ids, now):
        start = trace['creation_time']
        priorities = {'route': 1, 'ack_retry': 2, 'mac': 3, 'air': 4}
        events = []

        def add_span(begin, end, phase, priority):
            begin, end = max(start, begin), min(now, end)
            if end > begin:
                key = (priority, phase)
                events.append((begin, 1, key))
                events.append((end, -1, key))

        for begin, end, phase, owner in trace['intervals']:
            if owner in causal_ids and phase in priorities:
                add_span(begin, end, phase, priorities[phase])
        for begin, end, role, owner in trace['queue_spans']:
            if owner in causal_ids:
                add_span(begin, end, 'queue_' + role, 5 + causal_ids[owner])

        parts = {phase: 0 for phase in PHASES}
        active = Counter()
        last = start
        for time, group in groupby(sorted(events), key=lambda event: event[0]):
            if time > last:
                highest = max(active, default=None)
                phase = highest[1] if highest is not None else 'other'
                parts[phase] += time - last
            for _, delta, key in group:
                active[key] += delta
                if active[key] == 0:
                    del active[key]
            last = time
        parts['other'] += now - last
        return parts

    def delivered(self, packet, now):
        trace = self._trace(packet)
        if trace is None or trace['delivered_time'] is not None:
            return
        self._switch(trace, now, None, owner_id=self._token(packet))
        trace['delivered_time'] = now
        causal_ids = self._causal_ids(trace, self._token(packet))
        trace['parts'] = self._causal_parts(trace, causal_ids, now)
        for hop in trace['hops']:
            hop['on_delivery_path'] = hop.get('_object_id') in causal_ids
        for hop in reversed(trace['hops']):
            if hop['on_delivery_path'] and hop['outcome'] == 'pending':
                hop['outcome'] = 'delivered'
                break

    def _outcomes(self, now):
        for packet_id, trace in self.packets.items():
            if trace['delivered_time'] is not None:
                yield packet_id, trace, 'delivered', False
            elif trace['drop_reason'] is not None:
                yield packet_id, trace, trace['drop_reason'], False
            elif now >= trace['creation_time'] + trace['deadline']:
                reason = trace['last_failure'] if trace['phase'] == 'route' else None
                yield packet_id, trace, reason or 'PacketLifetime', False
            else:
                yield packet_id, trace, 'IncompleteAtHorizon', True

    def summary(self, now):
        outcomes = list(self._outcomes(now))
        delivered = [trace for _, trace, reason, _ in outcomes if reason == 'delivered']
        drops = Counter(reason for _, _, reason, censored in outcomes if reason != 'delivered' and not censored)
        drop_roles = Counter(trace['drop_role'] or trace['role'] for _, trace, reason, censored in outcomes if reason != 'delivered' and not censored)
        total_delay = sum(trace['delivered_time'] - trace['creation_time'] for trace in delivered)
        total_parts = {phase: sum(trace['parts'][phase] for trace in delivered) for phase in PHASES}
        errors = [abs(trace['delivered_time'] - trace['creation_time'] - sum(trace['parts'].values())) for trace in delivered]
        result = {
            'packet_diag_generated': len(outcomes),
            'packet_diag_delivered': len(delivered),
            'packet_diag_terminal_drops': sum(reason != 'delivered' and not censored for _, _, reason, censored in outcomes),
            'packet_diag_incomplete_at_horizon': sum(censored for _, _, _, censored in outcomes),
            'packet_diag_max_delay_error_us': max(errors, default=0),
        }
        for reason in DROP_REASONS:
            result['drop_' + reason] = drops[reason]
        for role in ('CM', 'CH', 'BR', 'BS'):
            result['drop_role_' + role] = drop_roles[role]
        for phase in PHASES:
            result['delay_' + phase + '_mean_ms'] = total_parts[phase] / max(1, len(delivered)) / 1000
            result['delay_' + phase + '_share'] = total_parts[phase] / total_delay if total_delay else 0.0
        return result

    def export(self, metrics_dir, now):
        rows = []
        for packet_id, trace, outcome, censored in self._outcomes(now):
            row = {'packet_id': packet_id, 'creation_time': trace['creation_time'],
                   'delivery_time': trace['delivered_time'], 'outcome': outcome,
                   'incomplete_at_horizon': censored, 'drop_role': trace['drop_role'] or trace['role'],
                   'last_failure': trace['last_failure']}
            row.update(trace['parts'])
            row['e2e_delay_us'] = (trace['delivered_time'] - trace['creation_time']) if trace['delivered_time'] is not None else None
            row['delay_error_us'] = (row['e2e_delay_us'] - sum(trace['parts'].values())) if row['e2e_delay_us'] is not None else None
            rows.append(row)
        self._write(os.path.join(metrics_dir, 'packet_outcomes.csv'), rows)
        self._write(os.path.join(metrics_dir, 'packet_hops.csv'), self.hops, HOP_FIELDS)

    @staticmethod
    def _write(path, rows, fields=None):
        if not rows and fields is None:
            return
        fields = fields or list(rows[0])
        with open(path, 'w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(rows)
