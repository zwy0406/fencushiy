import heapq
from dataclasses import dataclass

from energy.energy_accounting import CONTROL, RX, TX
from entities.packet import DataPacket
from routing.mwmp_dca.mwmp_dca_routing import MwmpDcaRouting
from topology.mwmp_dca.trajectory_let_calculator import trajectory_based_let
from utils import config
from utils.util_function import euclidean_distance_3d


@dataclass(frozen=True)
class TorpLikeSnapshot:
    epoch: int
    created_time_us: float
    paths: dict
    graph_reachable_to_bs: frozenset


class TorpLikePlanner:
    """Central TORP-like planner with a paid, one-second state snapshot."""

    def __init__(self, simulator):
        self.simulator = simulator
        self.snapshot = TorpLikeSnapshot(0, 0.0, {}, frozenset())
        self.simulator.env.process(self._refresh_periodically())

    def _refresh_periodically(self):
        while True:
            self.refresh()
            yield self.simulator.env.timeout(config.CLUSTER_INTERVAL)

    def refresh(self):
        nodes = [node for node in self.simulator.drones if not node.sleep]
        now_us = float(self.simulator.env.now)
        observed_state = {
            node.identifier: {
                'coords': tuple(node.coords),
                'velocity': tuple(node.velocity),
                'is_base_station': bool(getattr(node, 'is_base_station', False)),
            }
            for node in nodes
        }
        bs_ids = {
            node_id for node_id, values in observed_state.items()
            if values['is_base_station']
        }
        report_paths = self._report_paths(observed_state, bs_ids)
        reported_ids = bs_ids | set(report_paths)
        state = {
            node_id: values for node_id, values in observed_state.items()
            if node_id in reported_ids
        }
        graph = self._build_graph(state, now_us)
        paths = self._all_pairs_paths(graph)
        reachable = frozenset(
            source_id for source_id in state
            if source_id in bs_ids or any(
                (source_id, bs_id) in paths for bs_id in bs_ids
            )
        )
        self.snapshot = TorpLikeSnapshot(
            epoch=self.snapshot.epoch + 1,
            created_time_us=now_us,
            paths=paths,
            graph_reachable_to_bs=reachable,
        )
        self._account_control_exchange(nodes, report_paths)

    def path_for(self, source_id, target_id):
        return self.snapshot.paths.get((int(source_id), int(target_id)), ())

    def has_route(self, source_id, target_id):
        return bool(self.path_for(source_id, target_id))

    def snapshot_age_us(self):
        return max(0.0, float(self.simulator.env.now) - self.snapshot.created_time_us)

    def _build_graph(self, state, now_us):
        graph = {node_id: [] for node_id in state}
        trajectories = {
            node_id: self._kinematic_trajectory(values)
            for node_id, values in state.items()
        }
        for source_id, source in state.items():
            for target_id, target in state.items():
                if source_id == target_id:
                    continue
                if euclidean_distance_3d(
                    source['coords'], target['coords']
                ) > config.COMMUNICATION_RANGE:
                    continue
                tlet = trajectory_based_let(
                    trajectories[source_id],
                    trajectories[target_id],
                    config.COMMUNICATION_RANGE,
                )
                if tlet <= 0:
                    continue
                graph[source_id].append((
                    self._edge_cost(source_id, target_id, tlet, now_us),
                    target_id,
                ))
            graph[source_id].sort(key=lambda item: item[1])
        return graph

    def _edge_cost(self, source_id, target_id, tlet, now_us):
        tracker = self.simulator.link_reliability
        weights = config.TORP_LIKE_COST_WEIGHTS
        tlet_ratio = min(1.0, tlet / max(1.0, config.PREDICTION_HORIZON))
        return (
            weights['energy'] * tracker.normalized_expected_energy(
                source_id, target_id, now_us
            ) +
            weights['delay'] * tracker.normalized_delay(
                source_id, target_id, now_us
            ) +
            weights['tlet'] * (1.0 - tlet_ratio)
        )

    @staticmethod
    def _all_pairs_paths(graph):
        paths = {}
        for source_id in sorted(graph):
            distances = {source_id: 0.0}
            previous = {}
            queue = [(0.0, source_id)]
            while queue:
                distance, node_id = heapq.heappop(queue)
                if distance != distances.get(node_id):
                    continue
                for edge_cost, neighbor_id in graph.get(node_id, ()):
                    candidate = distance + edge_cost
                    if candidate < distances.get(neighbor_id, float('inf')):
                        distances[neighbor_id] = candidate
                        previous[neighbor_id] = node_id
                        heapq.heappush(queue, (candidate, neighbor_id))
            for target_id in distances:
                if target_id == source_id:
                    continue
                path = [target_id]
                while path[-1] != source_id:
                    path.append(previous[path[-1]])
                paths[(source_id, target_id)] = tuple(reversed(path))
        return paths

    @staticmethod
    def _kinematic_trajectory(state):
        if state['is_base_station']:
            return [state['coords']] * config.PREDICTION_HORIZON
        return [
            tuple(
                state['coords'][axis] + state['velocity'][axis] * step
                for axis in range(3)
            )
            for step in range(1, config.PREDICTION_HORIZON + 1)
        ]

    @staticmethod
    def _report_paths(state, bs_ids):
        adjacency = {node_id: [] for node_id in state}
        for source_id, source in state.items():
            for target_id, target in state.items():
                if source_id == target_id:
                    continue
                if euclidean_distance_3d(
                    source['coords'], target['coords']
                ) <= config.COMMUNICATION_RANGE:
                    adjacency[source_id].append(target_id)
        paths = {}
        for source_id in sorted(set(state) - set(bs_ids)):
            queue = [source_id]
            parents = {source_id: None}
            target_bs = None
            for current in queue:
                if current in bs_ids:
                    target_bs = current
                    break
                for neighbor_id in sorted(adjacency[current]):
                    if neighbor_id not in parents:
                        parents[neighbor_id] = current
                        queue.append(neighbor_id)
            if target_bs is None:
                continue
            path = [target_bs]
            while path[-1] != source_id:
                path.append(parents[path[-1]])
            paths[source_id] = tuple(reversed(path))
        return paths

    def _account_control_exchange(self, nodes, report_paths):
        by_id = {node.identifier: node for node in nodes}
        transmissions = 0
        for _node_id, path_to_bs in sorted(report_paths.items()):
            transmissions += self._charge_path(path_to_bs, by_id)
            transmissions += self._charge_path(tuple(reversed(path_to_bs)), by_id)
        if transmissions:
            self.simulator.metrics.increment_control_packets(
                transmissions,
                category='torp',
            )

    @staticmethod
    def _charge_path(path, by_id):
        packet_seconds = config.HELLO_PACKET_LENGTH / config.BIT_RATE
        transmissions = 0
        for source_id, target_id in zip(path, path[1:]):
            source = by_id[source_id]
            target = by_id[target_id]
            source.consume_energy(
                packet_seconds * config.TRANSMITTING_POWER,
                source=CONTROL,
                direction=TX,
                role_energy=source_id != path[0],
            )
            target.consume_energy(
                packet_seconds * config.RECEIVING_POWER,
                source=CONTROL,
                direction=RX,
                role_energy=target_id != path[-1],
            )
            transmissions += 1
        return transmissions


class TorpLikeRouting(MwmpDcaRouting):
    """Adapted TORP-like routing, not an exact reproduction of the paper."""

    def __init__(self, simulator, my_drone):
        self.simulator = simulator
        self.my_drone = my_drone
        self.check_interval = 0.6 * 1e6
        self.waiting_list = []
        self.backbone_router = None
        self.backbone_router_role = None
        if getattr(simulator, 'torp_like_planner', None) is None:
            simulator.torp_like_planner = TorpLikePlanner(simulator)
        self.planner = simulator.torp_like_planner
        self.simulator.env.process(self.check_waiting_list())

    def next_hop_selection(self, packet):
        if not isinstance(packet, DataPacket):
            return False, packet, False
        self._prepare_packet_state(packet)
        path = self.planner.path_for(
            self.my_drone.identifier,
            packet.dst_drone.identifier,
        )
        if len(path) < 2:
            return False, packet, False
        packet.next_hop_id = path[1]
        return True, packet, False

    def _shortest_path(self, source_id, target_id):
        """Compatibility wrapper used by diagnostics and unit tests."""
        return list(self.planner.path_for(source_id, target_id))
