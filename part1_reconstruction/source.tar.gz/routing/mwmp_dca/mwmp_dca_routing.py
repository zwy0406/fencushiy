import copy
import math
import random
import simpy
from entities.packet import DataPacket, AckPacket
from simulator.log import logger
from utils import config
from utils.util_function import euclidean_distance_3d
from routing.dsdv.dsdv import Dsdv
from topology.mwmp_dca.cluster_packet import ClusterHelloPacket, ClusterAnnouncePacket, JoinRequestPacket, JoinAckPacket


class MwmpDcaRouting:
    def __init__(self, simulator, my_drone):
        self.simulator = simulator
        self.my_drone = my_drone
        self.rng_routing = random.Random(self.my_drone.identifier + self.my_drone.simulator.seed + 33)
        self.check_interval = 0.6 * 1e6
        self.waiting_list = []
        self.backbone_router = None
        self.backbone_router_role = None
        self.simulator.env.process(self.check_waiting_list())
        self.update_role(getattr(self.my_drone, 'cluster_role', 'CM'))

    def update_role(self, role):
        if role in ('CH', 'BR', 'BS'):
            if self._uses_bs_assisted_planner():
                if self.backbone_router is not None:
                    self.backbone_router.active = False
                self.backbone_router = None
                self.backbone_router_role = role
                return
            if self.backbone_router is None or not getattr(self.backbone_router, 'active', True):
                self.backbone_router = Dsdv(self.simulator, self.my_drone)
            self.backbone_router_role = role
        else:
            if self.backbone_router is not None:
                self.backbone_router.active = False

    def next_hop_selection(self, packet):
        if isinstance(packet, DataPacket):
            self._prepare_packet_state(packet)
            pinned_result = self._select_pinned_route_next_hop(packet)
            if pinned_result is not None:
                return pinned_result
            if packet.backbone_packet_recorded:
                self._record_packet_event_once(
                    packet,
                    'post_migration_repin_blocked_count',
                )
                self._record_migration_audit(
                    packet,
                    event='post_migration_repin_blocked',
                    trigger_reason=(
                        packet.migration_failure_reason or
                        packet.migration_reason
                    ),
                )
                return False, packet, False
            if self._is_backbone_node(self.my_drone):
                return self._select_backbone_next_hop(packet)

            if self.my_drone.cluster_role == 'CM':
                return self._select_cluster_member_next_hop(packet)

        if hasattr(packet, 'msg_type'):
            if packet.msg_type in ('cluster_hello', 'ch_announce'):
                packet.transmission_mode = 1
                return True, packet, False

        return False, packet, False

    def packet_reception(self, packet, src_drone_id):
        current_time = self.simulator.env.now
        yield self.simulator.env.timeout(0)

        if isinstance(packet, ClusterHelloPacket):
            self.my_drone.cluster_directory = getattr(self.my_drone, 'cluster_directory', {})
            self.my_drone.cluster_directory[packet.src_drone.identifier] = packet.src_drone
            return

        if isinstance(packet, ClusterAnnouncePacket):
            self.my_drone.cluster_directory = getattr(self.my_drone, 'cluster_directory', {})
            self.my_drone.cluster_directory[packet.src_drone.identifier] = packet.src_drone
            return

        if isinstance(packet, JoinRequestPacket):
            if self.my_drone.cluster_role == 'CH':
                packet.src_drone.cluster_head = self.my_drone
                packet.src_drone.cluster_id = self.my_drone.identifier
                ack_packet = JoinAckPacket(src_drone=self.my_drone,
                                           creation_time=current_time,
                                           packet_id=packet.packet_id,
                                           packet_length=config.HELLO_PACKET_LENGTH,
                                           simulator=self.simulator,
                                           channel_id=packet.channel_id,
                                           cluster_id=self.my_drone.identifier,
                                           payload={'cluster_head_id': self.my_drone.identifier})
                ack_packet.transmission_mode = 1
                self.my_drone.transmitting_queue.put(ack_packet)
            return

        if isinstance(packet, JoinAckPacket):
            packet.src_drone.cluster_head = self.simulator.drones[src_drone_id]
            packet.src_drone.cluster_id = src_drone_id
            return

        if isinstance(packet, DataPacket):
            packet_copy = copy.copy(packet)
            diagnostics = getattr(self.simulator.metrics, 'packet_diagnostics', None)
            if diagnostics is not None:
                diagnostics.copied(packet, packet_copy)
            if packet_copy.dst_drone.identifier == self.my_drone.identifier:
                if packet_copy.packet_id not in self.simulator.metrics.datapacket_arrived:
                    self.simulator.metrics.calculate_metrics(packet_copy)
                self._reply_ack(packet_copy, src_drone_id)
            else:
                self.my_drone.transmitting_queue.put(packet_copy)
                if diagnostics is not None:
                    diagnostics.enqueued(packet_copy, self.my_drone, current_time)
                self._reply_ack(packet_copy, src_drone_id)
            return

        if isinstance(packet, AckPacket):
            data_packet_acked = packet.ack_packet
            diagnostics = getattr(self.simulator.metrics, 'packet_diagnostics', None)
            if diagnostics is not None:
                diagnostics.ack_finished(data_packet_acked, self.my_drone, self.simulator.env.now, 'ack')
            self.simulator.metrics.mac_delay.append((self.simulator.env.now - data_packet_acked.first_attempt_time) / 1e3)
            self.my_drone.remove_from_queue(data_packet_acked)
            key2 = ''.join(['wait_ack', str(self.my_drone.identifier), '_', str(data_packet_acked.packet_id)])
            if self.my_drone.mac_protocol.wait_ack_process_finish.get(key2, 0) == 0:
                if key2 in self.my_drone.mac_protocol.wait_ack_process_dict and \
                        not self.my_drone.mac_protocol.wait_ack_process_dict[key2].triggered:
                    self.my_drone.mac_protocol.wait_ack_process_finish[key2] = 1
                    self.my_drone.mac_protocol.wait_ack_process_dict[key2].interrupt()
            return

        if self.backbone_router is not None:
            return self.backbone_router.packet_reception(packet, src_drone_id)

    def _reply_ack(self, packet_copy, src_drone_id):
        self.simulator.env.process(self._reply_ack_process(packet_copy, src_drone_id))

    def _reply_ack_process(self, packet_copy, src_drone_id):
        yield self.simulator.env.timeout(config.SIFS_DURATION)
        config.GL_ID_ACK_PACKET += 1
        src_drone = self.simulator.drones[src_drone_id]
        ack_packet = AckPacket(src_drone=self.my_drone,
                               dst_drone=src_drone,
                               ack_packet_id=config.GL_ID_ACK_PACKET,
                               ack_packet_length=config.ACK_PACKET_LENGTH,
                               ack_packet=packet_copy,
                               simulator=self.simulator,
                               channel_id=packet_copy.channel_id)
        if not self.my_drone.sleep:
            ack_packet.increase_ttl()
            self.my_drone.mac_protocol.phy.unicast(ack_packet, src_drone_id)
            yield self.simulator.env.timeout(ack_packet.packet_length / config.BIT_RATE * 1e6)

    def check_waiting_list(self):
        while True:
            if self.my_drone.sleep:
                break
            yield self.simulator.env.timeout(self.check_interval)
            for waiting_pkd in list(self.my_drone.waiting_list):
                if self.simulator.env.now > waiting_pkd.creation_time + waiting_pkd.deadline:
                    diagnostics = getattr(self.simulator.metrics, 'packet_diagnostics', None)
                    if diagnostics is not None:
                        diagnostics.dropped(waiting_pkd, self.my_drone, self.simulator.env.now, 'PacketLifetime')
                    self.my_drone.waiting_list.remove(waiting_pkd)
                    continue
                has_route, packet, enquire = self.next_hop_selection(waiting_pkd)
                if has_route:
                    self.my_drone.transmitting_queue.put(waiting_pkd)
                    diagnostics = getattr(self.simulator.metrics, 'packet_diagnostics', None)
                    if diagnostics is not None:
                        diagnostics.enqueued(waiting_pkd, self.my_drone, self.simulator.env.now)
                    self.my_drone.waiting_list.remove(waiting_pkd)

    def penalize(self, packet):
        self.my_drone.cluster_reselection_score = getattr(self.my_drone, 'cluster_reselection_score', 0) + 1

    def _select_cluster_member_next_hop(self, packet):
        cluster_head = getattr(self.my_drone, 'cluster_head', None)
        if cluster_head is None or cluster_head.identifier == self.my_drone.identifier:
            self._record_packet_event_once(packet, 'fallback_fail_missing_target_count')
            return False, packet, False

        if self._is_reachable_neighbor(cluster_head):
            packet.next_hop_id = cluster_head.identifier
            return True, packet, False

        backup_neighbor = self._choose_cm_local_backup(cluster_head, packet)
        if backup_neighbor is not None:
            self.simulator.metrics.record_routing_event('cm_local_backup_count')
            packet.next_hop_id = backup_neighbor.identifier
            return True, packet, False

        fallback_neighbor = self._choose_cm_fallback_neighbor(cluster_head, packet)
        if fallback_neighbor is not None:
            packet.next_hop_id = fallback_neighbor.identifier
            return True, packet, False

        return False, packet, False

    def _select_backbone_next_hop(self, packet):
        self._record_packet_event_once(packet, 'backbone_decision_count')
        target_drone = self._resolve_backbone_target(packet)
        if target_drone is None:
            self._record_packet_event_once(packet, 'fallback_fail_missing_target_count')
            self._record_packet_event_once(packet, 'backbone_fail_count')
            return False, packet, False

        if self._pin_packet_route(packet, target_drone, migration=False):
            pinned_result = self._select_pinned_route_next_hop(packet)
            if pinned_result is not None:
                self._record_packet_event_once(
                    packet,
                    'backbone_planned_count',
                )
                return pinned_result

        self.update_role(self.my_drone.cluster_role)
        backup_neighbor = self._choose_backbone_local_backup(target_drone, packet)
        if backup_neighbor is not None:
            self.simulator.metrics.record_routing_event('backbone_local_backup_count')
            self._record_packet_event_once(packet, 'backbone_backup_count')
            packet.next_hop_id = backup_neighbor.identifier
            return True, packet, False

        fallback_neighbor = self._choose_backbone_fallback_neighbor(target_drone, packet)
        if fallback_neighbor is not None:
            self._record_packet_event_once(packet, 'backbone_fallback_count')
            packet.next_hop_id = fallback_neighbor.identifier
            return True, packet, False

        self._record_packet_event_once(packet, 'backbone_fail_count')
        return False, packet, False

    def _pin_packet_route(self, packet, target_drone, migration):
        if migration:
            packet.migration_failure_reason = None
        cluster_manager = getattr(self.simulator, 'cluster_manager', None)
        planner = getattr(cluster_manager, 'backbone_planner', None)
        if planner is None:
            if migration:
                packet.migration_failure_reason = 'PLANNER_MISSING'
            self._record_packet_event_once(
                packet,
                'planned_route_missing_planner_count',
            )
            return False
        snapshot = planner.active_snapshot
        forbidden = set(packet.visited_nodes) - {self.my_drone.identifier}
        if migration or forbidden:
            path = planner.path_for(
                self.my_drone.identifier,
                target_drone.identifier,
                forbidden_ids=forbidden,
            )
            if not migration:
                self._record_packet_event_once(
                    packet,
                    'initial_pin_visited_aware_count',
                )
        else:
            path = planner.planned_path_for(
                self.my_drone.identifier,
                target_drone.identifier,
            )
        if not path:
            if migration:
                packet.migration_failure_reason = 'NO_PATH'
            if self.my_drone.identifier not in snapshot.routes:
                self._record_packet_event_once(
                    packet,
                    'planned_route_missing_source_count',
                )
            else:
                self._record_packet_event_once(
                    packet,
                    'planned_route_missing_target_count',
                )
            return False

        path = tuple(path)
        destination_id = packet.dst_drone.identifier
        if target_drone.identifier != destination_id:
            if (
                getattr(packet.dst_drone, 'sleep', False)
                or not self._is_reachable_between(target_drone, packet.dst_drone)
            ):
                if migration:
                    packet.migration_failure_reason = (
                        'DESTINATION_UNREACHABLE'
                    )
                self._record_packet_event_once(
                    packet,
                    'pinned_destination_unreachable_count',
                )
                return False
            path = path + (destination_id,)
        rejected_nodes = sorted(
            node_id for node_id in path[1:] if node_id in forbidden
        )
        if len(path) < 2 or rejected_nodes:
            if migration:
                packet.migration_failure_reason = 'VISITED_CONFLICT'
            diagnostics = getattr(self.simulator.metrics, 'packet_diagnostics', None)
            if diagnostics is not None:
                diagnostics.note_failure(packet, 'LoopReject')
            self._record_packet_event_once(
                packet,
                'pinned_path_visited_conflict_count',
            )
            self._record_migration_audit(
                packet,
                event='visited_path_conflict',
                requested_target=target_drone.identifier,
                candidate_path=path,
                rejected_nodes=rejected_nodes,
            )
            return False

        packet.route_epoch = snapshot.epoch
        packet.route_version = snapshot.epoch
        packet.mwmp_route_epoch = snapshot.epoch
        packet.pinned_path = path
        packet.authorized_pinned_path = path
        packet.routing_path = list(path)
        packet.route_cursor = 0
        if packet.original_backbone_target is None:
            packet.original_backbone_target = target_drone.identifier
        if not packet.backbone_packet_recorded:
            self.simulator.metrics.record_routing_event(
                'backbone_packet_count',
            )
            packet.backbone_packet_recorded = True
        self.simulator.metrics.record_routing_event(
            'pinned_route_created_count',
        )
        return True

    def _select_pinned_route_next_hop(self, packet):
        path = getattr(packet, 'pinned_path', None)
        if not path:
            return None
        authorized_path = getattr(packet, 'authorized_pinned_path', None)
        if authorized_path is not None and tuple(path) != tuple(authorized_path):
            self._record_packet_event_once(
                packet,
                'unauthorized_pinned_path_change_count',
            )
            self._record_migration_audit(
                packet,
                event='unauthorized_path_change',
                candidate_path=path,
            )
        current_id = self.my_drone.identifier
        try:
            cursor = path.index(current_id)
        except ValueError:
            return self._migrate_pinned_route(
                packet,
                'CONNECTIVITY_INVALID',
            )
        packet.route_cursor = cursor
        if cursor >= len(path) - 1:
            packet.pinned_path = None
            return None

        self._record_packet_event_once(packet, 'pinned_hop_attempt_count')
        cluster_manager = getattr(self.simulator, 'cluster_manager', None)
        planner = getattr(cluster_manager, 'backbone_planner', None)
        active_epoch = getattr(
            getattr(planner, 'active_snapshot', None),
            'epoch',
            None,
        )
        if (
            active_epoch is not None
            and packet.route_epoch is not None
            and packet.route_epoch < active_epoch
        ):
            self._record_packet_event_once(packet, 'epoch_aged_packet_count')

        if (
            not self._is_backbone_node(self.my_drone)
            and current_id not in (
                packet.src_drone.identifier,
                packet.dst_drone.identifier,
            )
        ):
            packet.legacy_forward_count += 1
            self._record_packet_event_once(packet, 'legacy_forward_count')

        next_hop_id = path[cursor + 1]
        if next_hop_id in packet.visited_nodes:
            self._record_packet_event_once(
                packet,
                'planned_route_loop_reject_count',
            )
            return self._migrate_pinned_route(
                packet,
                'CONNECTIVITY_INVALID',
            )
        if next_hop_id < 0 or next_hop_id >= len(self.simulator.drones):
            return self._migrate_pinned_route(
                packet,
                'CONNECTIVITY_INVALID',
            )
        next_hop = self.simulator.drones[next_hop_id]
        if getattr(next_hop, 'sleep', False):
            return self._migrate_pinned_route(packet, 'NEXT_HOP_SLEEP')
        if not self._is_reachable_neighbor(next_hop):
            return self._migrate_pinned_route(
                packet,
                'NEXT_HOP_UNREACHABLE',
            )
        if next_hop_id != path[-1]:
            energy_ratio = (
                next_hop.residual_energy /
                max(1.0, float(config.INITIAL_ENERGY))
            )
            if energy_ratio <= config.BACKBONE_RELAY_MIN_ENERGY_RATIO:
                return self._migrate_pinned_route(
                    packet,
                    'ENERGY_EMERGENCY',
                )
            tlet_ratio = min(
                1.0,
                getattr(next_hop, 'avg_let', 0.0) /
                max(1.0, float(config.PREDICTION_HORIZON)),
            )
            if tlet_ratio <= config.BACKBONE_RELAY_MIN_TLET_RATIO:
                return self._migrate_pinned_route(
                    packet,
                    'TLET_EMERGENCY',
                )

        packet.next_hop_id = next_hop_id
        self._record_packet_event_once(packet, 'pinned_hop_selected_count')
        return True, packet, False

    def _migrate_pinned_route(self, packet, reason):
        self._record_packet_event_once(packet, 'pinned_route_invalid_count')
        self._record_packet_event_once(
            packet,
            f'pinned_invalid_{reason.lower()}_count',
        )
        if packet.migration_count >= 1:
            diagnostics = getattr(self.simulator.metrics, 'packet_diagnostics', None)
            if diagnostics is not None:
                diagnostics.note_failure(packet, 'MigrationExhausted')
            self._record_packet_event_once(
                packet,
                'migration_exhausted_count',
            )
            self._record_packet_event_once(
                packet,
                'migration_exhausted_already_used_count',
            )
            exhausted_reason = {
                'NEXT_HOP_UNREACHABLE': 'physical_disconnect',
                'NEXT_HOP_SLEEP': 'physical_disconnect',
                'TLET_EMERGENCY': 'tlet_emergency',
                'ENERGY_EMERGENCY': 'energy_emergency',
                'CONNECTIVITY_INVALID': 'connectivity_invalid',
            }.get(reason, 'connectivity_invalid')
            self._record_packet_event_once(
                packet,
                f'migration_exhausted_{exhausted_reason}_count',
            )
            self._record_migration_audit(
                packet,
                event='migration_exhausted',
                trigger_reason=reason,
            )
            return False, packet, False

        packet.migration_count += 1
        packet.migration_reason = reason
        previous_epoch = packet.route_epoch
        self.simulator.metrics.record_routing_event('migration_attempt_count')
        target_drone = self._resolve_backbone_target(packet)
        self._record_migration_audit(
            packet,
            event='migration_attempt',
            trigger_reason=reason,
            requested_target=(
                target_drone.identifier if target_drone is not None else None
            ),
        )
        if target_drone is None:
            packet.migration_failure_reason = 'TARGET_INVALID'
        if (
            target_drone is not None
            and self._pin_packet_route(packet, target_drone, migration=True)
        ):
            self.simulator.metrics.record_routing_event(
                'migration_success_count',
            )
            if packet.route_epoch != previous_epoch:
                self.simulator.metrics.record_routing_event(
                    'mid_route_epoch_switch_count',
                )
            if not packet.migration_packet_recorded:
                self.simulator.metrics.record_routing_event(
                    'migrated_packet_count',
                )
                packet.migration_packet_recorded = True
            self._record_migration_audit(
                packet,
                event='migration_success',
                trigger_reason=reason,
                requested_target=target_drone.identifier,
                candidate_path=packet.pinned_path,
            )
            return self._select_pinned_route_next_hop(packet)

        packet.pinned_path = None
        failure_reason = packet.migration_failure_reason or 'NO_PATH'
        failure_key = {
            'NO_PATH': 'no_path',
            'TARGET_INVALID': 'target_invalid',
            'VISITED_CONFLICT': 'visited_conflict',
            'DESTINATION_UNREACHABLE': 'destination_unreachable',
            'PLANNER_MISSING': 'planner_missing',
        }.get(failure_reason, 'no_path')
        self.simulator.metrics.record_routing_event(
            f'migration_fail_{failure_key}_count'
        )
        self.simulator.metrics.record_routing_event('migration_failed_count')
        self._record_migration_audit(
            packet,
            event='migration_failed',
            trigger_reason=reason,
            requested_target=(
                target_drone.identifier if target_drone is not None else None
            ),
            failure_reason=failure_reason,
        )
        return False, packet, False

    def _select_backbone_primary_next_hop(self, target_drone, packet):
        cluster_manager = getattr(self.simulator, 'cluster_manager', None)
        planner = getattr(cluster_manager, 'backbone_planner', None)
        if planner is None:
            self._record_packet_event_once(packet, 'planned_route_missing_planner_count')
            return None
        snapshot = getattr(planner, 'active_snapshot', None)
        backbone_epoch = (
            getattr(snapshot, 'epoch', None)
            if snapshot is not None
            else getattr(planner, 'snapshot_epoch', None)
        )
        cluster_epoch = getattr(cluster_manager, 'round_counter', None)
        packet_epoch = getattr(packet, 'mwmp_route_epoch', None)
        if packet_epoch is None:
            packet.mwmp_route_epoch = backbone_epoch
        elif backbone_epoch is not None and packet_epoch != backbone_epoch:
            self._record_packet_event_once(packet, 'stale_snapshot_count')
        if (
            backbone_epoch is not None and cluster_epoch is not None
            and backbone_epoch != cluster_epoch
        ):
            self._record_packet_event_once(packet, 'backbone_cluster_epoch_mismatch_count')
        planner_routes = (
            snapshot.routes
            if snapshot is not None
            else getattr(planner, 'last_routes', {})
        )
        source_routes = planner_routes.get(self.my_drone.identifier)
        if source_routes is None:
            self._record_packet_event_once(packet, 'planned_route_missing_source_count')
            return None
        if target_drone.identifier not in source_routes:
            self._record_packet_event_once(packet, 'planned_route_missing_target_count')
            return None
        planned_next_hop_id = source_routes[target_drone.identifier]
        planned_next_hop, invalid_reason = self._validate_backbone_next_hop(
            planned_next_hop_id,
            target_drone,
            packet,
        )
        if planned_next_hop is not None:
            return planned_next_hop
        if invalid_reason:
            self._record_packet_event_once(
                packet,
                f'planned_route_{invalid_reason}_count',
            )
        return None

    def _prepare_packet_state(self, packet):
        if not hasattr(packet, 'forwarding_path'):
            packet.forwarding_path = []
        if not packet.forwarding_path or packet.forwarding_path[-1] != self.my_drone.identifier:
            packet.forwarding_path.append(self.my_drone.identifier)
        endpoint_ids = {
            packet.src_drone.identifier,
            packet.dst_drone.identifier,
        }
        if self.my_drone.identifier not in endpoint_ids:
            packet.passed_ch = bool(getattr(packet, 'passed_ch', False) or self.my_drone.cluster_role == 'CH')
            packet.passed_br = bool(getattr(packet, 'passed_br', False) or getattr(self.my_drone, 'is_backbone_connector', False))
        if self.my_drone.identifier not in packet.intermediate_drones:
            packet.intermediate_drones.append(self.my_drone.identifier)
        if not hasattr(packet, 'mwmp_recorded_events'):
            packet.mwmp_recorded_events = set()
        if not hasattr(packet, 'mwmp_fallback_used'):
            packet.mwmp_fallback_used = False
        if not hasattr(packet, 'mwmp_route_epoch'):
            packet.mwmp_route_epoch = None
        defaults = {
            'route_epoch': None,
            'route_version': None,
            'pinned_path': None,
            'route_cursor': 0,
            'original_backbone_target': None,
            'visited_nodes': set(),
            'migration_count': 0,
            'migration_reason': None,
            'migration_failure_reason': None,
            'authorized_pinned_path': None,
            'legacy_forward_count': 0,
            'backbone_packet_recorded': False,
            'migration_packet_recorded': False,
        }
        for name, value in defaults.items():
            if not hasattr(packet, name):
                setattr(packet, name, value)
        packet.visited_nodes.update(packet.intermediate_drones)
        packet.visited_nodes.add(self.my_drone.identifier)

    def _resolve_backbone_target(self, packet):
        if getattr(packet.dst_drone, 'is_base_station', False):
            return packet.dst_drone
        dst_cluster_head = getattr(packet.dst_drone, 'cluster_head', None)
        if dst_cluster_head is not None:
            return dst_cluster_head
        return None

    def _record_migration_audit(
        self,
        packet,
        *,
        event,
        trigger_reason=None,
        requested_target=None,
        candidate_path=None,
        rejected_nodes=None,
        failure_reason=None,
    ):
        recorder = getattr(
            self.simulator.metrics,
            'record_migration_audit',
            None,
        )
        if recorder is None:
            return
        old_path = tuple(getattr(packet, 'pinned_path', ()) or ())
        current_id = self.my_drone.identifier
        next_hop_id = None
        if current_id in old_path:
            cursor = old_path.index(current_id)
            if cursor + 1 < len(old_path):
                next_hop_id = old_path[cursor + 1]
        distance = None
        noise_only_snr = None
        if (
            next_hop_id is not None
            and 0 <= next_hop_id < len(self.simulator.drones)
        ):
            next_hop = self.simulator.drones[next_hop_id]
            distance = euclidean_distance_3d(
                self.my_drone.coords,
                next_hop.coords,
            )
            if distance == 0:
                noise_only_snr = float('inf')
            else:
                path_loss = (
                    config.LIGHT_SPEED /
                    (4 * math.pi * config.CARRIER_FREQUENCY * distance)
                ) ** 2
                noise_only_snr = 10 * math.log10(
                    config.TRANSMITTING_POWER * path_loss /
                    config.NOISE_POWER
                )

        def encode(values):
            if values is None:
                return ''
            return '|'.join(str(value) for value in values)

        active_epoch = getattr(
            getattr(
                getattr(self.simulator, 'cluster_manager', None),
                'backbone_planner',
                None,
            ),
            'active_snapshot',
            None,
        )
        recorder(
            time_us=self.simulator.env.now,
            event=event,
            packet_id=packet.packet_id,
            source_id=packet.src_drone.identifier,
            destination_id=packet.dst_drone.identifier,
            destination_is_bs=bool(
                getattr(packet.dst_drone, 'is_base_station', False)
            ),
            current_node=current_id,
            trigger_reason=trigger_reason or '',
            failure_reason=failure_reason or '',
            route_epoch=getattr(packet, 'route_epoch', None),
            active_epoch=getattr(active_epoch, 'epoch', None),
            migration_count=getattr(packet, 'migration_count', 0),
            original_backbone_target=getattr(
                packet,
                'original_backbone_target',
                None,
            ),
            requested_target=requested_target,
            old_pinned_path=encode(old_path),
            visited_nodes=encode(sorted(packet.visited_nodes)),
            candidate_path=encode(candidate_path),
            rejected_nodes=encode(rejected_nodes),
            next_hop_id=next_hop_id,
            next_hop_distance_m=distance,
            communication_range_m=config.COMMUNICATION_RANGE,
            noise_only_snr_db=noise_only_snr,
            snr_threshold_db=config.SNR_THRESHOLD,
        )

    def _valid_backbone_next_hop(self, next_hop_id, target_drone, packet):
        next_hop, _ = self._validate_backbone_next_hop(
            next_hop_id,
            target_drone,
            packet,
        )
        return next_hop

    def _validate_backbone_next_hop(self, next_hop_id, target_drone, packet):
        if next_hop_id is None or next_hop_id == self.my_drone.identifier:
            return None, 'invalid_next_hop'
        if next_hop_id in packet.intermediate_drones:
            return None, 'loop_reject'
        if next_hop_id < 0 or next_hop_id >= len(self.simulator.drones):
            return None, 'invalid_next_hop'
        next_hop = self.simulator.drones[next_hop_id]
        if not self._is_reachable_neighbor(next_hop):
            return None, 'next_hop_unreachable'
        if not self._is_backbone_node(next_hop) and next_hop.identifier != target_drone.identifier:
            return None, 'role_invalid'
        return next_hop, None

    @staticmethod
    def _uses_bs_assisted_planner():
        return (
            config.MWMP_DECISION_MODE == 'proposed' and
            config.USE_BACKBONE_CONNECTORS
        )

    def _choose_cm_local_backup(self, cluster_head, packet):
        if not config.CH_ONLY_ENABLE_LOCAL_BACKUP:
            return None

        def is_candidate(candidate):
            if candidate.identifier in packet.intermediate_drones:
                return False
            candidate_head = getattr(candidate, 'cluster_head', None)
            if candidate_head is None:
                return False
            if candidate_head.identifier != cluster_head.identifier:
                return False
            return self._is_reachable_between(candidate, cluster_head)

        return self._select_best_neighbor(
            target_drone=cluster_head,
            packet=packet,
            predicate=is_candidate,
            prefer_backbone=False,
        )

    def _choose_cm_fallback_neighbor(self, cluster_head, packet):
        if not config.CH_ONLY_ENABLE_NEIGHBOR_FALLBACK:
            return None
        if self._mark_fallback_attempt(packet):
            return None

        def is_candidate(candidate):
            if candidate.identifier in packet.intermediate_drones:
                return False
            return self._is_backbone_node(candidate)

        neighbor = self._select_best_neighbor(
            target_drone=cluster_head,
            packet=packet,
            predicate=is_candidate,
            prefer_backbone=True,
        )
        if neighbor is None:
            self._record_packet_event_once(packet, 'fallback_fail_no_candidate_count')
            return None
        packet.mwmp_fallback_used = True
        self.simulator.metrics.record_routing_event('fallback_success_count')
        return neighbor

    def _choose_backbone_local_backup(self, target_drone, packet):
        if not config.CH_ONLY_ENABLE_LOCAL_BACKUP:
            return None

        def is_candidate(candidate):
            if candidate.identifier in packet.intermediate_drones:
                return False
            return self._is_backbone_node(candidate)

        return self._select_best_neighbor(
            target_drone=target_drone,
            packet=packet,
            predicate=is_candidate,
            prefer_backbone=True,
        )

    def _choose_backbone_fallback_neighbor(self, target_drone, packet):
        if not config.CH_ONLY_ENABLE_NEIGHBOR_FALLBACK:
            return None
        if self._mark_fallback_attempt(packet):
            return None

        def is_candidate(candidate):
            if candidate.identifier in packet.intermediate_drones:
                return False
            if (
                getattr(candidate, 'cluster_role', None) != 'CM'
                or getattr(candidate, 'is_backbone_connector', False)
            ):
                return False
            candidate_head = getattr(candidate, 'cluster_head', None)
            if candidate_head is None or candidate_head.identifier != target_drone.identifier:
                return False
            return self._is_reachable_between(candidate, target_drone)

        neighbor = self._select_best_neighbor(
            target_drone=target_drone,
            packet=packet,
            predicate=is_candidate,
            prefer_backbone=False,
        )
        if neighbor is None:
            self._record_packet_event_once(packet, 'fallback_fail_no_candidate_count')
            return None
        packet.mwmp_fallback_used = True
        self.simulator.metrics.record_routing_event('fallback_success_count')
        return neighbor

    def _mark_fallback_attempt(self, packet):
        self._record_packet_event_once(packet, 'fallback_attempt_count')
        if getattr(packet, 'mwmp_fallback_used', False):
            self._record_packet_event_once(packet, 'fallback_fail_already_used_count')
            return True
        return False

    def _record_packet_event_once(self, packet, event_name):
        event_key = (self.my_drone.identifier, event_name)
        if event_key in packet.mwmp_recorded_events:
            return False
        packet.mwmp_recorded_events.add(event_key)
        self.simulator.metrics.record_routing_event(event_name)
        return True

    def _select_best_neighbor(self, target_drone, packet, predicate, prefer_backbone):
        best_neighbor = None
        best_score = None
        current_distance = euclidean_distance_3d(self.my_drone.coords, target_drone.coords)
        for candidate in self._reachable_neighbors():
            if not predicate(candidate):
                continue
            candidate_distance = euclidean_distance_3d(candidate.coords, target_drone.coords)
            progress = current_distance - candidate_distance
            if candidate.identifier != target_drone.identifier and progress < config.CH_ONLY_PROGRESS_THRESHOLD:
                continue
            score = self._score_neighbor(candidate, target_drone, progress, prefer_backbone)
            if best_score is None or score > best_score:
                best_neighbor = candidate
                best_score = score
        return best_neighbor

    def _reachable_neighbors(self):
        neighbors = []
        for drone in self.simulator.drones:
            if drone.identifier == self.my_drone.identifier:
                continue
            if getattr(drone, 'sleep', False):
                continue
            if self._is_reachable_neighbor(drone):
                neighbors.append(drone)
        return neighbors

    def _score_neighbor(self, candidate, target_drone, progress, prefer_backbone):
        energy_ratio = getattr(candidate, 'residual_energy', 0.0) / max(1.0, float(config.INITIAL_ENERGY))
        let_score = float(getattr(candidate, 'avg_let', 0.0))
        distance_bonus = max(
            0.0,
            (config.COMMUNICATION_RANGE - euclidean_distance_3d(self.my_drone.coords, candidate.coords)) / max(1.0, config.COMMUNICATION_RANGE),
        )
        score = progress + 0.2 * energy_ratio + 0.05 * let_score + 0.1 * distance_bonus
        if candidate.identifier == target_drone.identifier:
            score += 100.0
        if prefer_backbone and self._is_backbone_node(candidate):
            score += 10.0
        return score

    @staticmethod
    def _is_backbone_node(drone):
        return (
            getattr(drone, 'cluster_role', None) in ('CH', 'BS')
            or getattr(drone, 'is_backbone_connector', False)
        )

    def _is_reachable_neighbor(self, drone):
        return self._is_reachable_between(self.my_drone, drone)

    def _is_reachable_between(self, src_drone, dst_drone):
        if getattr(src_drone, 'sleep', False) or getattr(dst_drone, 'sleep', False):
            return False
        return euclidean_distance_3d(src_drone.coords, dst_drone.coords) <= config.COMMUNICATION_RANGE
