import queue
import unittest
from unittest.mock import patch

import simpy
from types import SimpleNamespace

from topology.mwmp_dca.predictor import (
    CurrentOnlyTrajectoryPredictor, KinematicTrajectoryPredictor,
    LstmTrajectoryPredictor, OracleTrajectoryPredictor,
)
from topology.mwmp_dca.recent_baselines import TdcMopsoSelector, select_mdcs_heads
from topology.mwmp_dca.backbone_planner import BackbonePlanner
from topology.mwmp_dca.cluster_metrics import ClusterMetrics
from topology.mwmp_dca.cluster_manager import ClusterManager
from topology.mwmp_dca.cluster_rotation import ClusterRotationManager
from topology.mwmp_dca.trajectory_let_calculator import trajectory_based_let
from topology.mwmp_dca.weight_calculator import WeightCalculator
from topology.mwmp_dca.link_reliability import LinkReliabilityTracker
from routing.mwmp_dca.mwmp_dca_routing import MwmpDcaRouting
from routing.torp_like.torp_like import TorpLikePlanner, TorpLikeRouting
from experiments.e7_profiles import E7_PROFILES
from experiments.frozen_methods import apply_frozen_method
from energy.energy_accounting import is_role_energy
from entities.drone import Drone, EventQueue
from entities.packet import DataPacket
from phy.channel import Channel
from phy.phy import Phy
from simulator.metrics import Metrics
from simulator.packet_diagnostics import PacketDiagnostics
from utils import config


class MwmpDcaUnitTests(unittest.TestCase):
    def test_packet_diagnostics_conserves_delivered_delay_across_roles(self):
        class Roles:
            @staticmethod
            def _role_label(drone):
                return drone.role

        diagnostics = PacketDiagnostics(Roles())
        cm = SimpleNamespace(identifier=1, role='CM')
        ch = SimpleNamespace(identifier=2, role='CH')
        packet = SimpleNamespace(packet_id=7, deadline=10000, route_epoch=1)
        diagnostics.generated(packet, cm, 0)
        diagnostics.enqueued(packet, cm, 0)
        diagnostics.dequeued(packet, cm, 100)
        diagnostics.buffer_requested(packet, cm, 150)
        diagnostics.mac_started(packet, cm, 200, 1)
        diagnostics.tx_started(packet, cm, 300)
        diagnostics.tx_ended(packet, cm, 400)
        diagnostics.enqueued(packet, ch, 400)
        diagnostics.dequeued(packet, ch, 500)
        diagnostics.buffer_requested(packet, ch, 600)
        diagnostics.mac_started(packet, ch, 650, 1)
        diagnostics.tx_started(packet, ch, 700)
        diagnostics.delivered(packet, 800)
        summary = diagnostics.summary(800)
        self.assertEqual(summary['packet_diag_max_delay_error_us'], 0)
        self.assertAlmostEqual(summary['delay_queue_CM_mean_ms'], 0.15)
        self.assertAlmostEqual(summary['delay_queue_CH_mean_ms'], 0.15)
        self.assertEqual(summary['packet_diag_delivered'], 1)

    def test_packet_diagnostics_separates_terminal_drop_from_horizon(self):
        class Roles:
            @staticmethod
            def _role_label(drone):
                return drone.role

        diagnostics = PacketDiagnostics(Roles())
        cm = SimpleNamespace(identifier=1, role='CM')
        dropped = SimpleNamespace(packet_id=1, deadline=1000)
        pending = SimpleNamespace(packet_id=2, deadline=1000)
        diagnostics.generated(dropped, cm, 0)
        diagnostics.dropped(dropped, cm, 0, 'QueueOverflow')
        diagnostics.generated(pending, cm, 0)
        summary = diagnostics.summary(500)
        self.assertEqual(summary['drop_QueueOverflow'], 1)
        self.assertEqual(summary['drop_Other'], 0)
        self.assertEqual(summary['drop_role_CM'], 1)
        self.assertEqual(summary['packet_diag_terminal_drops'], 1)
        self.assertEqual(summary['packet_diag_incomplete_at_horizon'], 1)

    def test_packet_queue_time_uses_role_at_service(self):
        class Roles:
            @staticmethod
            def _role_label(drone):
                return drone.role

        diagnostics = PacketDiagnostics(Roles())
        drone = SimpleNamespace(identifier=1, role='CM')
        packet = SimpleNamespace(packet_id=3, deadline=1000, route_epoch=1)
        diagnostics.generated(packet, drone, 0)
        diagnostics.enqueued(packet, drone, 0)
        drone.role = 'CH'
        diagnostics.dequeued(packet, drone, 100)
        diagnostics.buffer_requested(packet, drone, 100)
        diagnostics.mac_started(packet, drone, 200, 1)
        diagnostics.delivered(packet, 200)
        summary = diagnostics.summary(200)
        self.assertEqual(summary['delay_queue_CM_mean_ms'], 0)
        self.assertAlmostEqual(summary['delay_queue_CH_mean_ms'], 0.2)
        self.assertEqual(diagnostics.hops[0]['role_at_service'], 'CH')

    def test_packet_hop_events_match_transmission_attempts(self):
        class Roles:
            @staticmethod
            def _role_label(drone):
                return drone.role

        diagnostics = PacketDiagnostics(Roles())
        drone = SimpleNamespace(identifier=1, role='CH')
        packet = SimpleNamespace(packet_id=4, deadline=1000, route_epoch=1)
        diagnostics.generated(packet, drone, 0)
        diagnostics.enqueued(packet, drone, 0)
        diagnostics.dequeued(packet, drone, 10)
        diagnostics.mac_started(packet, drone, 20, 1)
        packet._phy_tx_attempt = 1
        diagnostics.tx_started(packet, drone, 30)
        diagnostics.tx_ended(packet, drone, 40)
        diagnostics.ack_finished(packet, drone, 50, 'timeout')
        diagnostics.mac_started(packet, drone, 60, 2)
        packet._phy_tx_attempt = 2
        diagnostics.tx_started(packet, drone, 70)
        diagnostics.tx_ended(packet, drone, 80)
        diagnostics.ack_finished(packet, drone, 90, 'ack')
        self.assertEqual(len(diagnostics.hops), 2)
        self.assertEqual(
            [(hop['tx_start_time'], hop['tx_end_time'], hop['ack_end_or_timeout_time'])
             for hop in diagnostics.hops],
            [(30, 40, 50), (70, 80, 90)],
        )

    def test_packet_queue_role_excludes_unserved_copy(self):
        class Roles:
            @staticmethod
            def _role_label(drone):
                return drone.role

        diagnostics = PacketDiagnostics(Roles())
        sender = SimpleNamespace(identifier=1, role='CM')
        receiver = SimpleNamespace(identifier=2, role='CH')
        packet = SimpleNamespace(packet_id=5, deadline=1000, route_epoch=1)
        copy = SimpleNamespace(packet_id=5, deadline=1000, route_epoch=1)
        diagnostics.generated(packet, sender, 0)
        diagnostics.copied(packet, copy)
        diagnostics.enqueued(packet, sender, 0)
        diagnostics.dequeued(packet, sender, 10)
        diagnostics.enqueued(copy, receiver, 20)
        diagnostics.buffer_requested(packet, sender, 30)
        diagnostics.mac_started(packet, sender, 40, 2)
        diagnostics.delivered(packet, 50)
        summary = diagnostics.summary(50)
        self.assertEqual(summary['packet_diag_max_delay_error_us'], 0)
        self.assertEqual(summary['delay_queue_CH_mean_ms'], 0)
        self.assertAlmostEqual(summary['delay_queue_CM_mean_ms'], 0.02)
        self.assertAlmostEqual(summary['delay_other_mean_ms'], 0.01)
        self.assertEqual(diagnostics.hops[1]['outcome'], 'pending')

    def test_packet_queue_prefers_served_downstream_copy(self):
        class Roles:
            @staticmethod
            def _role_label(drone):
                return drone.role

        diagnostics = PacketDiagnostics(Roles())
        sender = SimpleNamespace(identifier=1, role='CM')
        receiver = SimpleNamespace(identifier=2, role='CM')
        packet = SimpleNamespace(packet_id=6, deadline=1000, route_epoch=1)
        child = SimpleNamespace(packet_id=6, deadline=1000, route_epoch=1)
        diagnostics.generated(packet, sender, 0)
        diagnostics.enqueued(packet, sender, 0)
        diagnostics.dequeued(packet, sender, 10)
        diagnostics.copied(packet, child)
        diagnostics.enqueued(child, receiver, 20)
        diagnostics.buffer_requested(packet, sender, 30)
        diagnostics.mac_started(packet, sender, 40, 2)
        receiver.role = 'CH'
        diagnostics.dequeued(child, receiver, 100)
        diagnostics.delivered(child, 120)
        summary = diagnostics.summary(120)
        self.assertEqual(summary['packet_diag_max_delay_error_us'], 0)
        self.assertAlmostEqual(summary['delay_queue_CM_mean_ms'], 0.01)
        self.assertAlmostEqual(summary['delay_queue_CH_mean_ms'], 0.08)
        self.assertTrue(diagnostics.hops[1]['on_delivery_path'])
        self.assertEqual(diagnostics.hops[1]['role_at_service'], 'CH')

    def test_e7_profiles_and_follow_up_combinations(self):
        self.assertEqual(list(E7_PROFILES), [
            'A0_ORIGINAL', 'A1_FORMAL_SCORE', 'A2_SERVICE_GUARD',
            'A3_PREDICTIVE_BACKBONE', 'A4_CONDITIONAL_HOLD',
            'B0_SCORE_BACKBONE', 'B1_SCORE_BACKBONE_HOLD',
        ])
        self.assertFalse(E7_PROFILES['A1_FORMAL_SCORE']['flags']['USE_SERVICE_GUARD'])
        self.assertTrue(E7_PROFILES['A2_SERVICE_GUARD']['flags']['USE_SERVICE_GUARD'])
        self.assertFalse(E7_PROFILES['A2_SERVICE_GUARD']['flags']['USE_BACKBONE_CONNECTORS'])
        self.assertTrue(E7_PROFILES['A3_PREDICTIVE_BACKBONE']['flags']['USE_BACKBONE_CONNECTORS'])
        self.assertEqual(E7_PROFILES['A3_PREDICTIVE_BACKBONE']['flags']['BACKBONE_RELAY_HOLD_ROUNDS'], 0)
        self.assertEqual(E7_PROFILES['A4_CONDITIONAL_HOLD']['flags']['BACKBONE_RELAY_HOLD_ROUNDS'], 3)
        for name, hold_rounds in (
            ('B0_SCORE_BACKBONE', 0),
            ('B1_SCORE_BACKBONE_HOLD', 3),
        ):
            flags = E7_PROFILES[name]['flags']
            self.assertEqual(E7_PROFILES[name]['method'], 'PROPOSED')
            self.assertFalse(flags['USE_SERVICE_GUARD'])
            self.assertTrue(flags['USE_BACKBONE_CONNECTORS'])
            self.assertEqual(flags['BACKBONE_RELAY_HOLD_ROUNDS'], hold_rounds)

    def test_service_guard_can_be_disabled_without_changing_network_score(self):
        calculator = WeightCalculator(profile_name='W2')
        original = config.USE_SERVICE_GUARD
        try:
            config.USE_SERVICE_GUARD = False
            self.assertAlmostEqual(calculator.service_utility(0.73, 0.95), 0.73)
            config.USE_SERVICE_GUARD = True
            self.assertNotAlmostEqual(calculator.service_utility(0.73, 0.95), 0.73)
        finally:
            config.USE_SERVICE_GUARD = original

    def test_trajectory_let_stops_when_link_breaks(self):
        traj_a = [(0, 0, 0), (10, 0, 0), (20, 0, 0)]
        traj_b = [(0, 0, 0), (15, 0, 0), (300, 0, 0)]
        self.assertEqual(trajectory_based_let(traj_a, traj_b, communication_range=20), 2.0)

    def test_weight_prefers_stable_high_energy_node(self):
        calculator = WeightCalculator(profile_name='W2')
        high = calculator.score(1.0, 0.9, 0.7, 1.0, 0.1, poi_ratio=0.5)
        low = calculator.score(0.2, 0.2, 0.2, 0.1, 0.9, poi_ratio=0.0)
        self.assertGreater(high, low)

    def test_backoff_is_shorter_for_higher_weight(self):
        high_weight = 0.9
        low_weight = 0.2
        high_backoff = config.CLUSTER_BACKOFF_MAX * (1.0 - high_weight)
        low_backoff = config.CLUSTER_BACKOFF_MAX * (1.0 - low_weight)
        self.assertLess(high_backoff, low_backoff)

    def test_adaptive_backoff_uses_only_local_score_distribution(self):
        class ZeroJitter:
            @staticmethod
            def uniform(_low, _high):
                return 0.0

        manager = object.__new__(ClusterManager)
        manager.rng = ZeroJitter()
        manager.metrics = SimpleNamespace(record_backoff_time=lambda _value: None)
        drones = [SimpleNamespace(identifier=index) for index in range(3)]
        neighbor_map = {0: [drones[1]], 1: [drones[0]], 2: []}
        scores = {0: 0.2, 1: 0.4, 2: 1.0}
        _, _, backoffs = manager._elect_adaptive_backoff(
            drones, neighbor_map, scores
        )
        self.assertEqual(backoffs[1], 0.0)
        self.assertEqual(backoffs[0], config.CLUSTER_BACKOFF_MAX)
        self.assertEqual(backoffs[2], config.CLUSTER_BACKOFF_MAX * 0.5)

    def test_predictors_return_prediction_horizon(self):
        drone = SimpleNamespace(
            coords=(10, 10, 10),
            velocity=(1, 2, 0),
            trajectory_history=[
                {'coords': (10, 10, 10), 'velocity': (1, 2, 0)},
                {'coords': (11, 12, 10), 'velocity': (1, 2, 0)},
                {'coords': (12, 14, 10), 'velocity': (1, 2, 0)},
            ],
        )
        self.assertEqual(len(KinematicTrajectoryPredictor().predict(drone, 5)), 5)
        self.assertEqual(len(LstmTrajectoryPredictor().predict(drone, 5)), 5)

    def test_mdcs_covers_all_nodes(self):
        import random

        drones = [
            SimpleNamespace(identifier=0, coords=(0, 0, 0), velocity=(1, 0, 0)),
            SimpleNamespace(identifier=1, coords=(10, 0, 0), velocity=(1, 0, 0)),
            SimpleNamespace(identifier=2, coords=(300, 0, 0), velocity=(1, 0, 0)),
        ]
        neighbor_map = {0: [drones[1]], 1: [drones[0]], 2: []}
        heads, _, _ = select_mdcs_heads(drones, neighbor_map, 50, 10, 1000, random.Random(7))
        covered = {head.identifier for head in heads}
        for head in heads:
            covered.update(item.identifier for item in neighbor_map[head.identifier])
        self.assertEqual(covered, {0, 1, 2})

    def test_tdc_mopso_returns_a_dominating_head_set(self):
        import random

        drones = [
            SimpleNamespace(
                identifier=idx,
                coords=(idx * 20, 0, 0),
                velocity=(1, 0, 0),
                residual_energy=20000,
            )
            for idx in range(4)
        ]
        neighbor_map = {
            drone.identifier: [
                other for other in drones
                if other.identifier != drone.identifier
                and abs(other.coords[0] - drone.coords[0]) <= 25
            ]
            for drone in drones
        }
        selector = TdcMopsoSelector(random.Random(11), swarm_size=6, iterations=3)
        heads = selector.select(
            drones,
            neighbor_map,
            previous_head_ids=set(),
            communication_range=25,
            reference_speed=10,
            initial_energy=20000,
            max_load=2,
            objective_weights=[0.25, 0.25, 0.20, 0.20, 0.10],
        )
        covered = {head.identifier for head in heads}
        for head in heads:
            covered.update(item.identifier for item in neighbor_map[head.identifier])
        self.assertEqual(covered, {0, 1, 2, 3})

    def test_cluster_metrics_report_normalized_churn_and_active_tenure(self):
        metrics = ClusterMetrics()
        metrics.record_cluster_snapshot([(1, [1, 2]), (3, [3, 4])], round_counter=1)
        metrics.record_cluster_snapshot([(1, [1, 2, 3]), (4, [4])], round_counter=2)
        metrics.record_backbone_connectivity(0.75, 0.50, 0.80, 0.90)
        summary = metrics.summary()
        self.assertAlmostEqual(summary['cluster_head_churn_ratio'], 2 / 3)
        self.assertGreater(summary['mean_ch_tenure_rounds'], 0)
        self.assertGreater(summary['mean_cluster_tenure_rounds'], 0)
        self.assertEqual(summary['mean_backbone_connectivity_ratio'], 0.75)
        self.assertEqual(summary['mean_bs_reachability_ratio'], 0.50)
        self.assertEqual(summary['mean_backbone_path_preservation_ratio'], 0.80)
        self.assertEqual(summary['mean_bs_reachability_efficiency'], 0.90)
        self.assertEqual(summary['backbone_partition_ratio'], 1.0)

    def test_rotation_requires_score_margin_and_persistence(self):
        manager = ClusterRotationManager()
        current = SimpleNamespace(
            residual_energy=config.INITIAL_ENERGY,
            avg_let=config.PREDICTION_HORIZON,
            cluster_weight=0.60,
        )
        candidate = SimpleNamespace(
            avg_let=config.PREDICTION_HORIZON,
            cluster_weight=0.67,
        )
        self.assertFalse(manager.should_rotate(current, candidate, stable_rounds=3))
        candidate.cluster_weight = 0.70
        self.assertTrue(manager.should_rotate(current, candidate, stable_rounds=3))

    def test_adaptive_rotation_replaces_low_tlet_head_with_better_link(self):
        manager = ClusterRotationManager()
        current = SimpleNamespace(
            residual_energy=config.INITIAL_ENERGY,
            cluster_age=5,
            avg_let=1.0,
            mobility_factor=0.1,
            cluster_members=[1, 2],
            cluster_weight=0.60,
        )
        candidate = SimpleNamespace(
            avg_let=config.PREDICTION_HORIZON,
            mobility_factor=0.1,
            cluster_weight=0.59,
        )
        original = config.ADAPTIVE_CH_ROTATION
        try:
            config.ADAPTIVE_CH_ROTATION = True
            self.assertTrue(manager.should_rotate(current, candidate, stable_rounds=1))
        finally:
            config.ADAPTIVE_CH_ROTATION = original

    def test_backbone_connector_selects_intermediate_node(self):
        def node(identifier, x, is_base_station=False):
            return SimpleNamespace(
                identifier=identifier,
                coords=(x, 0, 0),
                is_base_station=is_base_station,
                transmitting_queue=queue.Queue(),
                max_queue_size=20,
            )

        base = node(0, 0, True)
        relay = node(1, 90)
        head = node(2, 180)
        simulator = SimpleNamespace(
            drones=[base, relay, head],
            env=SimpleNamespace(now=0),
            link_reliability=LinkReliabilityTracker(),
        )
        planner = BackbonePlanner(simulator, lambda _source, _target: 1.0)
        predictions = {
            1: [(90, 0, 0)] * config.PREDICTION_HORIZON,
            2: [(180, 0, 0)] * config.PREDICTION_HORIZON,
        }
        original_range = config.COMMUNICATION_RANGE
        try:
            config.COMMUNICATION_RANGE = 100
            connected = planner.plan([head], [relay, head], predictions)
            self.assertEqual({drone.identifier for drone in connected}, {1, 2})
            self.assertEqual(planner.last_paths[2], (2, 1, 0))
            self.assertEqual(planner.last_routes[2][0], 1)
            self.assertEqual(planner.last_routes[1][2], 2)
            self.assertEqual(planner.last_control_paths[2], (0, 1, 2))
            with self.assertRaises(TypeError):
                planner.active_snapshot.routes[2][0] = 0
        finally:
            config.COMMUNICATION_RANGE = original_range

    def test_relay_hold_retains_valid_path_and_role_in_same_snapshot(self):
        def node(identifier, x, is_base_station=False):
            return SimpleNamespace(
                identifier=identifier,
                coords=(x, 0, 0),
                is_base_station=is_base_station,
                transmitting_queue=queue.Queue(),
                max_queue_size=20,
            )

        base = node(0, 0, True)
        relay = node(1, 90)
        head = node(2, 180)
        alternate = node(3, 100)
        simulator = SimpleNamespace(
            drones=[base, relay, head, alternate],
            env=SimpleNamespace(now=0),
            link_reliability=LinkReliabilityTracker(),
        )
        quality = {1: 0.1, 3: 1.0}
        planner = BackbonePlanner(
            simulator,
            lambda _source, target: quality.get(target.identifier, 1.0),
        )
        predictions = {
            node.identifier: [node.coords] * config.PREDICTION_HORIZON
            for node in (relay, head, alternate)
        }
        original_range = config.COMMUNICATION_RANGE
        try:
            config.COMMUNICATION_RANGE = 100
            planner.plan(
                [head],
                [relay, head],
                predictions,
                epoch=1,
                cluster_membership={2: (2,)},
            )
            self.assertEqual(planner.last_paths[2], (2, 1, 0))

            planner.plan(
                [head],
                [relay, head, alternate],
                predictions,
                epoch=2,
                retained_relay_ids={1},
                cluster_membership={2: (2,)},
            )

            self.assertEqual(planner.last_paths[2], (2, 1, 0))
            self.assertIn(1, planner.active_snapshot.backbone_relays)
            self.assertEqual(planner.active_snapshot.epoch, 2)
            self.assertEqual(
                planner.active_snapshot.cluster_membership[2],
                (2,),
            )
        finally:
            config.COMMUNICATION_RANGE = original_range

    def test_snapshot_migration_path_excludes_visited_nodes(self):
        def node(identifier, x, is_base_station=False):
            return SimpleNamespace(
                identifier=identifier,
                coords=(x, 0, 0),
                is_base_station=is_base_station,
                sleep=False,
                transmitting_queue=queue.Queue(),
                max_queue_size=20,
            )

        base = node(0, 0, True)
        visited_relay = node(1, 90)
        head = node(2, 180)
        alternate = node(3, 100)
        simulator = SimpleNamespace(
            drones=[base, visited_relay, head, alternate],
            env=SimpleNamespace(now=0),
            link_reliability=LinkReliabilityTracker(),
        )
        planner = BackbonePlanner(simulator, lambda _source, _target: 1.0)
        predictions = {
            item.identifier: [item.coords] * config.PREDICTION_HORIZON
            for item in (visited_relay, head, alternate)
        }
        original_range = config.COMMUNICATION_RANGE
        try:
            config.COMMUNICATION_RANGE = 100
            planner.plan([head], [visited_relay, head, alternate], predictions)
            self.assertEqual(
                planner.path_for(2, 0, forbidden_ids={1}),
                (2, 3, 0),
            )
        finally:
            config.COMMUNICATION_RANGE = original_range

    def test_link_reliability_window_staleness_and_etx_cap(self):
        tracker = LinkReliabilityTracker()
        for attempt_id in range(25):
            tracker.record_attempt(1, 2, 7, attempt_id, attempt_id)
            tracker.record_failure(1, 2, 7, attempt_id, attempt_id + 1)
        self.assertEqual(len(tracker._outcomes[(1, 2)]), 20)
        self.assertEqual(tracker.etx(1, 2, 25), config.MAX_RETRANSMISSION_ATTEMPT)
        stale_now = 25 + config.LINK_STATS_STALE + 1
        self.assertEqual(tracker.success_probability(1, 2, stale_now), 0.5)

    def test_reliable_edge_has_lower_expected_energy_cost(self):
        tracker = LinkReliabilityTracker()
        for attempt_id in range(10):
            tracker.record_attempt(1, 2, 10, attempt_id, attempt_id)
            tracker.record_success(1, 2, 10, attempt_id, attempt_id + 1)
            tracker.record_attempt(1, 3, 11, attempt_id, attempt_id)
            tracker.record_failure(1, 3, 11, attempt_id, attempt_id + 1)
        self.assertLess(
            tracker.normalized_expected_energy(1, 2, 20),
            tracker.normalized_expected_energy(1, 3, 20),
        )

    def test_channel_arrival_event_resets_after_notification(self):
        env = simpy.Environment()
        channel = Channel(env)
        inbox = channel.create_inbox_for_receiver(7)
        event = channel.arrival_event(7)
        channel.unicast_put(['packet'], 7)
        self.assertTrue(event.triggered)
        self.assertEqual(inbox, [['packet']])
        self.assertFalse(channel.arrival_event(7).triggered)

    def test_event_queue_wakes_only_when_an_item_arrives(self):
        env = simpy.Environment()
        pending = EventQueue(env)
        event = pending.wait_for_item()
        self.assertFalse(event.triggered)
        pending.put('packet')
        self.assertTrue(event.triggered)
        self.assertEqual(pending.get(), 'packet')
        self.assertFalse(pending.wait_for_item().triggered)

    def test_energy_ledger_separates_propulsion_and_network_energy(self):
        drone = SimpleNamespace(
            residual_energy=100.0,
            propulsion_energy=0.0,
            communication_energy=0.0,
            data_energy=0.0,
            control_energy=0.0,
            tx_energy=0.0,
            rx_energy=0.0,
            relay_role_energy=0.0,
            sleep=False,
        )
        Drone.consume_energy(drone, 4.0, source='propulsion')
        Drone.consume_energy(drone, 2.0, source='data', direction='tx', role_energy=True)
        Drone.consume_energy(drone, 1.0, source='control', direction='rx')
        self.assertEqual(drone.residual_energy, 93.0)
        self.assertEqual(drone.communication_energy, 3.0)
        self.assertEqual(drone.data_energy + drone.control_energy, 3.0)
        self.assertEqual(drone.tx_energy + drone.rx_energy, 3.0)
        self.assertEqual(drone.relay_role_energy, 2.0)

    def test_energy_ledger_caps_consumption_at_available_battery(self):
        drone = SimpleNamespace(
            residual_energy=5.0,
            propulsion_energy=0.0,
            communication_energy=0.0,
            data_energy=0.0,
            control_energy=0.0,
            tx_energy=0.0,
            rx_energy=0.0,
            relay_role_energy=0.0,
            sleep=False,
        )
        consumed = Drone.consume_energy(
            drone, 8.0, source='data', direction='tx', role_energy=True
        )
        ignored = Drone.consume_energy(drone, 2.0, source='propulsion')
        self.assertEqual(consumed, 5.0)
        self.assertEqual(ignored, 0.0)
        self.assertEqual(drone.residual_energy, 0.0)
        self.assertEqual(drone.communication_energy, 5.0)
        self.assertEqual(drone.data_energy, 5.0)
        self.assertEqual(drone.tx_energy, 5.0)
        self.assertEqual(drone.relay_role_energy, 5.0)
        self.assertEqual(drone.propulsion_energy, 0.0)
        self.assertTrue(drone.sleep)

    def test_energy_ledger_remains_precise_for_large_accumulations(self):
        drone = SimpleNamespace(
            residual_energy=420000.0,
            propulsion_energy=0.0,
            communication_energy=0.0,
            data_energy=0.0,
            control_energy=0.0,
            tx_energy=0.0,
            rx_energy=0.0,
            relay_role_energy=0.0,
            sleep=False,
        )
        for _ in range(10000):
            Drone.consume_energy(drone, 0.1234567, source='propulsion')
            Drone.consume_energy(drone, 0.0004321, source='data', direction='tx')
        ledger = drone.propulsion_energy + drone.communication_energy
        self.assertLess(abs(drone.battery_energy_consumed - ledger), 1e-10)
        self.assertLess(
            abs(drone.initial_energy - drone.residual_energy - ledger), 1e-8
        )

    @staticmethod
    def _energy_node(identifier, simulator=None):
        node = SimpleNamespace(
            identifier=identifier,
            simulator=simulator,
            residual_energy=100.0,
            propulsion_energy=0.0,
            communication_energy=0.0,
            data_energy=0.0,
            control_energy=0.0,
            tx_energy=0.0,
            rx_energy=0.0,
            relay_role_energy=0.0,
            _rx_energy_attempts=set(),
            cluster_role='CM',
            is_backbone_connector=False,
            sleep=False,
        )
        node.consume_energy = Drone.consume_energy.__get__(node, Drone)
        node._charge_rx_attempt = Drone._charge_rx_attempt.__get__(node, Drone)
        return node

    @staticmethod
    def _data_packet(packet_id, source, destination, length=1000):
        packet = DataPacket.__new__(DataPacket)
        packet.packet_id = packet_id
        packet.packet_length = length
        packet.src_drone = source
        packet.dst_drone = destination
        packet.channel_id = 0
        packet._phy_tx_attempt = 0
        return packet

    def test_decode_failure_charges_rx_once(self):
        env = simpy.Environment()
        sender = self._energy_node(0)
        receiver = self._energy_node(1)
        packet = self._data_packet(91, sender, receiver, length=200)
        packet._phy_tx_attempt = 1
        packet.get_current_ttl = lambda: 0
        sender.inbox = []
        receiver.inbox = [[packet, 0, sender.identifier, 0, 0]]
        receiver.env = env
        receiver.simulator = SimpleNamespace(drones=[sender, receiver])
        receiver.update_inbox = Drone.update_inbox.__get__(receiver, Drone)
        receiver.trigger = Drone.trigger.__get__(receiver, Drone)
        receiver.routing_protocol = SimpleNamespace(packet_reception=lambda *_: None)
        expected = packet.packet_length / config.BIT_RATE * config.RECEIVING_POWER
        with patch('entities.drone.sinr_calculator', return_value=[0.0]):
            env.process(Drone.receive(receiver))
            env.run(until=200)
        self.assertAlmostEqual(receiver.rx_energy, expected)
        self.assertEqual(receiver.communication_energy, receiver.data_energy)

    def test_retransmissions_charge_each_tx_and_rx_attempt(self):
        env = simpy.Environment()
        channel = Channel(env)
        tracker = LinkReliabilityTracker()
        simulator = SimpleNamespace(channel=channel, link_reliability=tracker)
        sender = self._energy_node(0, simulator)
        receiver = self._energy_node(1, simulator)
        channel.create_inbox_for_receiver(1)
        packet = self._data_packet(92, sender, receiver)
        packet.next_hop_id = receiver.identifier
        phy = Phy(SimpleNamespace(env=env, my_drone=sender))
        expected = packet.packet_length / config.BIT_RATE * config.TRANSMITTING_POWER
        for attempt in (1, 2):
            phy.unicast(packet, receiver.identifier)
            receiver._charge_rx_attempt(packet, sender.identifier)
            self.assertEqual(packet._phy_tx_attempt, attempt)
        self.assertAlmostEqual(sender.tx_energy, 2 * expected)
        self.assertAlmostEqual(receiver.rx_energy, 2 * expected)
        self.assertEqual(len(tracker._pending), 2)

    def test_timeout_then_late_ack_does_not_double_record_attempt(self):
        tracker = LinkReliabilityTracker()
        tracker.record_attempt(1, 2, 93, 1, 0)
        self.assertTrue(tracker.record_failure(1, 2, 93, 1, 10))
        self.assertFalse(tracker.record_success(1, 2, 93, 1, 20))
        self.assertEqual(list(tracker._outcomes[(1, 2)]), [False])
        tracker.record_attempt(1, 2, 93, 2, 30)
        self.assertTrue(tracker.record_success(1, 2, 93, 2, 40))
        self.assertFalse(tracker.record_failure(1, 2, 93, 2, 50))
        self.assertEqual(list(tracker._outcomes[(1, 2)]), [False, True])

    def test_broadcast_and_multicast_charge_each_actual_receiver(self):
        env = simpy.Environment()
        channel = Channel(env)
        simulator = SimpleNamespace(
            channel=channel,
            link_reliability=LinkReliabilityTracker(),
        )
        sender = self._energy_node(0, simulator)
        receivers = [self._energy_node(index, simulator) for index in (1, 2, 3)]
        for node in [sender] + receivers:
            channel.create_inbox_for_receiver(node.identifier)
        phy = Phy(SimpleNamespace(env=env, my_drone=sender))
        packet = self._data_packet(94, sender, receivers[0])
        expected = packet.packet_length / config.BIT_RATE * config.RECEIVING_POWER

        phy.broadcast(packet)
        for receiver in receivers:
            delivered = receiver.simulator.channel.pipes[receiver.identifier][-1][0]
            receiver._charge_rx_attempt(delivered, sender.identifier)
            receiver._charge_rx_attempt(delivered, sender.identifier)
            self.assertAlmostEqual(receiver.rx_energy, expected)
        self.assertEqual(sender.rx_energy, 0.0)

        multicast_packet = self._data_packet(95, sender, receivers[0])
        env.process(phy.multicast(multicast_packet, [1, 3]))
        env.run()
        for receiver in (receivers[0], receivers[2]):
            delivered = receiver.simulator.channel.pipes[receiver.identifier][-1][0]
            receiver._charge_rx_attempt(delivered, sender.identifier)
            self.assertAlmostEqual(receiver.rx_energy, 2 * expected)
        self.assertAlmostEqual(receivers[1].rx_energy, expected)

    def test_frozen_method_profiles_keep_baseline_boundaries(self):
        keys = (
            'CLUSTER_ALGORITHM', 'MWMP_DECISION_MODE',
            'USE_BACKBONE_CONNECTORS', 'BACKBONE_RELAY_HOLD_ROUNDS',
        )
        original = {key: getattr(config, key) for key in keys}
        try:
            torp = apply_frozen_method(config, 'TORP_LIKE')
            self.assertEqual(torp['protocol'], 'TORP_LIKE')
            self.assertEqual(config.CLUSTER_ALGORITHM, 'TORP_LIKE')
            legacy = apply_frozen_method(config, 'ORIGINAL_MWMP')
            self.assertEqual(config.MWMP_DECISION_MODE, 'original')
            self.assertFalse(config.USE_BACKBONE_CONNECTORS)
            proposed = apply_frozen_method(config, 'PROPOSED')
            self.assertEqual(config.MWMP_DECISION_MODE, 'proposed')
            self.assertTrue(config.USE_BACKBONE_CONNECTORS)
        finally:
            for key, value in original.items():
                setattr(config, key, value)

    def test_oracle_reads_future_trace_without_mutating_motion(self):
        trace = {
            'nodes': {
                '1': [
                    {'time_us': 0, 'coords': [0, 0, 0], 'velocity': [1, 0, 0]},
                    {'time_us': 1000000, 'coords': [1, 0, 0], 'velocity': [1, 0, 0]},
                    {'time_us': 2000000, 'coords': [2, 0, 0], 'velocity': [1, 0, 0]},
                ]
            }
        }
        simulator = SimpleNamespace(
            env=SimpleNamespace(now=0), mobility_trace_data=trace
        )
        drone = SimpleNamespace(identifier=1, coords=[0, 0, 0], is_base_station=False)
        predictor = OracleTrajectoryPredictor(simulator)
        self.assertEqual(predictor.predict(drone, 2), [(1, 0, 0), (2, 0, 0)])
        self.assertEqual(drone.coords, [0, 0, 0])
        self.assertEqual(
            CurrentOnlyTrajectoryPredictor().predict(drone, 2),
            [(0, 0, 0), (0, 0, 0)],
        )

    def test_torp_like_uses_paid_frozen_snapshot(self):
        class Node:
            def __init__(self, identifier, x):
                self.identifier = identifier
                self.coords = (x, 0, 0)
                self.velocity = (0, 0, 0)
                self.sleep = False
                self.is_base_station = identifier == 2
                self.energy = []

            def consume_energy(self, amount, **labels):
                self.energy.append((amount, labels))

        nodes = [Node(0, 0), Node(1, 90), Node(2, 180)]
        control_counts = []
        simulator = SimpleNamespace(
            drones=nodes,
            env=SimpleNamespace(now=0),
            link_reliability=LinkReliabilityTracker(),
            metrics=SimpleNamespace(
                increment_control_packets=lambda count, category: control_counts.append(
                    (count, category)
                )
            ),
        )
        planner = TorpLikePlanner.__new__(TorpLikePlanner)
        planner.simulator = simulator
        planner.snapshot = SimpleNamespace(epoch=0)
        original_range = config.COMMUNICATION_RANGE
        try:
            config.COMMUNICATION_RANGE = 100
            planner.refresh()
            self.assertEqual(planner.path_for(0, 2), (0, 1, 2))
            self.assertEqual(control_counts[-1][1], 'torp')
            self.assertGreater(control_counts[-1][0], 0)
            self.assertTrue(any(node.energy for node in nodes))

            nodes[1].coords = (500, 0, 0)
            self.assertEqual(planner.path_for(0, 2), (0, 1, 2))
            planner.refresh()
            self.assertEqual(planner.path_for(0, 2), ())
        finally:
            config.COMMUNICATION_RANGE = original_range

    def test_protocol_independent_bs_reachability_metrics(self):
        bs = SimpleNamespace(
            identifier=0,
            coords=(0, 0, 0),
            sleep=False,
            is_base_station=True,
        )
        source = SimpleNamespace(
            identifier=1,
            coords=(90, 0, 0),
            sleep=False,
            is_base_station=False,
        )
        planner = SimpleNamespace(
            has_route=lambda source_id, target_id: (source_id, target_id) == (1, 0)
        )
        metrics = Metrics.__new__(Metrics)
        metrics.simulator = SimpleNamespace(
            drones=[bs, source],
            torp_like_planner=planner,
        )
        original_range = config.COMMUNICATION_RANGE
        try:
            config.COMMUNICATION_RANGE = 100
            self.assertEqual(metrics._routing_bs_reachability_ratio(), 1.0)
            self.assertEqual(metrics._physical_bs_reachability_ratio(), 1.0)
            source.coords = (200, 0, 0)
            self.assertEqual(metrics._routing_bs_reachability_ratio(), 1.0)
            self.assertEqual(metrics._physical_bs_reachability_ratio(), 0.0)
        finally:
            config.COMMUNICATION_RANGE = original_range

    def test_tlet_saturation_ratio_is_reported(self):
        metrics = ClusterMetrics()
        for value in (1.0, 0.5, 1.0):
            metrics.record_weight_factors({'tlet_ratio': value})
        self.assertAlmostEqual(metrics.summary()['tlet_saturation_ratio'], 2 / 3)

    def test_backbone_relay_is_independent_from_cluster_head_role(self):
        relay = SimpleNamespace(cluster_role='CM', is_backbone_connector=True)
        member = SimpleNamespace(cluster_role='CM', is_backbone_connector=False)
        head = SimpleNamespace(cluster_role='CH', is_backbone_connector=False)
        self.assertTrue(MwmpDcaRouting._is_backbone_node(relay))
        self.assertTrue(MwmpDcaRouting._is_backbone_node(head))
        self.assertFalse(MwmpDcaRouting._is_backbone_node(member))

    def test_backbone_relay_enables_and_reuses_router(self):
        routing = object.__new__(MwmpDcaRouting)
        routing.simulator = SimpleNamespace()
        routing.my_drone = SimpleNamespace()
        routing.backbone_router = None
        routing.backbone_router_role = None
        router = SimpleNamespace(active=True)

        with patch.object(config, 'USE_BACKBONE_CONNECTORS', False):
            with patch('routing.mwmp_dca.mwmp_dca_routing.Dsdv', return_value=router) as factory:
                routing.update_role('BR')
                self.assertIs(routing.backbone_router, router)
                self.assertEqual(routing.backbone_router_role, 'BR')

                routing.update_role('CH')
                factory.assert_called_once()
                self.assertIs(routing.backbone_router, router)
                self.assertEqual(routing.backbone_router_role, 'CH')

                routing.update_role('CM')
                self.assertFalse(router.active)

    def test_proposed_uses_planner_route_without_dsdv(self):
        target = SimpleNamespace(identifier=2)
        next_hop = SimpleNamespace(
            identifier=1,
            cluster_role='CM',
            is_backbone_connector=True,
            sleep=False,
            coords=(10, 0, 0),
        )
        source = SimpleNamespace(identifier=0, sleep=False, coords=(0, 0, 0))
        planner = SimpleNamespace(
            last_routes={0: {2: 1}},
            snapshot_epoch=4,
        )
        recorded = []
        routing = object.__new__(MwmpDcaRouting)
        routing.simulator = SimpleNamespace(
            drones=[source, next_hop, target],
            cluster_manager=SimpleNamespace(
                backbone_planner=planner,
                round_counter=4,
            ),
            metrics=SimpleNamespace(
                record_routing_event=lambda name, count=1: recorded.append(
                    (name, count)
                )
            ),
        )
        routing.my_drone = source
        routing.backbone_router = None
        routing.backbone_router_role = None
        packet = SimpleNamespace(
            intermediate_drones=[0],
            mwmp_recorded_events=set(),
            mwmp_route_epoch=None,
        )

        with patch.object(config, 'MWMP_DECISION_MODE', 'proposed'):
            with patch.object(config, 'USE_BACKBONE_CONNECTORS', True):
                with patch('routing.mwmp_dca.mwmp_dca_routing.Dsdv') as factory:
                    routing.update_role('CH')
                    selected = routing._select_backbone_primary_next_hop(
                        target,
                        packet,
                    )

        factory.assert_not_called()
        self.assertIs(selected, next_hop)
        self.assertEqual(packet.mwmp_route_epoch, 4)
        self.assertEqual(recorded, [])

    def test_planner_diagnostics_classify_loop_and_stale_epoch(self):
        target = SimpleNamespace(identifier=2)
        source = SimpleNamespace(identifier=0, sleep=False, coords=(0, 0, 0))
        next_hop = SimpleNamespace(
            identifier=1,
            cluster_role='CM',
            is_backbone_connector=True,
            sleep=False,
            coords=(10, 0, 0),
        )
        recorded = []
        routing = object.__new__(MwmpDcaRouting)
        routing.simulator = SimpleNamespace(
            drones=[source, next_hop, target],
            cluster_manager=SimpleNamespace(
                backbone_planner=SimpleNamespace(
                    last_routes={0: {2: 1}},
                    snapshot_epoch=5,
                ),
                round_counter=5,
            ),
            metrics=SimpleNamespace(
                record_routing_event=lambda name, count=1: recorded.append(
                    (name, count)
                )
            ),
        )
        routing.my_drone = source
        routing.backbone_router = None
        packet = SimpleNamespace(
            intermediate_drones=[0, 1],
            mwmp_recorded_events=set(),
            mwmp_route_epoch=4,
        )

        selected = routing._select_backbone_primary_next_hop(target, packet)

        self.assertIsNone(selected)
        self.assertIn(('stale_snapshot_count', 1), recorded)
        self.assertIn(('planned_route_loop_reject_count', 1), recorded)

    def test_pinned_route_survives_epoch_change_with_packet_scoped_lease(self):
        def node(identifier, x, role='CM'):
            return SimpleNamespace(
                identifier=identifier,
                coords=(x, 0, 0),
                cluster_role=role,
                is_backbone_connector=False,
                is_base_station=False,
                sleep=False,
                residual_energy=config.INITIAL_ENERGY,
                avg_let=config.PREDICTION_HORIZON,
            )

        source = node(0, 0)
        legacy_relay = node(1, 10)
        destination = node(2, 20)
        recorded = []
        routing = object.__new__(MwmpDcaRouting)
        routing.my_drone = legacy_relay
        routing.simulator = SimpleNamespace(
            drones=[source, legacy_relay, destination],
            cluster_manager=SimpleNamespace(
                backbone_planner=SimpleNamespace(
                    active_snapshot=SimpleNamespace(epoch=2),
                )
            ),
            metrics=SimpleNamespace(
                record_routing_event=lambda name, count=1: recorded.append(
                    (name, count)
                )
            ),
        )
        packet = self._data_packet(96, source, destination)
        packet.intermediate_drones = [0]
        routing._prepare_packet_state(packet)
        packet.route_epoch = 1
        packet.route_version = 1
        packet.pinned_path = (0, 1, 2)
        packet.route_cursor = 1

        selected = routing._select_pinned_route_next_hop(packet)

        self.assertTrue(selected[0])
        self.assertEqual(packet.next_hop_id, 2)
        self.assertEqual(packet.route_epoch, 1)
        self.assertEqual(packet.legacy_forward_count, 1)
        names = [name for name, _count in recorded]
        self.assertIn('epoch_aged_packet_count', names)
        self.assertIn('legacy_forward_count', names)
        self.assertNotIn('mid_route_epoch_switch_count', names)
        self.assertTrue(is_role_energy(packet, legacy_relay))

    def test_invalid_pinned_hop_migrates_once_from_current_node(self):
        def node(identifier, x, *, base=False):
            return SimpleNamespace(
                identifier=identifier,
                coords=(x, 0, 0),
                cluster_role='BS' if base else 'CM',
                is_backbone_connector=False,
                is_base_station=base,
                sleep=False,
                residual_energy=config.INITIAL_ENERGY,
                avg_let=config.PREDICTION_HORIZON,
            )

        visited = node(0, -10)
        current = node(1, 0)
        broken = node(2, 1000)
        destination = node(3, 20, base=True)
        alternate = node(4, 10)
        recorded = []
        captured = {}

        def migration_path(source_id, target_id, forbidden_ids=()):
            captured['source'] = source_id
            captured['target'] = target_id
            captured['forbidden'] = set(forbidden_ids)
            return (1, 4, 3)

        planner = SimpleNamespace(
            active_snapshot=SimpleNamespace(epoch=5, routes={}),
            path_for=migration_path,
        )
        routing = object.__new__(MwmpDcaRouting)
        routing.my_drone = current
        routing.simulator = SimpleNamespace(
            drones=[visited, current, broken, destination, alternate],
            cluster_manager=SimpleNamespace(backbone_planner=planner),
            metrics=SimpleNamespace(
                record_routing_event=lambda name, count=1: recorded.append(
                    (name, count)
                )
            ),
        )
        packet = self._data_packet(97, visited, destination)
        packet.intermediate_drones = [0]
        routing._prepare_packet_state(packet)
        packet.route_epoch = 4
        packet.route_version = 4
        packet.pinned_path = (1, 2, 3)
        packet.route_cursor = 0

        selected = routing._select_pinned_route_next_hop(packet)

        self.assertTrue(selected[0])
        self.assertEqual(packet.next_hop_id, 4)
        self.assertEqual(packet.pinned_path, (1, 4, 3))
        self.assertEqual(packet.migration_count, 1)
        self.assertEqual(packet.migration_reason, 'NEXT_HOP_UNREACHABLE')
        self.assertEqual(captured['source'], 1)
        self.assertEqual(captured['target'], 3)
        self.assertEqual(captured['forbidden'], {0})
        names = [name for name, _count in recorded]
        self.assertEqual(names.count('migration_attempt_count'), 1)
        self.assertEqual(names.count('migration_success_count'), 1)
        self.assertEqual(names.count('mid_route_epoch_switch_count'), 1)

        recorded.clear()
        same_epoch_packet = self._data_packet(98, visited, destination)
        same_epoch_packet.intermediate_drones = [0]
        routing._prepare_packet_state(same_epoch_packet)
        same_epoch_packet.route_epoch = 5
        same_epoch_packet.route_version = 5
        same_epoch_packet.pinned_path = (1, 2, 3)
        same_epoch_packet.route_cursor = 0

        same_epoch_selected = routing._select_pinned_route_next_hop(
            same_epoch_packet
        )

        self.assertTrue(same_epoch_selected[0])
        same_epoch_names = [name for name, _count in recorded]
        self.assertNotIn('mid_route_epoch_switch_count', same_epoch_names)

    def test_visited_conflict_audit_uses_only_actual_history(self):
        def node(identifier, x, *, base=False):
            return SimpleNamespace(
                identifier=identifier,
                coords=(x, 0, 0),
                cluster_role='BS' if base else 'CM',
                is_backbone_connector=False,
                is_base_station=base,
                sleep=False,
                residual_energy=config.INITIAL_ENERGY,
                avg_let=config.PREDICTION_HORIZON,
            )

        visited_head = node(0, 0)
        current = node(1, 10)
        source = node(2, 20)
        destination = node(3, 30)
        candidate = node(4, 15)
        destination.cluster_head = visited_head
        recorded = []
        audit_rows = []
        planner = SimpleNamespace(
            active_snapshot=SimpleNamespace(epoch=7, routes={1: {0: 4}}),
            path_for=lambda source_id, target_id, forbidden_ids=(): (
                1, 4, 0
            ),
        )
        routing = object.__new__(MwmpDcaRouting)
        routing.my_drone = current
        routing.simulator = SimpleNamespace(
            env=SimpleNamespace(now=123),
            drones=[visited_head, current, source, destination, candidate],
            cluster_manager=SimpleNamespace(backbone_planner=planner),
            metrics=SimpleNamespace(
                record_routing_event=lambda name, count=1: recorded.append(
                    (name, count)
                ),
                record_migration_audit=lambda **fields: audit_rows.append(
                    fields
                ),
            ),
        )
        packet = self._data_packet(99, source, destination)
        packet.intermediate_drones = [2, 0]
        routing._prepare_packet_state(packet)
        packet.route_epoch = 6
        packet.pinned_path = (1, 4, 3)
        packet.authorized_pinned_path = packet.pinned_path

        selected = routing._migrate_pinned_route(
            packet,
            'NEXT_HOP_UNREACHABLE',
        )

        self.assertFalse(selected[0])
        self.assertEqual(packet.visited_nodes, {0, 1, 2})
        names = [name for name, _count in recorded]
        self.assertIn('migration_fail_visited_conflict_count', names)
        conflict = next(
            row for row in audit_rows
            if row['event'] == 'visited_path_conflict'
        )
        self.assertEqual(conflict['old_pinned_path'], '1|4|3')
        self.assertEqual(conflict['visited_nodes'], '0|1|2')
        self.assertEqual(conflict['requested_target'], 0)
        self.assertEqual(conflict['candidate_path'], '1|4|0|3')
        self.assertEqual(conflict['rejected_nodes'], '0')

    def test_bs_migration_target_is_always_packet_destination(self):
        source = SimpleNamespace(identifier=1)
        stale_head = SimpleNamespace(identifier=2)
        base_station = SimpleNamespace(
            identifier=0,
            is_base_station=True,
            cluster_head=stale_head,
        )
        routing = object.__new__(MwmpDcaRouting)
        packet = SimpleNamespace(
            src_drone=source,
            dst_drone=base_station,
            original_backbone_target=stale_head.identifier,
        )

        target = routing._resolve_backbone_target(packet)

        self.assertIs(target, base_station)

    def test_failed_migration_cannot_silently_repin_on_poll(self):
        source = SimpleNamespace(identifier=0)
        current = SimpleNamespace(
            identifier=1,
            coords=(10, 0, 0),
            cluster_role='CH',
            is_backbone_connector=False,
        )
        destination = SimpleNamespace(identifier=2, is_base_station=True)
        recorded = []
        audit_rows = []
        routing = object.__new__(MwmpDcaRouting)
        routing.my_drone = current
        routing.simulator = SimpleNamespace(
            env=SimpleNamespace(now=456),
            drones=[source, current, destination],
            cluster_manager=None,
            metrics=SimpleNamespace(
                record_routing_event=lambda name, count=1: recorded.append(
                    (name, count)
                ),
                record_migration_audit=lambda **fields: audit_rows.append(
                    fields
                ),
            ),
        )
        packet = self._data_packet(100, source, destination)
        packet.intermediate_drones = [0, 1]
        routing._prepare_packet_state(packet)
        packet.backbone_packet_recorded = True
        packet.migration_count = 1
        packet.migration_reason = 'NEXT_HOP_UNREACHABLE'
        packet.migration_failure_reason = 'NO_PATH'
        packet.pinned_path = None

        with patch.object(
            routing,
            '_select_backbone_next_hop',
        ) as selector:
            selected = routing.next_hop_selection(packet)

        self.assertFalse(selected[0])
        selector.assert_not_called()
        names = [name for name, _count in recorded]
        self.assertIn('post_migration_repin_blocked_count', names)
        self.assertEqual(
            audit_rows[-1]['event'],
            'post_migration_repin_blocked',
        )

    def test_initial_pin_excludes_actual_pre_backbone_history(self):
        def node(identifier, x, *, base=False):
            return SimpleNamespace(
                identifier=identifier,
                coords=(x, 0, 0),
                cluster_role='BS' if base else 'CM',
                is_backbone_connector=False,
                is_base_station=base,
                sleep=False,
                residual_energy=config.INITIAL_ENERGY,
                avg_let=config.PREDICTION_HORIZON,
            )

        visited = node(0, -10)
        current = node(1, 0)
        destination = node(2, 20, base=True)
        alternate = node(3, 10)
        calls = []

        def loop_free_path(source_id, target_id, forbidden_ids=()):
            calls.append((source_id, target_id, set(forbidden_ids)))
            return (1, 3, 2)

        planner = SimpleNamespace(
            active_snapshot=SimpleNamespace(
                epoch=9,
                routes={1: {2: 0}},
            ),
            path_for=loop_free_path,
            planned_path_for=lambda *_args: (1, 0, 2),
        )
        recorded = []
        routing = object.__new__(MwmpDcaRouting)
        routing.my_drone = current
        routing.simulator = SimpleNamespace(
            drones=[visited, current, destination, alternate],
            cluster_manager=SimpleNamespace(backbone_planner=planner),
            metrics=SimpleNamespace(
                record_routing_event=lambda name, count=1: recorded.append(
                    (name, count)
                )
            ),
        )
        packet = self._data_packet(101, visited, destination)
        packet.intermediate_drones = [0]
        routing._prepare_packet_state(packet)

        pinned = routing._pin_packet_route(
            packet,
            destination,
            migration=False,
        )

        self.assertTrue(pinned)
        self.assertEqual(calls, [(1, 2, {0})])
        self.assertEqual(packet.pinned_path, (1, 3, 2))
        names = [name for name, _count in recorded]
        self.assertIn('initial_pin_visited_aware_count', names)
        self.assertNotIn('pinned_path_visited_conflict_count', names)

    def test_rotation_retains_previous_head_when_trigger_rejects_candidate(self):
        previous = SimpleNamespace(identifier=0, residual_energy=10.0)
        candidate = SimpleNamespace(identifier=1, residual_energy=10.0)
        manager = object.__new__(ClusterManager)
        manager.simulator = SimpleNamespace(drones=[previous, candidate])
        manager.better_candidate_persistence = {}
        manager.rotation_manager = SimpleNamespace(
            should_rotate=lambda _current, _candidate, _rounds: False,
            should_rotate_original=lambda _current, _candidate, _rounds: False,
        )

        selected = manager._apply_rotation(
            [candidate],
            [previous, candidate],
            {0: [candidate], 1: [previous]},
            {0: 0.7, 1: 0.8},
            {0},
        )

        self.assertEqual([drone.identifier for drone in selected], [0])

    def test_backbone_control_paths_are_charged_to_energy_ledger(self):
        def node(identifier, role, connector=False):
            calls = []
            drone = SimpleNamespace(
                identifier=identifier,
                cluster_role=role,
                is_backbone_connector=connector,
                calls=calls,
            )
            drone.consume_energy = lambda amount, **kwargs: calls.append(
                (amount, kwargs)
            )
            return drone

        base = node(0, 'BS')
        relay = node(1, 'CM', connector=True)
        head = node(2, 'CH')
        recorded = []
        manager = object.__new__(ClusterManager)
        manager.simulator = SimpleNamespace(
            drones=[base, relay, head],
            metrics=SimpleNamespace(
                increment_control_packets=lambda count, category: recorded.append(
                    (count, category)
                )
            ),
        )
        manager.backbone_planner = SimpleNamespace(
            last_control_paths={2: [0, 1, 2]}
        )

        manager._account_backbone_control()

        self.assertEqual(recorded, [(2, 'backbone')])
        self.assertEqual(base.calls[0][1]['direction'], 'tx')
        self.assertEqual(relay.calls[0][1]['direction'], 'rx')
        self.assertEqual(relay.calls[1][1]['direction'], 'tx')
        self.assertEqual(head.calls[0][1]['direction'], 'rx')
        self.assertTrue(relay.calls[0][1]['role_energy'])
        self.assertTrue(head.calls[0][1]['role_energy'])

if __name__ == '__main__':
    unittest.main()
