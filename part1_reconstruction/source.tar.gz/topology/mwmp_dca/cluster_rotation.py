from utils import config


class ClusterRotationManager:
    """Score-margin persistence with battery/TLET emergency rotation."""

    def should_rotate_original(self, current_head, candidate_head, stable_rounds):
        if current_head is None or candidate_head is None:
            return True
        energy_ratio = current_head.residual_energy / float(config.INITIAL_ENERGY)
        if energy_ratio <= config.CH_MIN_ENERGY_RATIO:
            return True
        round_limit = max(
            1,
            int(config.CH_MAX_LIFETIME / max(1, config.CLUSTER_INTERVAL)),
        )
        if getattr(current_head, 'cluster_age', 0) >= round_limit:
            return True
        if getattr(current_head, 'avg_let', 0.0) <= (
            config.PREDICTION_HORIZON * config.CH_LET_DROP_RATIO
        ):
            return True
        if getattr(current_head, 'mobility_factor', 0.0) >= config.CH_MOBILITY_ROTATION_THRESHOLD:
            return True
        if len(getattr(current_head, 'cluster_members', [])) > config.CH_MAX_LOAD:
            return True
        score_gain = (
            getattr(candidate_head, 'cluster_weight', 0.0) -
            getattr(current_head, 'cluster_weight', 0.0)
        )
        return (
            score_gain >= config.CH_ROTATION_WEIGHT_MARGIN and
            stable_rounds >= config.CH_ROTATION_STABLE_ROUNDS
        )

    def should_rotate(self, current_head, candidate_head, stable_rounds):
        if current_head is None or candidate_head is None:
            return True

        energy_ratio = current_head.residual_energy / float(config.INITIAL_ENERGY)
        if energy_ratio <= config.CH_MIN_ENERGY_RATIO:
            return True

        horizon = max(1.0, float(config.PREDICTION_HORIZON))
        current_tlet_ratio = max(
            0.0,
            min(1.0, getattr(current_head, 'avg_let', 0.0) / horizon),
        )
        if current_tlet_ratio <= config.CH_LET_DROP_RATIO:
            return True

        score_gain = (
            getattr(candidate_head, 'cluster_weight', 0.0) -
            getattr(current_head, 'cluster_weight', 0.0)
        )
        return (
            score_gain >= config.CH_ROTATION_WEIGHT_MARGIN and
            stable_rounds >= config.CH_ROTATION_STABLE_ROUNDS
        )
