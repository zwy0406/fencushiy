from collections import defaultdict, deque

from utils import config


class LinkReliabilityTracker:
    """Tracks completed directed data/ACK transactions for ETX and delay."""

    def __init__(self):
        self._outcomes = defaultdict(
            lambda: deque(maxlen=int(config.LINK_SUCCESS_WINDOW))
        )
        self._pending = {}
        self._last_update = {}
        self._delay_ewma_us = {}

    @staticmethod
    def _edge(src_id, dst_id):
        return int(src_id), int(dst_id)

    @staticmethod
    def _attempt_key(src_id, dst_id, packet_id, attempt_id):
        return int(src_id), int(dst_id), int(packet_id), int(attempt_id)

    def record_attempt(self, src_id, dst_id, packet_id, attempt_id, now_us):
        key = self._attempt_key(src_id, dst_id, packet_id, attempt_id)
        self._pending.setdefault(key, float(now_us))

    def record_success(self, src_id, dst_id, packet_id, attempt_id, now_us):
        return self._record_outcome(src_id, dst_id, packet_id, attempt_id, now_us, True)

    def record_failure(self, src_id, dst_id, packet_id, attempt_id, now_us):
        return self._record_outcome(src_id, dst_id, packet_id, attempt_id, now_us, False)

    def _record_outcome(self, src_id, dst_id, packet_id, attempt_id, now_us, success):
        key = self._attempt_key(src_id, dst_id, packet_id, attempt_id)
        started = self._pending.pop(key, None)
        if started is None:
            return False
        edge = self._edge(src_id, dst_id)
        self._outcomes[edge].append(bool(success))
        self._last_update[edge] = float(now_us)
        delay_us = max(0.0, float(now_us) - started)
        previous = self._delay_ewma_us.get(edge)
        alpha = float(config.LINK_DELAY_EWMA_ALPHA)
        self._delay_ewma_us[edge] = delay_us if previous is None else (
            alpha * delay_us + (1.0 - alpha) * previous
        )
        return True

    def _active_outcomes(self, src_id, dst_id, now_us):
        edge = self._edge(src_id, dst_id)
        last_update = self._last_update.get(edge)
        if last_update is None or float(now_us) - last_update > config.LINK_STATS_STALE:
            return ()
        return self._outcomes.get(edge, ())

    def success_probability(self, src_id, dst_id, now_us):
        outcomes = self._active_outcomes(src_id, dst_id, now_us)
        return (sum(outcomes) + 1.0) / (len(outcomes) + 2.0)

    def etx(self, src_id, dst_id, now_us):
        probability = max(
            self.success_probability(src_id, dst_id, now_us),
            float(config.LINK_SUCCESS_EPSILON),
        )
        return min(float(config.MAX_RETRANSMISSION_ATTEMPT), 1.0 / probability)

    def normalized_expected_energy(self, src_id, dst_id, now_us):
        return self.etx(src_id, dst_id, now_us) / float(config.MAX_RETRANSMISSION_ATTEMPT)

    def delay_seconds(self, src_id, dst_id, now_us):
        edge = self._edge(src_id, dst_id)
        if self._active_outcomes(src_id, dst_id, now_us):
            return self._delay_ewma_us[edge] / 1e6
        return self.analytic_delay_seconds()

    @staticmethod
    def analytic_delay_seconds():
        data_bits = (
            config.AVERAGE_PAYLOAD_LENGTH + config.IP_HEADER_LENGTH +
            config.MAC_HEADER_LENGTH + config.PHY_HEADER_LENGTH
        )
        expected_backoff_us = ((config.CW_MIN - 1) / 2.0) * config.SLOT_DURATION
        fixed_us = config.DIFS_DURATION + config.SIFS_DURATION + expected_backoff_us
        serialization_s = (data_bits + config.ACK_PACKET_LENGTH) / config.BIT_RATE
        return fixed_us / 1e6 + serialization_s

    def normalized_delay(self, src_id, dst_id, now_us):
        return min(1.0, self.delay_seconds(src_id, dst_id, now_us) / config.ENERGY_DELAY_REF)
