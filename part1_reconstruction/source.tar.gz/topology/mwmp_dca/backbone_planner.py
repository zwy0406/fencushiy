import heapq
from dataclasses import dataclass
from types import MappingProxyType

from topology.mwmp_dca.trajectory_let_calculator import trajectory_based_let
from topology.mwmp_dca.weight_calculator import clamp01
from utils import config
from utils.util_function import euclidean_distance_3d


@dataclass(frozen=True)
class BackboneSnapshot:
    epoch: int
    created_time_us: float
    cluster_heads: frozenset
    backbone_relays: frozenset
    cluster_membership: object
    paths_to_bs: object
    routes: object
    control_paths: object
    valid_edges: frozenset
    edge_costs: object


def _frozen_mapping(values):
    return MappingProxyType(dict(values))


def _frozen_nested_mapping(values):
    return MappingProxyType({
        key: MappingProxyType(dict(nested))
        for key, nested in values.items()
    })


class BackbonePlanner:
    """BS-assisted weighted planner over CH, candidate BR, and BS nodes."""

    def __init__(self, simulator, link_quality):
        self.simulator = simulator
        self.link_quality = link_quality
        self.last_paths = {}
        self.last_routes = {}
        self.last_control_paths = {}
        self.last_failures = {}
        self.snapshot_epoch = 0
        self.snapshot_head_ids = frozenset()
        self.snapshot_backbone_ids = frozenset()
        self.active_snapshot = BackboneSnapshot(
            epoch=0,
            created_time_us=0.0,
            cluster_heads=frozenset(),
            backbone_relays=frozenset(),
            cluster_membership=_frozen_mapping({}),
            paths_to_bs=_frozen_mapping({}),
            routes=_frozen_nested_mapping({}),
            control_paths=_frozen_mapping({}),
            valid_edges=frozenset(),
            edge_costs=_frozen_mapping({}),
        )

    def plan(
        self,
        candidate_heads,
        drones,
        predictions,
        epoch=None,
        retained_relay_ids=(),
        cluster_membership=None,
    ):
        new_epoch = int(epoch) if epoch is not None else self.snapshot_epoch + 1
        head_ids = frozenset(
            head.identifier for head in candidate_heads
        )
        membership = cluster_membership or {}
        if not config.USE_BACKBONE_CONNECTORS:
            snapshot = BackboneSnapshot(
                epoch=new_epoch,
                created_time_us=self.simulator.env.now,
                cluster_heads=head_ids,
                backbone_relays=frozenset(),
                cluster_membership=_frozen_mapping(membership),
                paths_to_bs=_frozen_mapping({}),
                routes=_frozen_nested_mapping({}),
                control_paths=_frozen_mapping({}),
                valid_edges=frozenset(),
                edge_costs=_frozen_mapping({}),
            )
            self._publish(snapshot, {})
            return list(candidate_heads)

        base_stations = [
            drone for drone in self.simulator.drones
            if getattr(drone, 'is_base_station', False)
        ]
        nodes = base_stations + list(drones)
        by_id = {drone.identifier: drone for drone in nodes}
        adjacency = {drone.identifier: [] for drone in nodes}
        for source in nodes:
            for target in nodes:
                if source.identifier == target.identifier:
                    continue
                if euclidean_distance_3d(source.coords, target.coords) <= config.COMMUNICATION_RANGE:
                    adjacency[source.identifier].append(target.identifier)

        target_ids = {drone.identifier for drone in base_stations}
        selected_ids = set(head_ids)
        retained_relay_ids = set(retained_relay_ids)
        old_paths = self.active_snapshot.paths_to_bs
        new_paths = {}
        new_failures = {}
        for head in sorted(candidate_heads, key=lambda item: item.identifier):
            old_path = old_paths.get(head.identifier)
            if self._can_retain_path(
                old_path,
                head.identifier,
                target_ids,
                head_ids,
                retained_relay_ids,
                adjacency,
                by_id,
            ):
                path = list(old_path)
            else:
                path = self._dijkstra(
                    head.identifier,
                    target_ids,
                    adjacency,
                    by_id,
                    predictions,
                )
            if path:
                new_paths[head.identifier] = tuple(path)
                selected_ids.update(path)
            else:
                new_failures[head.identifier] = 'no_bs_path'

        backbone_adjacency = {
            node_id: [
                neighbor_id for neighbor_id in adjacency.get(node_id, ())
                if neighbor_id in selected_ids
            ]
            for node_id in selected_ids
        }
        terminal_ids = target_ids | {
            head.identifier for head in candidate_heads
        }
        new_routes = self._build_routes(
            selected_ids,
            terminal_ids,
            backbone_adjacency,
            by_id,
            predictions,
        )
        new_control_paths = {}
        for node_id in sorted(selected_ids - target_ids):
            path_to_bs = self._dijkstra(
                node_id,
                target_ids,
                backbone_adjacency,
                by_id,
                predictions,
            )
            if path_to_bs:
                new_control_paths[node_id] = tuple(
                    reversed(path_to_bs)
                )
        relay_ids = frozenset(selected_ids - head_ids - target_ids)
        valid_edges = frozenset(
            (source_id, target_id)
            for source_id, targets in adjacency.items()
            for target_id in targets
        )
        edge_costs = {
            edge: self.edge_cost(
                by_id[edge[0]],
                by_id[edge[1]],
                predictions,
            )
            for edge in valid_edges
        }
        snapshot = BackboneSnapshot(
            epoch=new_epoch,
            created_time_us=self.simulator.env.now,
            cluster_heads=head_ids,
            backbone_relays=relay_ids,
            cluster_membership=_frozen_mapping(membership),
            paths_to_bs=_frozen_mapping(new_paths),
            routes=_frozen_nested_mapping(new_routes),
            control_paths=_frozen_mapping(new_control_paths),
            valid_edges=valid_edges,
            edge_costs=_frozen_mapping(edge_costs),
        )
        self._publish(snapshot, new_failures)
        return [
            by_id[node_id] for node_id in sorted(selected_ids)
            if not getattr(by_id[node_id], 'is_base_station', False)
        ]

    def _publish(self, snapshot, failures):
        self.active_snapshot = snapshot
        self.snapshot_epoch = snapshot.epoch
        self.snapshot_head_ids = snapshot.cluster_heads
        self.snapshot_backbone_ids = (
            snapshot.cluster_heads | snapshot.backbone_relays
        )
        self.last_paths = snapshot.paths_to_bs
        self.last_routes = snapshot.routes
        self.last_control_paths = snapshot.control_paths
        self.last_failures = _frozen_mapping(failures)

    def planned_path_for(self, source_id, target_id):
        if source_id == target_id:
            return (source_id,)
        routes = self.active_snapshot.routes
        path = [source_id]
        visited = {source_id}
        current_id = source_id
        while current_id != target_id:
            next_id = routes.get(current_id, {}).get(target_id)
            if next_id is None or next_id in visited:
                return ()
            path.append(next_id)
            visited.add(next_id)
            current_id = next_id
        return tuple(path)

    def path_for(self, source_id, target_id, forbidden_ids=()):
        snapshot = self.active_snapshot
        if source_id == target_id:
            return (source_id,)
        allowed_nodes = {
            drone.identifier for drone in self.simulator.drones
            if not getattr(drone, 'sleep', False)
        }
        if source_id not in allowed_nodes or target_id not in allowed_nodes:
            return ()
        blocked = set(forbidden_ids) - {source_id, target_id}
        adjacency = {}
        for start, end in snapshot.valid_edges:
            if start in blocked or end in blocked:
                continue
            adjacency.setdefault(start, []).append(end)
        queue = [(0.0, source_id)]
        distances = {source_id: 0.0}
        parents = {source_id: None}
        while queue:
            distance, node_id = heapq.heappop(queue)
            if distance != distances.get(node_id):
                continue
            if node_id == target_id:
                break
            for neighbor_id in sorted(adjacency.get(node_id, ())):
                edge_cost = snapshot.edge_costs.get(
                    (node_id, neighbor_id),
                    float('inf'),
                )
                candidate = distance + edge_cost
                if candidate < distances.get(neighbor_id, float('inf')):
                    distances[neighbor_id] = candidate
                    parents[neighbor_id] = node_id
                    heapq.heappush(queue, (candidate, neighbor_id))
        if target_id not in parents:
            return ()
        path = []
        node_id = target_id
        while node_id is not None:
            path.append(node_id)
            node_id = parents[node_id]
        return tuple(reversed(path))

    @staticmethod
    def _can_retain_path(
        path,
        head_id,
        target_ids,
        head_ids,
        retained_relay_ids,
        adjacency,
        by_id,
    ):
        if not path or path[0] != head_id or path[-1] not in target_ids:
            return False
        if any(node_id not in by_id for node_id in path):
            return False
        if any(
            target_id not in adjacency.get(source_id, ())
            for source_id, target_id in zip(path, path[1:])
        ):
            return False
        intermediate_relays = {
            node_id for node_id in path[1:-1]
            if node_id not in head_ids and node_id not in target_ids
        }
        return bool(intermediate_relays) and intermediate_relays.issubset(
            retained_relay_ids
        )

    def _build_routes(
        self,
        source_ids,
        target_ids,
        adjacency,
        by_id,
        predictions,
    ):
        routes = {}
        for source_id in sorted(source_ids):
            entries = {}
            for target_id in sorted(target_ids):
                if source_id == target_id:
                    continue
                path = self._dijkstra(
                    source_id,
                    {target_id},
                    adjacency,
                    by_id,
                    predictions,
                )
                if len(path) >= 2:
                    entries[target_id] = path[1]
            if entries:
                routes[source_id] = entries
        return routes

    def _dijkstra(self, start, targets, adjacency, by_id, predictions):
        queue = [(0.0, start)]
        distances = {start: 0.0}
        parents = {start: None}
        target = None
        while queue:
            distance, node_id = heapq.heappop(queue)
            if distance != distances.get(node_id):
                continue
            if node_id in targets:
                target = node_id
                break
            for neighbor_id in sorted(adjacency.get(node_id, ())):
                edge_cost = self.edge_cost(
                    by_id[node_id],
                    by_id[neighbor_id],
                    predictions,
                )
                candidate = distance + edge_cost
                if candidate < distances.get(neighbor_id, float('inf')):
                    distances[neighbor_id] = candidate
                    parents[neighbor_id] = node_id
                    heapq.heappush(queue, (candidate, neighbor_id))
        if target is None:
            return []
        path = []
        node_id = target
        while node_id is not None:
            path.append(node_id)
            node_id = parents[node_id]
        return list(reversed(path))

    def edge_cost(self, source, target, predictions):
        now_us = self.simulator.env.now
        tracker = self.simulator.link_reliability
        energy = tracker.normalized_expected_energy(
            source.identifier, target.identifier, now_us
        )
        quality = self.link_quality(source, target)
        tlet = self._normalized_tlet(source, target, predictions)
        burden = 0.0
        if config.USE_SERVICE_GUARD:
            burden = clamp01(
                target.transmitting_queue.qsize() / max(1, target.max_queue_size)
            )
        delay = tracker.normalized_delay(source.identifier, target.identifier, now_us)
        weights = config.BACKBONE_COST_WEIGHTS
        return (
            weights['energy'] * energy +
            weights['link_quality'] * (1.0 - quality) +
            weights['tlet'] * (1.0 - tlet) +
            weights['burden'] * burden +
            weights['delay'] * delay
        )

    @staticmethod
    def _trajectory(drone, predictions):
        trajectory = predictions.get(drone.identifier)
        if trajectory:
            return trajectory
        return [tuple(drone.coords)] * max(1, int(config.PREDICTION_HORIZON))

    def _normalized_tlet(self, source, target, predictions):
        source_traj = self._trajectory(source, predictions)
        target_traj = self._trajectory(target, predictions)
        seconds = trajectory_based_let(
            source_traj,
            target_traj,
            config.COMMUNICATION_RANGE,
        )
        return clamp01(seconds / max(1.0, float(config.PREDICTION_HORIZON)))
