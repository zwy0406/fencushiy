import json
import os

from utils import config


def clamp01(value):
    return max(0.0, min(1.0, value))


class WeightCalculator:
    def __init__(self, profile_name=None):
        self.profile_name = profile_name or config.MWMP_WEIGHT_PROFILE
        self.ga_weights = self._load_ga_weights()

    def _profile(self):
        return config.MWMP_WEIGHT_PROFILES[self.profile_name]

    def _load_ga_weights(self):
        if os.path.exists(config.GA_WEIGHT_FILE):
            with open(config.GA_WEIGHT_FILE, 'r', encoding='utf-8') as f:
                payload = json.load(f)
            weights = payload.get('weights', {})
            if weights:
                return weights
        return dict(config.GA_SCORE_WEIGHTS)

    def score(self, energy_ratio, link_quality, density, tlet_ratio, mobility_factor, **_):
        profile = self._profile()
        value = (
            profile['energy'] * clamp01(energy_ratio) +
            profile['link_quality'] * clamp01(link_quality) +
            profile['density'] * clamp01(density) +
            profile['tlet'] * clamp01(tlet_ratio) +
            profile['mobility'] * (1.0 - clamp01(mobility_factor))
        )
        return clamp01(value)

    def service_utility(self, network_score, service_burden):
        if not config.USE_SERVICE_GUARD:
            return clamp01(network_score)
        alpha = clamp01(config.SERVICE_GUARD_ALPHA)
        return clamp01(
            (1.0 - alpha) * clamp01(network_score) +
            alpha * (1.0 - clamp01(service_burden))
        )

    def normalize_link_quality(self, sinr_value):
        denominator = float(config.SNR_SATURATION - config.SNR_THRESHOLD)
        if denominator <= 0:
            raise ValueError('SNR_SATURATION must exceed SNR_THRESHOLD')
        return clamp01((sinr_value - config.SNR_THRESHOLD) / denominator)

    def normalize_density(self, density, max_density):
        if max_density <= 0:
            return 0.0
        return clamp01(density / max_density)

    def normalize_tlet(self, tlet_seconds, horizon_seconds=None):
        horizon_seconds = horizon_seconds or config.PREDICTION_HORIZON
        return clamp01(tlet_seconds / float(horizon_seconds))

    def normalize_mobility(self, displacement_ratio):
        return clamp01(displacement_ratio)

    def normalize_topology(self, topology_score):
        return clamp01(topology_score)

    def ga_score(self, energy_ratio, link_quality, tlet_ratio, topology_score, mobility_factor):
        weights = self.ga_weights
        value = (
            weights.get('w1_energy', 0.0) * clamp01(energy_ratio) +
            weights.get('w2_link_quality', 0.0) * clamp01(link_quality) +
            weights.get('w3_tlet', 0.0) * clamp01(tlet_ratio) +
            weights.get('w4_topology', 0.0) * clamp01(topology_score) -
            weights.get('w5_mobility', 0.0) * clamp01(mobility_factor)
        )
        return clamp01(value)
