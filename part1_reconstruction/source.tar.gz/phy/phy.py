import logging

from energy.energy_accounting import TX, communication_source, is_role_energy
from entities.packet import DataPacket
from utils import config

logging.basicConfig(
    filename='running_log.log',
    filemode='w',
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=config.LOGGING_LEVEL,
)


class Phy:
    """Physical-layer transmission and explicit network-energy accounting."""

    def __init__(self, mac):
        self.mac = mac
        self.env = mac.env
        self.my_drone = mac.my_drone

    def _begin_transmission(self, packet):
        packet._phy_tx_attempt = int(getattr(packet, '_phy_tx_attempt', 0)) + 1
        energy = packet.packet_length / config.BIT_RATE * config.TRANSMITTING_POWER
        self.my_drone.consume_energy(
            energy,
            source=communication_source(packet),
            direction=TX,
            role_energy=is_role_energy(packet, self.my_drone),
        )
        return packet._phy_tx_attempt

    def unicast(self, packet, next_hop_id):
        attempt_id = self._begin_transmission(packet)
        if isinstance(packet, DataPacket):
            self.my_drone.simulator.link_reliability.record_attempt(
                self.my_drone.identifier,
                next_hop_id,
                packet.packet_id,
                attempt_id,
                self.env.now,
            )
        message = [packet, self.env.now, self.my_drone.identifier, 0, packet.channel_id]
        self.my_drone.simulator.channel.unicast_put(message, next_hop_id)

    def broadcast(self, packet):
        self._begin_transmission(packet)
        message = [packet, self.env.now, self.my_drone.identifier, 0, packet.channel_id]
        self.my_drone.simulator.channel.broadcast_put(message)

    def multicast(self, packet, dst_id_list):
        yield self.env.timeout(packet.packet_length / config.BIT_RATE * 1e6)
        self._begin_transmission(packet)
        message = [packet, self.env.now, self.my_drone.identifier, 0, packet.channel_id]
        self.my_drone.simulator.channel.multicast_put(message, dst_id_list)
