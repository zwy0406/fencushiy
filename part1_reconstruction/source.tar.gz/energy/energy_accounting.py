from entities.packet import AckPacket, DataPacket


PROPULSION = 'propulsion'
DATA = 'data'
CONTROL = 'control'
TX = 'tx'
RX = 'rx'


def communication_source(packet):
    """Classify packets for the network-energy ledger."""
    if isinstance(packet, (DataPacket, AckPacket)):
        return DATA
    if hasattr(packet, 'ack_packet') or hasattr(packet, 'acked_packet'):
        return DATA
    return CONTROL


def acknowledged_packet(packet):
    return getattr(packet, 'ack_packet', getattr(packet, 'acked_packet', None))


def is_role_energy(packet, drone):
    data_packet = packet if isinstance(packet, DataPacket) else acknowledged_packet(packet)
    if data_packet is not None:
        src_id = getattr(getattr(data_packet, 'src_drone', None), 'identifier', None)
        dst_id = getattr(getattr(data_packet, 'dst_drone', None), 'identifier', None)
        return drone.identifier not in (src_id, dst_id)
    return (
        getattr(drone, 'cluster_role', None) == 'CH' or
        getattr(drone, 'is_backbone_connector', False)
    )
