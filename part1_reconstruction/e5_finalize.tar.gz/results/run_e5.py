"""Run frozen E5 H1/H2 and reuse the verified F0 H0 matrix."""

import argparse
import csv
import hashlib
import json
import math
import subprocess
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from experiments.e5_energy import CAPACITY_KJ, e5_assignment
from experiments.frozen_methods import FROZEN_METHODS
from experiments.run_frozen_experiments import FORMAL_METHODS, run_frozen_task


SEEDS = range(2030, 2040)
SEVERITIES = ('H1', 'H2')
F0 = Path('results/f0_formal_a3_seeds2030_2039_20261005')


def run_dir(root, severity, method, seed, attempt):
    return root / severity.lower() / method.lower() / f'seed{seed}' / f'attempt{attempt}'


def summary_path(directory, method, seed):
    return directory / 'metrics' / f'matrix_{method.lower()}_seed{seed}_summary.csv'


def trace_digest(path):
    digest = hashlib.sha256()
    with path.open(newline='', encoding='utf-8') as stream:
        for row in csv.DictReader(stream):
            digest.update(f"{row['packet_id']},{row['creation_time']}\n".encode())
    return digest.hexdigest()


def valid_run(directory, severity, method, seed):
    summary = summary_path(directory, method, seed)
    outcomes = directory / 'metrics' / 'packet_outcomes.csv'
    node_file = directory / 'metrics' / 'e5_node_energy.csv'
    if not all(path.is_file() for path in (summary, outcomes, node_file)):
        return False
    try:
        with summary.open(newline='', encoding='utf-8') as stream:
            rows = list(csv.DictReader(stream))
        with node_file.open(newline='', encoding='utf-8') as stream:
            nodes = list(csv.DictReader(stream))
        if len(rows) != 1 or len(nodes) != 80:
            return False
        row = rows[0]
        capacities, labels = e5_assignment(seed, severity)
        generated = int(row['packet_diag_generated'])
        return (
            row['method'] == method
            and int(row['seed']) == seed
            and int(row['number_of_drones']) == 80
            and float(row['traffic_rate_pps']) == 2.0
            and float(row['sim_time_s']) == 300.0
            and float(row['e5_total_initial_energy_j']) == 33_600_000.0
            and abs(float(row['energy_accounting_error_j'])) < 1e-8
            and float(row['packet_diag_max_delay_error_us']) <= 1e-6
            and generated == sum(int(row[key]) for key in (
                'packet_diag_delivered', 'packet_diag_terminal_drops',
                'packet_diag_incomplete_at_horizon',
            ))
            and all(
                math.isclose(float(node['initial_energy_j']),
                             capacities[int(node['node_id'])])
                and node['energy_class'] == labels[int(node['node_id'])]
                for node in nodes
            )
            and (method != 'PROPOSED' or row['backbone_relay_hold_rounds'] == '0')
        )
    except (OSError, ValueError, KeyError):
        return False


def completed_attempts(root, severity, method, seed):
    parent = root / severity.lower() / method.lower() / f'seed{seed}'
    return [path for path in sorted(parent.glob('attempt*'))
            if valid_run(path, severity, method, seed)]


def validate_f0():
    with (F0 / 'matrix_runs.csv').open(newline='', encoding='utf-8') as stream:
        rows = {(int(row['seed']), row['method']): row for row in csv.DictReader(stream)}
    assert len(rows) == 50
    for seed in SEEDS:
        trace = F0 / 'mobility_traces' / f'seed{seed}_n80_v15.json'
        assert trace.is_file(), trace
        digests = set()
        for method in FORMAL_METHODS:
            row = rows[seed, method]
            assert int(row['number_of_drones']) == 80
            assert float(row['traffic_rate_pps']) == 2.0
            assert float(row['sim_time_s']) == 300.0
            assert int(row['packet_diag_generated']) == sum(int(row[key]) for key in (
                'packet_diag_delivered', 'packet_diag_terminal_drops',
                'packet_diag_incomplete_at_horizon',
            ))
            assert abs(float(row['energy_accounting_error_j'])) < 1e-8
            output = F0 / method.lower() / f'seed{seed}'
            digests.add(trace_digest(output / 'metrics' / 'packet_outcomes.csv'))
        assert len(digests) == 1, seed


def build_tasks(root):
    tasks = []
    counts = {}
    for severity in SEVERITIES:
        counts[severity] = {'completed': 0, 'missing': 0}
        for seed in SEEDS:
            capacities, labels = e5_assignment(seed, severity)
            trace = (F0 / 'mobility_traces' / f'seed{seed}_n80_v15.json').resolve()
            for method in FORMAL_METHODS:
                complete = completed_attempts(root, severity, method, seed)
                if len(complete) > 1:
                    raise RuntimeError(f'Duplicate valid outputs: {complete}')
                if complete:
                    counts[severity]['completed'] += 1
                    continue
                parent = root / severity.lower() / method.lower() / f'seed{seed}'
                previous = [int(path.name.removeprefix('attempt'))
                            for path in parent.glob('attempt*')]
                attempt = max(previous, default=0) + 1
                counts[severity]['missing'] += 1
                tasks.append({
                    'phase': 'matrix', 'variant': method, 'seed': seed,
                    'severity': severity,
                    'trace_path': str(trace), 'n_drones': 80,
                    'output_dir': str(run_dir(root, severity, method, seed, attempt).resolve()),
                    'speed': 15.0, 'traffic_rate': 2.0, 'comm_range': 250.0,
                    'sim_time_s': 300.0,
                    'initial_energy_by_node': capacities,
                    'energy_class_by_node': labels,
                })
    return tasks, counts


def write_manifest(root, workers):
    manifest = {
        'experiment': 'E5',
        'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'n_nodes_including_bs': 80,
        'bs_node_id': 0,
        'bs_capacity_kj': 420,
        'uav_class_counts': {'Low': 20, 'Medium': 39, 'High': 20},
        'all_node_class_counts': {'Low': 20, 'Medium': 40, 'High': 20},
        'capacity_kj': CAPACITY_KJ,
        'energy_assignment': 'numpy default_rng(seed).permutation of non-BS node IDs',
        'total_initial_energy_j': 33_600_000,
        'speed_mps': 15.0, 'traffic_rate_pps_per_uav': 2.0,
        'comm_range_m': 250.0, 'sim_time_s': 300.0,
        'seeds': list(SEEDS), 'methods': list(FORMAL_METHODS),
        'method_profiles': FROZEN_METHODS,
        'h0_reused_from': str(F0),
        'mobility_traces': str(F0 / 'mobility_traces'),
        'packet_lifetime_s': 10,
        'workers': workers,
    }
    path = root / 'manifest.json'
    if path.is_file():
        if json.loads(path.read_text(encoding='utf-8')) != manifest:
            raise RuntimeError('E5 manifest differs from the frozen run')
    else:
        path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')


def validate_traffic(root):
    for seed in SEEDS:
        digests = set()
        for severity in SEVERITIES:
            for method in FORMAL_METHODS:
                complete = completed_attempts(root, severity, method, seed)
                if len(complete) != 1:
                    raise RuntimeError(f'Incomplete E5 group: {severity}, {seed}, {method}')
                digests.add(trace_digest(complete[0] / 'metrics' / 'packet_outcomes.csv'))
        if len(digests) != 1:
            raise RuntimeError(f'E5 traffic mismatch for seed {seed}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=8)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if not 1 <= args.workers <= 8:
        parser.error('workers must be between 1 and 8')
    validate_f0()
    tasks, counts = build_tasks(args.output_root)
    print(json.dumps({'counts': counts, 'queued': len(tasks)}), flush=True)
    if args.dry_run:
        return
    args.output_root.mkdir(parents=True, exist_ok=True)
    write_manifest(args.output_root, args.workers)
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = {executor.submit(run_frozen_task, task): task for task in tasks}
        for future in as_completed(futures):
            task = futures[future]
            method, seed, row = future.result()
            severity = task['severity']
            if method != task['variant'] or seed != task['seed']:
                raise RuntimeError(f'E5 task identity mismatch: {task}')
            if not valid_run(Path(task['output_dir']), severity, method, seed):
                raise RuntimeError(f'Invalid E5 run: {task}')
            print(json.dumps({'completed': [severity, method, seed],
                              'remaining': sum(not item.done() for item in futures)}),
                  flush=True)
    remaining, final_counts = build_tasks(args.output_root)
    if remaining:
        raise RuntimeError(f'E5 still has {len(remaining)} missing runs')
    validate_traffic(args.output_root)
    print(json.dumps({'final_counts': final_counts,
                      'traffic_trace_check': 'passed'}), flush=True)


if __name__ == '__main__':
    main()
