"""Validate and summarize the frozen E5 energy-heterogeneity matrix."""

import csv
import json
import math
import statistics
import sys
from pathlib import Path

sys.path.insert(0, 'results')
from run_e5 import (F0, FORMAL_METHODS, completed_attempts, summary_path,
                    trace_digest, valid_run)


ROOT = Path('results/e5_a3_energy_seeds2030_2039_20261015')
SEEDS = range(2030, 2040)
SEVERITIES = ('H0', 'H1', 'H2')
PRIMARY = (
    'pdr_percent', 'e_pkt_mj', 'delay_ms', 'routing_load',
    'control_energy_j', 'r_bs_route', 'relay_energy_jain',
    'network_lifetime_s', 'battery_remaining_ratio',
    'lifetime_drop_percent', 'queue_overflow_percent',
)
DIAGNOSTIC = (
    'e5_emergency_node_ratio', 'e5_sleep_node_ratio',
    'e5_final_soc_mean', 'e5_final_soc_p05', 'e5_final_soc_jain',
    'e5_low_ch_occupancy', 'e5_medium_ch_occupancy', 'e5_high_ch_occupancy',
    'e5_low_br_occupancy', 'e5_medium_br_occupancy', 'e5_high_br_occupancy',
    'e5_low_ch_share', 'e5_medium_ch_share', 'e5_high_ch_share',
    'e5_low_br_share', 'e5_medium_br_share', 'e5_high_br_share',
)


def read_one(path):
    with path.open(newline='', encoding='utf-8') as stream:
        records = list(csv.DictReader(stream))
    if len(records) != 1:
        raise RuntimeError(f'Expected one summary row: {path}')
    return records[0]


def measure(row, metric):
    if metric == 'e_pkt_mj':
        return 1000 * float(row['energy_per_delivered_packet_j'])
    if metric == 'delay_ms':
        return float(row['e2e_delay_ms'])
    if metric == 'r_bs_route':
        return float(row['bs_route_reachability_ratio'])
    if metric == 'lifetime_drop_percent':
        return 100 * int(row['drop_PacketLifetime']) / int(row['packet_diag_generated'])
    if metric == 'queue_overflow_percent':
        return 100 * int(row['drop_QueueOverflow']) / int(row['packet_diag_generated'])
    return float(row[metric])


def summarize(values):
    mean = statistics.mean(values)
    sd = statistics.stdev(values)
    half_width = 2.262157 * sd / math.sqrt(10)
    return mean, sd, mean - half_width, mean + half_width


def write_csv(path, rows):
    fields = sorted({key for row in rows for key in row})
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    with (F0 / 'matrix_runs.csv').open(newline='', encoding='utf-8') as stream:
        f0 = {(int(row['seed']), row['method']): row for row in csv.DictReader(stream)}
    if len(f0) != 50:
        raise RuntimeError('F0 must contain 50 verified H0 rows')
    rows = {}
    merged = []
    max_energy_error = 0.0
    max_delay_error = 0.0
    for severity in SEVERITIES:
        for seed in SEEDS:
            digests = set()
            for method in FORMAL_METHODS:
                if severity == 'H0':
                    row = f0[seed, method]
                    source = F0 / 'matrix_runs.csv'
                    directory = F0 / method.lower() / f'seed{seed}'
                else:
                    complete = completed_attempts(ROOT, severity, method, seed)
                    if len(complete) != 1:
                        raise RuntimeError(f'Missing E5 run: {severity}, {method}, {seed}')
                    directory = complete[0]
                    source = summary_path(directory, method, seed)
                    row = read_one(source)
                    if not valid_run(directory, severity, method, seed):
                        raise RuntimeError(f'Invalid E5 run: {directory}')
                if row['method'] != method or int(row['seed']) != seed:
                    raise RuntimeError(f'E5 identity mismatch: {source}')
                generated = int(row['packet_diag_generated'])
                delivered = int(row['packet_diag_delivered'])
                if generated != sum(int(row[key]) for key in (
                    'packet_diag_delivered', 'packet_diag_terminal_drops',
                    'packet_diag_incomplete_at_horizon',
                )) or delivered <= 0:
                    raise RuntimeError(f'Packet ledger failure: {source}')
                energy_error = abs(float(row['energy_accounting_error_j']))
                delay_error = abs(float(row['packet_diag_max_delay_error_us']))
                if energy_error >= 1e-8 or delay_error > 1e-6:
                    raise RuntimeError(f'Energy/delay ledger failure: {source}')
                max_energy_error = max(max_energy_error, energy_error)
                max_delay_error = max(max_delay_error, delay_error)
                digests.add(trace_digest(directory / 'metrics' / 'packet_outcomes.csv'))
                rows[severity, method, seed] = row
                merged.append({**row, 'e5_severity': severity, 'e5_source': str(source)})
            if len(digests) != 1:
                raise RuntimeError(f'Traffic mismatch: {severity}, seed={seed}')
    if len(merged) != 150:
        raise RuntimeError(f'Expected 150 merged E5 rows, got {len(merged)}')

    descriptive = []
    paired_method = []
    paired_severity = []
    for severity in SEVERITIES:
        metrics = PRIMARY + (DIAGNOSTIC if severity != 'H0' else ())
        for method in FORMAL_METHODS:
            for metric in metrics:
                values = [measure(rows[severity, method, seed], metric) for seed in SEEDS]
                if not all(math.isfinite(value) for value in values):
                    continue
                mean, sd, low, high = summarize(values)
                descriptive.append({
                    'severity': severity, 'method': method, 'metric': metric,
                    'n': 10, 'mean': mean, 'sd': sd, 'ci95_low': low, 'ci95_high': high,
                })
        for baseline in FORMAL_METHODS[:-1]:
            for metric in metrics:
                differences = [
                    measure(rows[severity, 'PROPOSED', seed], metric)
                    - measure(rows[severity, baseline, seed], metric)
                    for seed in SEEDS
                ]
                if not all(math.isfinite(value) for value in differences):
                    continue
                mean, sd, low, high = summarize(differences)
                paired_method.append({
                    'severity': severity, 'baseline': baseline, 'metric': metric,
                    'n': 10, 'delta_mean': mean, 'delta_sd': sd,
                    'ci95_low': low, 'ci95_high': high,
                })
    for earlier, later in (('H0', 'H1'), ('H1', 'H2'), ('H0', 'H2')):
        metrics = PRIMARY + (DIAGNOSTIC if earlier != 'H0' else ())
        for method in FORMAL_METHODS:
            for metric in metrics:
                differences = [
                    measure(rows[later, method, seed], metric)
                    - measure(rows[earlier, method, seed], metric)
                    for seed in SEEDS
                ]
                if not all(math.isfinite(value) for value in differences):
                    continue
                mean, sd, low, high = summarize(differences)
                paired_severity.append({
                    'earlier': earlier, 'later': later, 'method': method,
                    'metric': metric, 'n': 10, 'delta_mean': mean, 'delta_sd': sd,
                    'ci95_low': low, 'ci95_high': high,
                })
    write_csv(ROOT / 'e5_merged_runs.csv', merged)
    write_csv(ROOT / 'e5_descriptive.csv', descriptive)
    write_csv(ROOT / 'e5_paired_method.csv', paired_method)
    write_csv(ROOT / 'e5_paired_severity.csv', paired_severity)
    audit = {
        'validated_runs': len(merged), 'h0_reused_runs': 50,
        'new_h1_h2_runs': 100, 'max_energy_accounting_error_j': max_energy_error,
        'max_packet_delay_error_us': max_delay_error,
        'traffic_pairing_groups': 30,
        'h0_e5_node_diagnostics': 'not available in the original F0 artifacts',
    }
    (ROOT / 'e5_integrity.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps(audit), flush=True)
    for severity in SEVERITIES:
        print('SEVERITY', severity)
        for method in FORMAL_METHODS:
            output = []
            for metric in ('pdr_percent', 'e_pkt_mj', 'delay_ms', 'routing_load',
                           'control_energy_j', 'r_bs_route'):
                values = [measure(rows[severity, method, seed], metric) for seed in SEEDS]
                output.append(f'{metric}={statistics.mean(values):.4f}+-{statistics.stdev(values):.4f}')
            print(method, ' '.join(output))


if __name__ == '__main__':
    main()
