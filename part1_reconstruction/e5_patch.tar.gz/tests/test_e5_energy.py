import math
import unittest
from types import SimpleNamespace

from entities.drone import Drone
from experiments.e5_energy import e5_assignment
from simulator.metrics import Metrics
from topology.mwmp_dca.cluster_rotation import ClusterRotationManager


class E5EnergyTests(unittest.TestCase):
    def test_frozen_assignments_preserve_total_and_pair_labels(self):
        h0, labels0 = e5_assignment(2030, 'H0')
        h1, labels1 = e5_assignment(2030, 'H1')
        h2, labels2 = e5_assignment(2030, 'H2')
        self.assertEqual(labels0, labels1)
        self.assertEqual(labels1, labels2)
        self.assertEqual(labels0[0], 'Medium')
        self.assertEqual([list(labels1.values()).count(label) for label in
                          ('Low', 'Medium', 'High')], [20, 40, 20])
        for capacities in (h0, h1, h2):
            self.assertEqual(math.fsum(capacities.values()), 33_600_000.0)
        self.assertEqual(set(h0.values()), {420_000.0})
        self.assertEqual({h1[node] for node, label in labels1.items() if label == 'Low'},
                         {336_000.0})
        self.assertEqual({h2[node] for node, label in labels2.items() if label == 'High'},
                         {588_000.0})
        self.assertEqual(e5_assignment(2030, 'H1'), (h1, labels1))
        self.assertNotEqual(e5_assignment(2031, 'H1')[1], labels1)

    def test_sleep_threshold_scales_with_node_capacity(self):
        node = SimpleNamespace(
            initial_energy=252_000.0, residual_energy=252_000.0,
            propulsion_energy=0.0, communication_energy=0.0,
            data_energy=0.0, control_energy=0.0, tx_energy=0.0,
            rx_energy=0.0, relay_role_energy=0.0, sleep=False,
            env=SimpleNamespace(now=12_000_000), first_sleep_time_us=None,
        )
        Drone.consume_energy(node, 226_799.0, source='propulsion')
        self.assertFalse(node.sleep)
        Drone.consume_energy(node, 2.0, source='propulsion')
        self.assertTrue(node.sleep)
        self.assertEqual(node.first_sleep_time_us, 12_000_000)
        self.assertAlmostEqual(node.residual_energy, 25_199.0)

    def test_emergency_rotation_uses_own_initial_energy(self):
        low = SimpleNamespace(initial_energy=252_000.0, residual_energy=63_000.0)
        high = SimpleNamespace(initial_energy=588_000.0, residual_energy=147_000.0)
        rotation = ClusterRotationManager()
        self.assertTrue(rotation.should_rotate(low, object(), 0))
        self.assertTrue(rotation.should_rotate(high, object(), 0))

    def test_e5_summary_uses_uavs_and_class_role_samples(self):
        bs = SimpleNamespace(is_base_station=True, initial_energy=420_000.0)
        low = SimpleNamespace(is_base_station=False, energy_class='Low',
                              initial_energy=252_000.0, residual_energy=63_000.0,
                              sleep=False, first_sleep_time_us=None)
        high = SimpleNamespace(is_base_station=False, energy_class='High',
                               initial_energy=588_000.0, residual_energy=58_000.0,
                               sleep=True, first_sleep_time_us=25_000_000)
        metrics = SimpleNamespace(
            simulator=SimpleNamespace(drones=[bs, low, high]),
            energy_class_sample_count=2,
            energy_class_role_samples={
                'Low': {'CH': 1, 'BR': 0},
                'Medium': {'CH': 0, 'BR': 0},
                'High': {'CH': 0, 'BR': 2},
            },
        )
        result = Metrics._e5_energy_summary(metrics)
        self.assertEqual(result['e5_total_initial_energy_j'], 1_260_000.0)
        self.assertEqual(result['e5_low_ch_occupancy'], 0.5)
        self.assertEqual(result['e5_high_br_occupancy'], 1.0)
        self.assertEqual(result['e5_first_uav_sleep_s'], 25.0)
        self.assertEqual(result['e5_emergency_node_ratio'], 0.5)


if __name__ == '__main__':
    unittest.main()
