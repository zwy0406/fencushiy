import argparse
import csv
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from experiments.frozen_methods import FROZEN_METHODS
from experiments.generate_mobility_trace import generate_trace
from experiments.run_experiment import run_once
from utils import config


FORMAL_METHODS = ('DSDV', 'MOBIC', 'ORIGINAL_MWMP', 'TORP_LIKE', 'PROPOSED')
E8_MODES = ('current', 'kinematic', 'oracle')


def parse_seeds(value):
    return [int(item) for item in value.split(',') if item]


def write_rows(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_manifest(root, args):
    manifest = {
        'phase': args.phase,
        'seeds': parse_seeds(args.seeds),
        'n_drones': args.n_drones,
        'speed_mps': args.speed,
        'traffic_rate_pps': args.traffic_rate,
        'comm_range_m': args.comm_range,
        'sim_time_s': args.sim_time_s,
        'parallel_workers': args.workers,
        'methods': FORMAL_METHODS,
        'e8_modes': E8_MODES,
        'method_profiles': FROZEN_METHODS,
        'energy_accounting': 'shared_tx_rx_for_all_methods',
        'delta_direction': {
            'pdr': 'proposed_minus_baseline_positive_is_better',
            'e_pkt': 'proposed_minus_baseline_negative_is_better',
            'r_bs': 'proposed_minus_baseline_positive_is_better',
        },
    }
    (root / 'manifest.json').write_text(
        json.dumps(manifest, indent=2), encoding='utf-8'
    )


def run_frozen_task(task):
    variant = task['variant']
    method = variant if task['phase'] == 'matrix' else 'PROPOSED'
    predictor = 'kinematic' if task['phase'] == 'matrix' else variant
    experiment = f"{task['phase']}_{variant.lower()}_seed{task['seed']}"
    row = run_once(
        protocol='DSDV',
        seed=task['seed'],
        n_drones=task['n_drones'],
        output_dir=task['output_dir'],
        speed=task['speed'],
        experiment_name=experiment,
        predictor_mode=predictor,
        traffic_rate=task['traffic_rate'],
        comm_range=task['comm_range'],
        sim_time_s=task['sim_time_s'],
        method=method,
        mobility_trace_mode='replay',
        mobility_trace_file=task['trace_path'],
        packet_diagnostics=True,
        initial_energy_by_node=task.get('initial_energy_by_node'),
        energy_class_by_node=task.get('energy_class_by_node'),
    )
    generated = row['packet_diag_generated']
    row['packet_lifetime_drop_rate'] = row['drop_PacketLifetime'] / generated
    row['queue_overflow_rate'] = row['drop_QueueOverflow'] / generated
    row['frozen_variant'] = variant
    return variant, task['seed'], row


def main():
    parser = argparse.ArgumentParser(description='Frozen paired experiment entry')
    parser.add_argument('--phase', choices=['matrix', 'e8'], required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--seeds', default='2025,2026,2027')
    parser.add_argument('--n-drones', type=int, default=80)
    parser.add_argument('--speed', type=float, default=15.0)
    parser.add_argument('--traffic-rate', type=float, default=2.0)
    parser.add_argument('--comm-range', type=float, default=config.COMMUNICATION_RANGE)
    parser.add_argument('--sim-time-s', type=float, required=True)
    parser.add_argument('--workers', type=int, default=15)
    args = parser.parse_args()

    root = Path(args.output_dir)
    trace_root = root / 'mobility_traces'
    root.mkdir(parents=True, exist_ok=True)
    write_manifest(root, args)
    seeds = parse_seeds(args.seeds)
    trace_paths = {}
    for seed in seeds:
        trace_path = trace_root / f'seed{seed}_n{args.n_drones}_v{args.speed:g}.json'
        if not trace_path.exists():
            generate_trace(
                seed, args.n_drones, args.speed, args.sim_time_s, trace_path
            )
        trace_paths[seed] = trace_path

    variants = FORMAL_METHODS if args.phase == 'matrix' else E8_MODES
    tasks = []
    for seed in seeds:
        for variant in variants:
            tasks.append({
                'phase': args.phase,
                'variant': variant,
                'seed': seed,
                'trace_path': str(trace_paths[seed]),
                'n_drones': args.n_drones,
                'output_dir': str(root / variant.lower() / f'seed{seed}'),
                'speed': args.speed,
                'traffic_rate': args.traffic_rate,
                'comm_range': args.comm_range,
                'sim_time_s': args.sim_time_s,
            })

    rows = []
    workers = max(1, min(args.workers, len(tasks)))
    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(run_frozen_task, task) for task in tasks]
        for future in as_completed(futures):
            variant, seed, row = future.result()
            rows.append(row)
            print({'completed': f'{variant}/seed{seed}'}, flush=True)

    variant_order = {name: index for index, name in enumerate(variants)}
    rows.sort(key=lambda row: (
        int(row['seed']), variant_order[row['frozen_variant']]
    ))
    write_rows(root / f'{args.phase}_runs.csv', rows)
    print({'phase': args.phase, 'runs': len(rows), 'output': str(root)})


if __name__ == '__main__':
    main()
