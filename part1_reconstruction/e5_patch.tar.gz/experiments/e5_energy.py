"""Frozen node-level battery assignments for E5."""

import math

import numpy as np

from utils import config


CAPACITY_KJ = {
    'H0': {'Low': 420, 'Medium': 420, 'High': 420},
    'H1': {'Low': 336, 'Medium': 420, 'High': 504},
    'H2': {'Low': 252, 'Medium': 420, 'High': 588},
}


def e5_assignment(seed, severity, n_nodes=80):
    if severity not in CAPACITY_KJ:
        raise ValueError(f'Unknown E5 severity: {severity}')
    if n_nodes != 80 or config.BS_NODE_ID not in range(n_nodes):
        raise ValueError('The frozen E5 assignment requires 80 nodes including BS')

    # Keep BS at the center capacity; permute only the 79 role-eligible UAVs.
    uav_ids = [node_id for node_id in range(n_nodes) if node_id != config.BS_NODE_ID]
    permuted = np.random.default_rng(int(seed)).permutation(uav_ids)
    classes = {config.BS_NODE_ID: 'Medium'}
    classes.update({int(node_id): 'Low' for node_id in permuted[:20]})
    classes.update({int(node_id): 'Medium' for node_id in permuted[20:59]})
    classes.update({int(node_id): 'High' for node_id in permuted[59:]})
    capacities = {
        node_id: float(CAPACITY_KJ[severity][label] * 1000)
        for node_id, label in classes.items()
    }
    assert len(capacities) == n_nodes
    assert math.fsum(capacities.values()) == 33_600_000.0
    return capacities, classes
