import csv
import math
import os
from collections import defaultdict

import numpy as np
from openpyxl import Workbook

from utils import config
from utils.util_function import euclidean_distance_3d
from simulator.packet_diagnostics import PacketDiagnostics


class Metrics:
    """
    Network-level statistics and export helpers for baseline and clustering studies.
    """

    def __init__(self, simulator):
        self.simulator = simulator

        self.control_packet_num = 0

        self.datapacket_generated = set()
        self.datapacket_arrived = set()
        self.datapacket_generated_num = 0
        self.delivered_bits = 0

        self.delivery_time = []
        self.deliver_time_dict = defaultdict()

        self.throughput = []
        self.throughput_dict = defaultdict()

        self.hop_cnt = []
        self.hop_cnt_dict = defaultdict()

        self.mac_delay = []

        self.collision_num = 0
        self.poi_coverage_ratio = []
        self.connected_ratio = []
        self.control_packet_breakdown = {
            'total': 0,
            'dsdv': 0,
            'backbone': 0,
            'cluster': 0,
            'torp': 0,
        }
        self.routing_resilience = defaultdict(int)
        self.migration_audit_rows = []
        self.network_lifetime_us = None
        self.metric_timeseries = []
        self.path_stretch = []
        self.path_stretch_unavailable = 0
        self.delivered_via_ch = 0
        self.delivered_via_br = 0
        self.queue_wait_us = {
            'CH': [], 'BR': [], 'CM': [],
        }
        self.energy_class_role_samples = {
            label: {'CH': 0, 'BR': 0}
            for label in ('Low', 'Medium', 'High')
        }
        self.energy_class_sample_count = 0
        self.packet_diagnostics = PacketDiagnostics(self) if config.PACKET_DIAGNOSTICS else None

    def calculate_metrics(self, received_packet):
        if self.packet_diagnostics is not None:
            self.packet_diagnostics.delivered(received_packet, self.simulator.env.now)
        latency = self.simulator.env.now - received_packet.creation_time
        self.deliver_time_dict[received_packet.packet_id] = latency
        self.throughput_dict[received_packet.packet_id] = received_packet.packet_length / (latency / 1e6)
        self.hop_cnt_dict[received_packet.packet_id] = received_packet.get_current_ttl()
        self.datapacket_arrived.add(received_packet.packet_id)
        self.delivered_bits += received_packet.packet_length

        actual_hops = max(
            1,
            len(getattr(received_packet, 'forwarding_path', ())),
        )
        shortest_hops = self._shortest_physical_hops(
            received_packet.src_drone.identifier,
            received_packet.dst_drone.identifier,
        )
        if shortest_hops is None:
            self.path_stretch_unavailable += 1
        else:
            self.path_stretch.append(actual_hops / max(1, shortest_hops))
        if getattr(received_packet, 'passed_ch', False):
            self.delivered_via_ch += 1
        if getattr(received_packet, 'passed_br', False):
            self.delivered_via_br += 1

    def print_metrics(self):
        pdr = self._current_pdr()
        e2e_delay = self._current_e2e_delay()
        throughput = self._current_throughput()
        hop_cnt = self._current_hop_count()
        rl = self._current_routing_load()
        average_mac_delay = np.mean(self.mac_delay) if self.mac_delay else 0.0

        print('Totally send: ', self.datapacket_generated_num, ' data packets')
        print('Packet delivery ratio is: ', pdr, '%')
        print('Average end-to-end delay is: ', e2e_delay, 'ms')
        print('Routing load is: ', rl)
        print('Average throughput is: ', throughput, 'Kbps')
        print('Average hop count is: ', hop_cnt)
        print('Collision num is: ', self.collision_num)
        print('Average mac delay is: ', average_mac_delay, 'ms')

    def _current_pdr(self):
        if self.datapacket_generated_num == 0:
            return 0.0
        return len(self.datapacket_arrived) / self.datapacket_generated_num * 100

    def _current_e2e_delay(self):
        return np.mean(list(self.deliver_time_dict.values())) / 1e3 if self.deliver_time_dict else 0.0

    def _current_throughput(self):
        elapsed_seconds = max(self.simulator.env.now / 1e6, 1e-9)
        return (self.delivered_bits / elapsed_seconds) / 1e3

    def _current_hop_count(self):
        return np.mean(list(self.hop_cnt_dict.values())) if self.hop_cnt_dict else 0.0

    def _current_routing_load(self):
        return self.control_packet_num / len(self.datapacket_arrived) if self.datapacket_arrived else 0.0

    def _current_connectivity_ratio(self):
        drones = [drone for drone in self.simulator.drones if not getattr(drone, 'is_base_station', False)]
        node_count = len(drones)
        if node_count == 0:
            return 0.0

        adjacency = {drone.identifier: set() for drone in drones}
        for idx, drone in enumerate(drones):
            for other in drones[idx + 1:]:
                if euclidean_distance_3d(drone.coords, other.coords) <= config.COMMUNICATION_RANGE:
                    adjacency[drone.identifier].add(other.identifier)
                    adjacency[other.identifier].add(drone.identifier)

        visited = set()
        largest_component = 0
        for drone in drones:
            if drone.identifier in visited:
                continue
            stack = [drone.identifier]
            size = 0
            while stack:
                current = stack.pop()
                if current in visited:
                    continue
                visited.add(current)
                size += 1
                stack.extend(adjacency[current] - visited)
            largest_component = max(largest_component, size)
        return largest_component / node_count

    def _shortest_physical_hops(self, source_id, target_id):
        active = [drone for drone in self.simulator.drones if not drone.sleep]
        by_id = {drone.identifier: drone for drone in active}
        if source_id not in by_id or target_id not in by_id:
            return None
        queue = [(source_id, 0)]
        visited = {source_id}
        for current_id, hops in queue:
            if current_id == target_id:
                return hops
            current = by_id[current_id]
            for candidate_id, candidate in by_id.items():
                if candidate_id in visited:
                    continue
                if euclidean_distance_3d(
                    current.coords, candidate.coords
                ) <= config.COMMUNICATION_RANGE:
                    visited.add(candidate_id)
                    queue.append((candidate_id, hops + 1))
        return None

    @staticmethod
    def _role_label(drone):
        if getattr(drone, 'is_backbone_connector', False):
            return 'BR'
        if getattr(drone, 'cluster_role', None) == 'CH':
            return 'CH'
        return 'CM'

    def record_queue_wait(self, drone, wait_us):
        if wait_us < 0:
            raise ValueError('Queue wait cannot be negative')
        role = self._role_label(drone)
        self.queue_wait_us[role].append(wait_us)

    def _role_queue_depths(self):
        values = {'CH': [], 'BR': [], 'CM': []}
        for drone in self.simulator.drones:
            if getattr(drone, 'is_base_station', False):
                continue
            depth = drone.transmitting_queue.qsize() + len(drone.waiting_list)
            values[self._role_label(drone)].append(depth)
        return {
            role: float(np.mean(depths)) if depths else 0.0
            for role, depths in values.items()
        }

    def _physical_bs_reachability_ratio(self):
        active = [
            drone for drone in self.simulator.drones
            if not getattr(drone, 'sleep', False)
        ]
        bs_ids = {
            drone.identifier for drone in active
            if getattr(drone, 'is_base_station', False)
        }
        sources = [
            drone for drone in active
            if drone.identifier not in bs_ids
        ]
        if not sources or not bs_ids:
            return 0.0
        adjacency = {drone.identifier: set() for drone in active}
        for index, drone in enumerate(active):
            for other in active[index + 1:]:
                if euclidean_distance_3d(
                    drone.coords, other.coords
                ) <= config.COMMUNICATION_RANGE:
                    adjacency[drone.identifier].add(other.identifier)
                    adjacency[other.identifier].add(drone.identifier)
        reachable = set(bs_ids)
        stack = list(bs_ids)
        while stack:
            current = stack.pop()
            unseen = adjacency.get(current, set()) - reachable
            reachable.update(unseen)
            stack.extend(unseen)
        return sum(
            drone.identifier in reachable for drone in sources
        ) / len(sources)

    def _routing_bs_reachability_ratio(self):
        active = [
            drone for drone in self.simulator.drones
            if not getattr(drone, 'sleep', False)
        ]
        bs_ids = {
            drone.identifier for drone in active
            if getattr(drone, 'is_base_station', False)
        }
        sources = [
            drone for drone in active
            if drone.identifier not in bs_ids
        ]
        if not sources or not bs_ids:
            return 0.0
        return sum(
            self._node_has_bs_route(drone, bs_ids)
            for drone in sources
        ) / len(sources)

    def _node_has_bs_route(self, drone, bs_ids):
        torp_planner = getattr(self.simulator, 'torp_like_planner', None)
        if torp_planner is not None:
            return any(
                torp_planner.has_route(drone.identifier, bs_id)
                for bs_id in bs_ids
            )

        routing = getattr(drone, 'routing_protocol', None)
        table = getattr(getattr(routing, 'routing_table', None), 'table', {})
        if any(self._valid_table_entry(table, drone.identifier, bs_id) for bs_id in bs_ids):
            return True

        manager = getattr(self.simulator, 'cluster_manager', None)
        if manager is None:
            return False
        gateway = drone
        if getattr(drone, 'cluster_role', None) == 'CM' and not getattr(
            drone, 'is_backbone_connector', False
        ):
            gateway = getattr(drone, 'cluster_head', None)
            if gateway is None or gateway.identifier == drone.identifier:
                return False
            if euclidean_distance_3d(
                drone.coords, gateway.coords
            ) > config.COMMUNICATION_RANGE:
                return False

        planner = getattr(manager, 'backbone_planner', None)
        if planner is not None and any(
            planner.planned_path_for(gateway.identifier, bs_id)
            for bs_id in bs_ids
        ):
            return True
        gateway_routing = getattr(gateway, 'routing_protocol', None)
        backbone_router = getattr(gateway_routing, 'backbone_router', None)
        backbone_table = getattr(
            getattr(backbone_router, 'routing_table', None), 'table', {}
        )
        return any(
            self._valid_table_entry(
                backbone_table, gateway.identifier, bs_id
            )
            for bs_id in bs_ids
        )

    @staticmethod
    def _valid_table_entry(table, source_id, target_id):
        entry = table.get(target_id)
        return bool(
            entry and entry[0] != source_id and entry[1] != float('inf')
        )

    def _energy_snapshot(self):
        drones = list(self.simulator.drones)
        network_energy = math.fsum(getattr(drone, 'communication_energy', 0.0) for drone in drones)
        data_energy = math.fsum(getattr(drone, 'data_energy', 0.0) for drone in drones)
        control_energy = math.fsum(getattr(drone, 'control_energy', 0.0) for drone in drones)
        propulsion_energy = math.fsum(getattr(drone, 'propulsion_energy', 0.0) for drone in drones)
        tx_energy = math.fsum(getattr(drone, 'tx_energy', 0.0) for drone in drones)
        rx_energy = math.fsum(getattr(drone, 'rx_energy', 0.0) for drone in drones)
        role_values = [
            getattr(drone, 'relay_role_energy', 0.0)
            for drone in drones
            if not getattr(drone, 'is_base_station', False)
        ]
        role_sum = sum(role_values)
        role_square_sum = sum(value * value for value in role_values)
        relay_fairness = (
            role_sum * role_sum / (len(role_values) * role_square_sum)
            if role_values and role_square_sum > 0 else 1.0
        )
        delivered = len(self.datapacket_arrived)
        return {
            'network_energy_j': network_energy,
            'data_energy_j': data_energy,
            'control_energy_j': control_energy,
            'propulsion_energy_j': propulsion_energy,
            'tx_energy_j': tx_energy,
            'rx_energy_j': rx_energy,
            'relay_role_energy_j': role_sum,
            'relay_energy_jain': relay_fairness,
            'energy_per_delivered_packet_j': (
                network_energy / delivered if delivered else float('nan')
            ),
            'energy_metric_valid': bool(delivered),
        }

    def record_timeseries(self):
        role_depths = self._role_queue_depths()
        if self.simulator.energy_class_by_node is not None:
            self.energy_class_sample_count += 1
            for drone in self.simulator.drones:
                if drone.is_base_station:
                    continue
                role = self._role_label(drone)
                if role in ('CH', 'BR'):
                    self.energy_class_role_samples[drone.energy_class][role] += 1
        self.metric_timeseries.append({
            'time_s': self.simulator.env.now / 1e6,
            'pdr_percent': self._current_pdr(),
            'e2e_delay_ms': self._current_e2e_delay(),
            'throughput_kbps': self._current_throughput(),
            'routing_load': self._current_routing_load(),
            'connectivity_ratio': self._current_connectivity_ratio(),
            'bs_route_reachability_ratio': self._routing_bs_reachability_ratio(),
            'bs_graph_reachability_ratio': self._physical_bs_reachability_ratio(),
            'control_packet_total': self.control_packet_breakdown['total'],
            'control_packet_dsdv': self.control_packet_breakdown['dsdv'],
            'control_packet_backbone': self.control_packet_breakdown['backbone'],
            'control_packet_cluster': self.control_packet_breakdown['cluster'],
            'control_packet_torp': self.control_packet_breakdown['torp'],
            'torp_snapshot_age_us': self._torp_snapshot_age_us(),
            'ch_queue_depth': role_depths['CH'],
            'br_queue_depth': role_depths['BR'],
            'cm_queue_depth': role_depths['CM'],
            'network_energy_j': sum(
                getattr(drone, 'communication_energy', 0.0)
                for drone in self.simulator.drones
            ),
        })

    def collect_summary(self):
        pdr = self._current_pdr()
        e2e_delay = self._current_e2e_delay()
        throughput = self._current_throughput()
        hop_cnt = self._current_hop_count()
        rl = self._current_routing_load()
        average_mac_delay = np.mean(self.mac_delay) if self.mac_delay else 0.0
        residual_energy = math.fsum(
            drone.residual_energy for drone in self.simulator.drones
        )
        initial_energy = math.fsum(
            getattr(drone, 'initial_energy', config.INITIAL_ENERGY)
            for drone in self.simulator.drones
        )
        energy_consumption = math.fsum(
            getattr(
                drone,
                'battery_energy_consumed',
                math.fsum((
                    getattr(drone, 'propulsion_energy', 0.0),
                    getattr(drone, 'communication_energy', 0.0),
                )),
            )
            for drone in self.simulator.drones
        )
        battery_remaining_ratio = (
            residual_energy / initial_energy if initial_energy else float('nan')
        )
        if self.network_lifetime_us is None:
            sleeping = [drone for drone in self.simulator.drones if getattr(drone, 'sleep', False)]
            if sleeping:
                self.network_lifetime_us = self.simulator.env.now
        network_lifetime = (self.network_lifetime_us or self.simulator.env.now) / 1e6
        poi_coverage = np.mean(self.poi_coverage_ratio) if self.poi_coverage_ratio else 0.0
        connected_ratio = np.mean(self.connected_ratio) if self.connected_ratio else self._current_connectivity_ratio()
        energy_summary = self._energy_snapshot()
        component_error = math.fsum(
            abs(math.fsum((
                getattr(drone, 'battery_energy_consumed', 0.0),
                -getattr(drone, 'propulsion_energy', 0.0),
                -getattr(drone, 'communication_energy', 0.0),
            )))
            for drone in self.simulator.drones
        )
        balance_error = math.fsum(
            abs(math.fsum((
                getattr(drone, 'initial_energy', config.INITIAL_ENERGY),
                -drone.residual_energy,
                -getattr(drone, 'battery_energy_consumed', 0.0),
            )))
            for drone in self.simulator.drones
        )
        accounting_error = max(component_error, balance_error)
        cluster_summary = {}
        if getattr(self.simulator, 'cluster_manager', None) is not None:
            cluster_summary = self.simulator.cluster_manager.metrics.summary()

        route_samples = [
            row['bs_route_reachability_ratio'] for row in self.metric_timeseries
        ]
        graph_samples = [
            row['bs_graph_reachability_ratio'] for row in self.metric_timeseries
        ]
        route_reachability = (
            np.mean(route_samples) if route_samples
            else self._routing_bs_reachability_ratio()
        )
        graph_reachability = (
            np.mean(graph_samples) if graph_samples
            else self._physical_bs_reachability_ratio()
        )
        delivered = len(self.datapacket_arrived)
        role_depth_means = {
            role: np.mean([
                row[f'{role.lower()}_queue_depth'] for row in self.metric_timeseries
            ]) if self.metric_timeseries else 0.0
            for role in ('CH', 'BR', 'CM')
        }
        queue_wait_means = {
            role: (np.mean(values) / 1e3 if values else 0.0)
            for role, values in self.queue_wait_us.items()
        }
        summary = {
            'experiment': config.EXPERIMENT_NAME,
            'protocol': config.ROUTING_PROTOCOL,
            'method': config.EXPERIMENT_METHOD,
            'e7_profile': config.E7_PROFILE,
            'mwmp_decision_mode': config.MWMP_DECISION_MODE,
            'use_service_guard': config.USE_SERVICE_GUARD,
            'use_backbone_connectors': config.USE_BACKBONE_CONNECTORS,
            'backbone_relay_hold_rounds': config.BACKBONE_RELAY_HOLD_ROUNDS,
            'seed': self.simulator.seed,
            'number_of_drones': self.simulator.n_drones,
            'pdr_percent': pdr,
            'e2e_delay_ms': e2e_delay,
            'routing_load': rl,
            'throughput_kbps': throughput,
            'hop_count': hop_cnt,
            'collision_num': self.collision_num,
            'mac_delay_ms': average_mac_delay,
            'datapacket_generated': self.datapacket_generated_num,
            'datapacket_arrived': len(self.datapacket_arrived),
            'control_packet_num': self.control_packet_num,
            'control_packet_total': self.control_packet_breakdown['total'],
            'control_packet_dsdv': self.control_packet_breakdown['dsdv'],
            'control_packet_backbone': self.control_packet_breakdown['backbone'],
            'control_packet_cluster': self.control_packet_breakdown['cluster'],
            'control_packet_torp': self.control_packet_breakdown['torp'],
            'residual_energy_j': residual_energy,
            'energy_consumption_j': energy_consumption,
            'battery_remaining_ratio': battery_remaining_ratio,
            'energy_accounting_error_j': accounting_error,
            'network_lifetime_s': network_lifetime,
            'poi_coverage_ratio': poi_coverage,
            'connected_ratio': connected_ratio,
            'mobility_model': config.MOBILITY_MODEL,
            'comm_range_m': config.COMMUNICATION_RANGE,
            'bs_route_reachability_ratio': route_reachability,
            'bs_graph_reachability_ratio': graph_reachability,
            'torp_snapshot_age_us': self._torp_snapshot_age_us(),
            'path_stretch_mean': np.mean(self.path_stretch) if self.path_stretch else float('nan'),
            'path_stretch_samples': len(self.path_stretch),
            'path_stretch_unavailable': self.path_stretch_unavailable,
            'ch_pass_ratio': self.delivered_via_ch / delivered if delivered else float('nan'),
            'br_pass_ratio': self.delivered_via_br / delivered if delivered else float('nan'),
            'ch_queue_depth_mean': role_depth_means['CH'],
            'br_queue_depth_mean': role_depth_means['BR'],
            'cm_queue_depth_mean': role_depth_means['CM'],
            'ch_queue_wait_ms': queue_wait_means['CH'],
            'br_queue_wait_ms': queue_wait_means['BR'],
            'cm_queue_wait_ms': queue_wait_means['CM'],
        }
        summary.update(energy_summary)
        if self.simulator.energy_class_by_node is not None:
            summary.update(self._e5_energy_summary())
        summary.update(self._routing_resilience_summary())
        summary.update(cluster_summary)
        if self.packet_diagnostics is not None:
            summary.update(self.packet_diagnostics.summary(self.simulator.env.now))
        return summary

    def export_results(self, output_dir=None):
        output_root = output_dir or config.RESULTS_DIR
        metrics_dir = os.path.join(output_root, config.RESULTS_METRICS_DIRNAME)
        figures_dir = os.path.join(output_root, config.RESULTS_FIGURES_DIRNAME)
        os.makedirs(metrics_dir, exist_ok=True)
        os.makedirs(figures_dir, exist_ok=True)
        summary = self.collect_summary()

        csv_path = os.path.join(metrics_dir, f'{config.EXPERIMENT_NAME}_summary.csv')
        xlsx_path = os.path.join(metrics_dir, f'{config.EXPERIMENT_NAME}_summary.xlsx')

        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(summary.keys()))
            writer.writeheader()
            writer.writerow(summary)

        wb = Workbook()
        ws = wb.active
        ws.title = 'summary'
        ws.append(list(summary.keys()))
        ws.append(list(summary.values()))
        wb.save(xlsx_path)

        self._export_timeseries(metrics_dir)
        self._export_control_breakdown(metrics_dir)
        self._write_rows(
            os.path.join(metrics_dir, 'migration_audit.csv'),
            self.migration_audit_rows,
        )
        if self.packet_diagnostics is not None:
            self.packet_diagnostics.export(metrics_dir, self.simulator.env.now)
        if self.simulator.energy_class_by_node is not None:
            self._write_rows(os.path.join(metrics_dir, 'e5_node_energy.csv'), [
                {
                    'node_id': drone.identifier,
                    'energy_class': drone.energy_class,
                    'is_base_station': drone.is_base_station,
                    'initial_energy_j': drone.initial_energy,
                    'residual_energy_j': drone.residual_energy,
                    'final_soc': drone.residual_energy / drone.initial_energy,
                    'first_sleep_time_s': (
                        drone.first_sleep_time_us / 1e6
                        if drone.first_sleep_time_us is not None else ''
                    ),
                }
                for drone in self.simulator.drones
            ])
        if getattr(self.simulator, 'cluster_manager', None) is not None:
            self.simulator.cluster_manager.metrics.export(metrics_dir)
        self._export_figures(figures_dir)

        return csv_path, xlsx_path, summary

    def _e5_energy_summary(self):
        uavs = [
            drone for drone in self.simulator.drones
            if not drone.is_base_station
        ]
        soc = [drone.residual_energy / drone.initial_energy for drone in uavs]
        first_sleep = [
            drone.first_sleep_time_us for drone in uavs
            if drone.first_sleep_time_us is not None
        ]
        soc_sum = math.fsum(soc)
        soc_squares = math.fsum(value * value for value in soc)
        result = {
            'e5_total_initial_energy_j': math.fsum(
                drone.initial_energy for drone in self.simulator.drones
            ),
            'e5_emergency_node_ratio': (
                sum(value < 0.25 for value in soc) / len(soc)
                if soc else float('nan')
            ),
            'e5_sleep_node_ratio': (
                sum(drone.sleep for drone in uavs) / len(uavs)
                if uavs else float('nan')
            ),
            'e5_final_soc_mean': float(np.mean(soc)) if soc else float('nan'),
            'e5_final_soc_p05': float(np.percentile(soc, 5)) if soc else float('nan'),
            'e5_final_soc_jain': (
                soc_sum * soc_sum / (len(soc) * soc_squares)
                if soc_squares else float('nan')
            ),
            'e5_first_uav_sleep_s': (
                min(first_sleep) / 1e6 if first_sleep else float('nan')
            ),
            'e5_first_uav_sleep_observed': bool(first_sleep),
        }
        totals = {
            role: sum(counts[role] for counts in self.energy_class_role_samples.values())
            for role in ('CH', 'BR')
        }
        for label in ('Low', 'Medium', 'High'):
            key = label.lower()
            members = [drone for drone in uavs if drone.energy_class == label]
            result[f'e5_{key}_node_count'] = len(members)
            for role in ('CH', 'BR'):
                count = self.energy_class_role_samples[label][role]
                denominator = len(members) * self.energy_class_sample_count
                result[f'e5_{key}_{role.lower()}_occupancy'] = (
                    count / denominator if denominator else float('nan')
                )
                result[f'e5_{key}_{role.lower()}_share'] = (
                    count / totals[role] if totals[role] else float('nan')
                )
        return result

    def _export_timeseries(self, metrics_dir):
        self._write_rows(os.path.join(metrics_dir, 'connectivity_ratio_timeseries.csv'), [
            {'time_s': row['time_s'], 'connectivity_ratio': row['connectivity_ratio']}
            for row in self.metric_timeseries
        ])
        self._write_rows(os.path.join(metrics_dir, 'throughput_timeseries.csv'), [
            {'time_s': row['time_s'], 'throughput_kbps': row['throughput_kbps']}
            for row in self.metric_timeseries
        ])
        self._write_rows(os.path.join(metrics_dir, 'pdr_timeseries.csv'), [
            {'time_s': row['time_s'], 'pdr_percent': row['pdr_percent']}
            for row in self.metric_timeseries
        ])
        self._write_rows(os.path.join(metrics_dir, 'control_overhead_timeseries.csv'), self.metric_timeseries)

    def _export_control_breakdown(self, metrics_dir):
        control_row = {
            'control_packet_total': self.control_packet_breakdown['total'],
            'control_packet_dsdv': self.control_packet_breakdown['dsdv'],
            'control_packet_backbone': self.control_packet_breakdown['backbone'],
            'control_packet_cluster': self.control_packet_breakdown['cluster'],
            'control_packet_torp': self.control_packet_breakdown['torp'],
            'routing_load': self._current_routing_load(),
            'unit_control_overhead': self.control_packet_breakdown['total'] / max(1, len(self.datapacket_arrived)),
        }
        control_row.update(self._routing_resilience_summary())
        self._write_rows(os.path.join(metrics_dir, 'control_overhead_breakdown.csv'), [control_row])
        self._write_rows(os.path.join(metrics_dir, 'routing_fallback_breakdown.csv'), [self._routing_resilience_summary()])

    def _export_figures(self, figures_dir):
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            return

        def plot_line(rows, x_key, y_key, filename, ylabel):
            if not rows:
                return
            plt.figure()
            plt.plot([row[x_key] for row in rows], [row[y_key] for row in rows])
            plt.xlabel('Time (s)')
            plt.ylabel(ylabel)
            plt.tight_layout()
            plt.savefig(os.path.join(figures_dir, filename))
            plt.close()

        plot_line(self.metric_timeseries, 'time_s', 'connectivity_ratio', 'connectivity_ratio_curve.png', 'Connectivity Ratio')
        plot_line(self.metric_timeseries, 'time_s', 'throughput_kbps', 'throughput_curve.png', 'Throughput (kbps)')
        plot_line(self.metric_timeseries, 'time_s', 'pdr_percent', 'pdr_curve.png', 'PDR (%)')
        if getattr(self.simulator, 'cluster_manager', None) is not None:
            samples = self.simulator.cluster_manager.metrics.cluster_lifetime_samples
            if samples:
                plt.figure()
                plt.plot(list(range(1, len(samples) + 1)), samples)
                plt.xlabel('Cluster Sample')
                plt.ylabel('Cluster Lifetime (rounds)')
                plt.tight_layout()
                plt.savefig(os.path.join(figures_dir, 'cluster_lifetime_curve.png'))
                plt.close()

        try:
            plt.figure()
            labels = ['DSDV', 'Backbone', 'Cluster', 'TORP-like']
            values = [
                self.control_packet_breakdown['dsdv'],
                self.control_packet_breakdown['backbone'],
                self.control_packet_breakdown['cluster'],
                self.control_packet_breakdown['torp'],
            ]
            plt.bar(labels, values)
            plt.ylabel('Control Packets')
            plt.tight_layout()
            plt.savefig(os.path.join(figures_dir, 'control_overhead_breakdown.png'))
            plt.close()
        except Exception:
            plt.close('all')

        self._plot_uav_trajectories(figures_dir)
        self._plot_cluster_snapshot(figures_dir)

    def _plot_uav_trajectories(self, figures_dir):
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            return

        if not any(getattr(drone, 'trajectory_trace', None) for drone in self.simulator.drones):
            return

        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        for drone in self.simulator.drones:
            trace = getattr(drone, 'trajectory_trace', [])
            if not trace:
                continue
            x = [step['coords'][0] for step in trace]
            y = [step['coords'][1] for step in trace]
            z = [step['coords'][2] for step in trace]
            ax.plot(x, y, z, linewidth=0.8, alpha=0.8)
        ax.set_xlim(0, config.MAP_LENGTH)
        ax.set_ylim(0, config.MAP_WIDTH)
        ax.set_zlim(0, config.MAP_HEIGHT)
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')
        ax.set_zlabel('Z (m)')
        fig.tight_layout()
        fig.savefig(os.path.join(figures_dir, 'uav_3d_trajectory.png'))
        plt.close(fig)

    def _plot_cluster_snapshot(self, figures_dir):
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            return

        drones = [drone for drone in self.simulator.drones if not getattr(drone, 'is_base_station', False)]
        if not drones:
            return

        plt.figure()
        for drone in drones:
            color = 'tab:red' if getattr(drone, 'cluster_role', None) == 'CH' else 'tab:blue'
            plt.scatter(drone.coords[0], drone.coords[1], c=color, s=45 if color == 'tab:red' else 20)
            cluster_head = getattr(drone, 'cluster_head', None)
            if cluster_head is not None and cluster_head.identifier != drone.identifier:
                plt.plot([drone.coords[0], cluster_head.coords[0]], [drone.coords[1], cluster_head.coords[1]], color='lightgray', linewidth=0.5)
        plt.xlim(0, config.MAP_LENGTH)
        plt.ylim(0, config.MAP_WIDTH)
        plt.xlabel('X (m)')
        plt.ylabel('Y (m)')
        plt.tight_layout()
        plt.savefig(os.path.join(figures_dir, 'cluster_structure_snapshot.png'))
        plt.close()

    def update_poi_metrics(self, simulator):
        if not getattr(simulator, 'pois', None):
            return

        coverage_hits = 0
        connected_hits = 0
        for poi in simulator.pois:
            covered = False
            connected = False
            for drone in simulator.drones:
                if euclidean_distance_3d(poi.coords, drone.coords) <= config.COMMUNICATION_RANGE:
                    covered = True
                    if getattr(drone, 'cluster_role', None) in ('CH', 'BS'):
                        connected = True
                        break
            if covered:
                coverage_hits += 1
            if connected:
                connected_hits += 1

        total = len(simulator.pois)
        self.poi_coverage_ratio.append(coverage_hits / total if total else 0.0)
        self.connected_ratio.append(connected_hits / total if total else 0.0)

    def _torp_snapshot_age_us(self):
        planner = getattr(self.simulator, 'torp_like_planner', None)
        if planner is None:
            return float('nan')
        return planner.snapshot_age_us()

    def increment_control_packets(self, count=1, category='total'):
        self.control_packet_num += count
        self.control_packet_breakdown['total'] += count
        if category in self.control_packet_breakdown:
            self.control_packet_breakdown[category] += count

    def record_routing_event(self, event_name, count=1):
        self.routing_resilience[event_name] += count

    def record_migration_audit(self, **fields):
        self.migration_audit_rows.append(dict(fields))

    def _routing_resilience_summary(self):
        keys = [
            'cm_local_backup_count',
            'backbone_local_backup_count',
            'fallback_attempt_count',
            'fallback_success_count',
            'fallback_fail_already_used_count',
            'fallback_fail_missing_target_count',
            'fallback_fail_no_candidate_count',
            'fallback_extra_control_packets',
            'backbone_decision_count',
            'backbone_planned_count',
            'backbone_direct_count',
            'backbone_backup_count',
            'backbone_fallback_count',
            'backbone_fail_count',
            'stale_snapshot_count',
            'backbone_cluster_epoch_mismatch_count',
            'planned_route_missing_planner_count',
            'planned_route_missing_source_count',
            'planned_route_missing_target_count',
            'planned_route_invalid_next_hop_count',
            'planned_route_loop_reject_count',
            'planned_route_next_hop_unreachable_count',
            'planned_route_role_invalid_count',
            'snapshot_final_head_added_count',
            'snapshot_final_head_removed_count',
            'relative_mobility_evaluation_count',
            'relative_mobility_nonzero_count',
            'service_guard_evaluation_count',
            'service_guard_adjustment_count',
            'relay_hold_candidate_count',
            'relay_hold_keep_count',
            'relay_hold_early_release_count',
            'relay_hold_register_count',
            'relay_hold_switch_count',
            'backbone_packet_count',
            'pinned_route_created_count',
            'pinned_hop_attempt_count',
            'pinned_hop_selected_count',
            'pinned_route_invalid_count',
            'pinned_invalid_next_hop_unreachable_count',
            'pinned_invalid_next_hop_sleep_count',
            'pinned_invalid_energy_emergency_count',
            'pinned_invalid_tlet_emergency_count',
            'pinned_invalid_connectivity_invalid_count',
            'pinned_destination_unreachable_count',
            'pinned_path_visited_conflict_count',
            'epoch_aged_packet_count',
            'mid_route_epoch_switch_count',
            'migration_attempt_count',
            'migration_success_count',
            'migration_failed_count',
            'migration_exhausted_count',
            'migration_exhausted_already_used_count',
            'migration_exhausted_physical_disconnect_count',
            'migration_exhausted_tlet_emergency_count',
            'migration_exhausted_energy_emergency_count',
            'migration_exhausted_connectivity_invalid_count',
            'migration_fail_no_path_count',
            'migration_fail_target_invalid_count',
            'migration_fail_visited_conflict_count',
            'migration_fail_destination_unreachable_count',
            'migration_fail_planner_missing_count',
            'unauthorized_pinned_path_change_count',
            'post_migration_repin_blocked_count',
            'initial_pin_visited_aware_count',
            'migrated_packet_count',
            'legacy_forward_count',
        ]
        summary = {key: self.routing_resilience.get(key, 0) for key in keys}
        decisions = summary['backbone_decision_count']
        summary['planned_route_ratio'] = (
            summary['backbone_planned_count'] / decisions if decisions else 0.0
        )
        summary['stale_snapshot_ratio'] = (
            summary['stale_snapshot_count'] / decisions if decisions else 0.0
        )
        pinned_attempts = summary['pinned_hop_attempt_count']
        summary['pinned_route_hit_ratio'] = (
            summary['pinned_hop_selected_count'] / pinned_attempts
            if pinned_attempts else 0.0
        )
        summary['pinned_route_invalid_ratio'] = (
            summary['pinned_route_invalid_count'] / pinned_attempts
            if pinned_attempts else 0.0
        )
        backbone_packets = summary['backbone_packet_count']
        summary['migration_rate'] = (
            summary['migrated_packet_count'] / backbone_packets
            if backbone_packets else 0.0
        )
        summary['epoch_aged_ratio'] = (
            summary['epoch_aged_packet_count'] / pinned_attempts
            if pinned_attempts else 0.0
        )
        return summary

    def _write_rows(self, path, rows):
        rows = rows or []
        fieldnames = sorted({key for row in rows for key in row.keys()}) if rows else ['placeholder']
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            if rows:
                writer.writerows(rows)
