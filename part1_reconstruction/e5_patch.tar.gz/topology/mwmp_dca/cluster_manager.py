import math
import random

import numpy as np

from energy.energy_accounting import CONTROL, RX, TX
from models.infer_models import OnlineModelSuite
from phy.large_scale_fading import general_path_loss
from topology.mwmp_dca.backbone_planner import BackbonePlanner
from topology.mwmp_dca.cluster_metrics import ClusterMetrics
from topology.mwmp_dca.cluster_rotation import ClusterRotationManager
from topology.mwmp_dca.predictor import build_predictor
from topology.mwmp_dca.recent_baselines import (
    TdcMopsoSelector,
    mdcs_candidate_score,
    select_mdcs_heads,
    tdc_candidate_score,
)
from topology.mwmp_dca.trajectory_let_calculator import trajectory_based_let
from topology.mwmp_dca.weight_calculator import WeightCalculator, clamp01
from utils import config
from utils.util_function import euclidean_distance_3d


class ClusterManager:
    def __init__(self, simulator):
        self.simulator = simulator
        self.env = simulator.env
        needs_models = (
            config.USE_GAT_FEATURE or
            (
                config.USE_LSTM_PREDICTOR and
                config.PREDICTOR_MODE.lower() == 'lstm'
            )
        )
        self.model_suite = OnlineModelSuite() if needs_models else None
        if self.model_suite is not None:
            self.model_suite.refresh_status()
        else:
            config.MODEL_STATUS.update({'lstm': 'disabled', 'gat': 'disabled'})
        self.requested_algorithm = config.CLUSTER_ALGORITHM
        self._maybe_downgrade_ga_mode()
        self.predictor = build_predictor(self.simulator)
        self.weight_calculator = WeightCalculator()
        self.backbone_planner = BackbonePlanner(simulator, self._pair_link_quality)
        self.rotation_manager = ClusterRotationManager()
        self.metrics = ClusterMetrics()
        self.rng = random.Random(simulator.seed + 101)
        self.cluster_snapshot = {}
        self.round_counter = 0
        self.stable_rounds = 0
        self.better_candidate_persistence = {}
        self.smoothed_tlet = {}
        self.backbone_relay_hold_until = {}
        self.env.process(self.run())

    def _maybe_downgrade_ga_mode(self):
        if config.CLUSTER_ALGORITHM.upper() != 'GA_MP_DCA':
            config.MODEL_STATUS['ga_mode'] = 'not_requested'
            return

        lstm_missing = config.USE_LSTM_PREDICTOR and config.PREDICTOR_MODE.lower() == 'lstm' and not self.model_suite.trajectory_model.available
        gat_missing = config.USE_GAT_FEATURE and not self.model_suite.graph_model.available
        if lstm_missing or gat_missing:
            missing = [
                name for name, unavailable in (('LSTM', lstm_missing), ('GAT', gat_missing))
                if unavailable
            ]
            raise RuntimeError(f'Requested models unavailable: {", ".join(missing)}')
        config.MODEL_STATUS['ga_mode'] = 'active'

    def active_drones(self):
        return [drone for drone in self.simulator.drones if not getattr(drone, 'is_base_station', False)]

    def run(self):
        while True:
            yield self.env.timeout(config.CLUSTER_INTERVAL)
            self.recluster()

    def recluster(self):
        self.round_counter += 1
        drones = self.active_drones()
        if not drones:
            return

        previous_head_ids = {drone.identifier for drone in drones if getattr(drone, 'cluster_role', None) == 'CH'}
        predictions = {drone.identifier: self.predictor.predict(drone, config.PREDICTION_HORIZON) for drone in drones}
        neighbor_map = self._build_neighbor_map(drones)
        raw_tlets = {
            drone.identifier: self._average_local_tlet(
                drone,
                neighbor_map.get(drone.identifier, []),
                predictions,
            )
            for drone in drones
        }
        tlets = self._smooth_tlets(raw_tlets)
        feature_rows, adjacency, degree_scores = self._build_graph_inputs(drones, neighbor_map)
        topology_scores, topology_embeddings = self._compute_topology_scores(drones, feature_rows, adjacency, degree_scores)
        scores = {}

        for drone in drones:
            scores[drone.identifier] = self._score_drone(
                drone=drone,
                neighbors=neighbor_map.get(drone.identifier, []),
                predictions=predictions,
                topology_score=topology_scores.get(drone.identifier, degree_scores.get(drone.identifier, 0.0)),
                tlet=tlets.get(drone.identifier, 0.0),
            )
            drone.cluster_weight = scores[drone.identifier]
            drone.topology_score = topology_scores.get(drone.identifier, degree_scores.get(drone.identifier, 0.0))
            drone.graph_embedding = topology_embeddings.get(drone.identifier, [])
            drone.raw_avg_let = raw_tlets.get(drone.identifier, 0.0)
            drone.avg_let = tlets.get(drone.identifier, 0.0)
            drone.local_density = len(neighbor_map.get(drone.identifier, []))
            drone.avg_link_quality = self._average_link_quality(drone, neighbor_map.get(drone.identifier, []))
            drone.mobility_factor = self._mobility_factor(drone, neighbor_map.get(drone.identifier, []), predictions)
            self.metrics.record_topology_score(drone.topology_score)

        if config.CLUSTER_ALGORITHM.upper() == 'GA_MP_DCA' and config.GA_CH_PERSISTENCE_BONUS > 0:
            for head_id in previous_head_ids:
                if head_id in scores:
                    scores[head_id] = clamp01(scores[head_id] + config.GA_CH_PERSISTENCE_BONUS)
                    self.simulator.drones[head_id].cluster_weight = scores[head_id]

        for drone in drones:
            drone.cluster_role = 'CM'
            drone.is_backbone_connector = False
            drone.cluster_id = None
            drone.cluster_head = None
            drone.cluster_members = []

        for drone in drones:
            self.metrics.record_prediction_error(self.predictor.evaluate_recent(drone, config.PREDICTION_HORIZON))

        candidate_heads, suppressed_count, backoff_map = self._elect_cluster_heads(
            drones,
            neighbor_map,
            scores,
            previous_head_ids,
        )

        if not candidate_heads:
            candidate_heads = [max(drones, key=lambda d: scores[d.identifier])]

        candidate_heads = sorted(
            candidate_heads,
            key=lambda d: (scores[d.identifier], d.residual_energy, -d.identifier),
            reverse=True,
        )
        if config.USE_CH_ROTATION and config.CLUSTER_ALGORITHM.upper() in ('MWMP_DCA', 'GA_MP_DCA'):
            candidate_heads = self._apply_rotation(candidate_heads, drones, neighbor_map, scores, previous_head_ids)

        clusters = []
        for head in candidate_heads:
            head.cluster_role = 'CH'
            head.cluster_head = head
            head.cluster_id = head.identifier
            head.cluster_members = [head.identifier]
            head.cluster_weight = scores[head.identifier]
            head.cluster_age = getattr(head, 'cluster_age', 0) + 1 if head.identifier in previous_head_ids else 1

        extra_heads = []
        for drone in drones:
            if drone.cluster_role == 'CH':
                continue
            reachable_heads = [
                head for head in candidate_heads
                if euclidean_distance_3d(drone.coords, head.coords) <= config.COMMUNICATION_RANGE
            ]
            if not reachable_heads:
                extra_heads.append(drone)

        for head in extra_heads:
            head.cluster_role = 'CH'
            head.cluster_head = head
            head.cluster_id = head.identifier
            head.cluster_members = [head.identifier]
            head.cluster_weight = scores[head.identifier]
            head.cluster_age = getattr(head, 'cluster_age', 0) + 1 if head.identifier in previous_head_ids else 1
            candidate_heads.append(head)

        for drone in drones:
            if drone.cluster_role == 'CH':
                continue
            reachable_heads = [
                head for head in candidate_heads
                if euclidean_distance_3d(drone.coords, head.coords) <= config.COMMUNICATION_RANGE
                and len(head.cluster_members) < config.CH_MAX_LOAD
            ]
            if reachable_heads:
                if config.MWMP_DECISION_MODE == 'original':
                    best_head = max(
                        reachable_heads,
                        key=lambda head: (
                            scores[head.identifier],
                            self._pair_link_quality(drone, head),
                            -euclidean_distance_3d(drone.coords, head.coords),
                        ),
                    )
                else:
                    best_head = max(
                        reachable_heads,
                        key=lambda head: (
                            self._member_affinity(drone, head, predictions),
                            scores[head.identifier],
                            -head.identifier,
                        ),
                    )
            else:
                drone.cluster_role = 'CH'
                drone.cluster_head = drone
                drone.cluster_id = drone.identifier
                drone.cluster_members = [drone.identifier]
                drone.cluster_weight = scores[drone.identifier]
                if all(head.identifier != drone.identifier for head in candidate_heads):
                    candidate_heads.append(drone)
                continue
            drone.cluster_role = 'CM'
            drone.cluster_head = best_head
            drone.cluster_id = best_head.identifier
            if drone.identifier not in best_head.cluster_members:
                best_head.cluster_members.append(drone.identifier)

        final_head_ids = {
            drone.identifier for drone in drones
            if drone.cluster_role == 'CH'
        }
        hold_rounds = max(
            0,
            int(getattr(config, 'BACKBONE_RELAY_HOLD_ROUNDS', 0)),
        )
        by_id = {drone.identifier: drone for drone in drones}
        active_ids = set(by_id)
        previous_backbone_ids = (
            self.backbone_planner.active_snapshot.cluster_heads |
            self.backbone_planner.active_snapshot.backbone_relays
        )
        previous_relay_ids = set(
            self.backbone_planner.active_snapshot.backbone_relays
        )
        previous_backbone = [
            by_id[node_id] for node_id in previous_backbone_ids
            if node_id in by_id
        ]
        hold_context = list(candidate_heads)
        hold_context.extend(
            drone for drone in previous_backbone
            if drone.identifier not in final_head_ids
        )
        active_prior_hold_ids = {
            node_id for node_id, until_round
            in self.backbone_relay_hold_until.items()
            if until_round >= self.round_counter
        }
        if hold_rounds:
            self.backbone_relay_hold_until = {
                node_id: until_round
                for node_id, until_round in self.backbone_relay_hold_until.items()
                if (
                    until_round >= self.round_counter and
                    node_id in active_ids and
                    self._relay_hold_eligible(by_id[node_id], hold_context)
                )
            }
        else:
            self.backbone_relay_hold_until = {}
        if hold_rounds:
            retained_hold_ids = set(self.backbone_relay_hold_until)
            self.simulator.metrics.record_routing_event(
                'relay_hold_candidate_count', len(active_prior_hold_ids)
            )
            self.simulator.metrics.record_routing_event(
                'relay_hold_keep_count', len(retained_hold_ids)
            )
            self.simulator.metrics.record_routing_event(
                'relay_hold_early_release_count',
                len(active_prior_hold_ids - retained_hold_ids),
            )

        membership = {
            head.identifier: tuple(sorted(head.cluster_members))
            for head in candidate_heads
        }
        backbone_nodes = self.backbone_planner.plan(
            candidate_heads,
            drones,
            predictions,
            epoch=self.round_counter,
            retained_relay_ids=self.backbone_relay_hold_until,
            cluster_membership=membership,
        )
        known_head_ids = {head.identifier for head in candidate_heads}
        connectors = [
            drone for drone in backbone_nodes
            if drone.identifier not in known_head_ids
        ]
        published_relay_ids = (
            self.backbone_planner.active_snapshot.backbone_relays
        )
        self.backbone_relay_hold_until = {
            node_id: until_round
            for node_id, until_round in self.backbone_relay_hold_until.items()
            if node_id in published_relay_ids
        }
        if hold_rounds:
            for connector in connectors:
                self.backbone_relay_hold_until[connector.identifier] = (
                    self.round_counter + hold_rounds
                )
            connector_ids = {connector.identifier for connector in connectors}
            self.simulator.metrics.record_routing_event(
                'relay_hold_register_count', len(connector_ids)
            )
            self.simulator.metrics.record_routing_event(
                'relay_hold_switch_count',
                len(previous_relay_ids.symmetric_difference(
                    set(published_relay_ids)
                )),
            )
        for connector in connectors:
            connector.is_backbone_connector = True

        planned_head_ids = set(self.backbone_planner.snapshot_head_ids)
        self.simulator.metrics.record_routing_event(
            'snapshot_final_head_added_count',
            len(final_head_ids - planned_head_ids),
        )
        self.simulator.metrics.record_routing_event(
            'snapshot_final_head_removed_count',
            len(planned_head_ids - final_head_ids),
        )

        self._account_cluster_control(drones, candidate_heads)
        self._account_backbone_control()
        join_count = sum(max(0, len(head.cluster_members) - 1) for head in candidate_heads)
        formation_time = max(backoff_map.values()) if backoff_map else 0.0
        self.metrics.record_control_exchange(
            announces=len(candidate_heads),
            joins=join_count,
            suppressed=suppressed_count,
        )
        self.metrics.record_election_round(
            round_counter=self.round_counter,
            candidate_ids=[drone.identifier for drone in drones],
            winner_ids=[head.identifier for head in candidate_heads],
            suppressed=suppressed_count,
            formation_time_us=formation_time,
            backoff_map=backoff_map,
        )

        for head in candidate_heads:
            clusters.append((head.identifier, head.cluster_members[:]))

        for drone in drones:
            if drone.cluster_role != 'CH':
                drone.cluster_age = 0

        (
            backbone_connectivity,
            bs_reachability,
            path_preservation,
            bs_reachability_efficiency,
        ) = self._backbone_connectivity(backbone_nodes)
        self.metrics.record_backbone_connectivity(
            backbone_connectivity,
            bs_reachability,
            path_preservation,
            bs_reachability_efficiency,
        )

        new_snapshot = {drone.identifier: drone.cluster_id for drone in drones}
        if self.cluster_snapshot and new_snapshot == self.cluster_snapshot:
            self.stable_rounds += 1
        else:
            self.stable_rounds = 0
            self.metrics.record_reclustering()
        self.cluster_snapshot = new_snapshot
        self.metrics.record_cluster_snapshot(clusters, self.round_counter)

        control_overhead = len(candidate_heads) + join_count
        self.simulator.metrics.increment_control_packets(control_overhead, category='cluster')

        head_tlets = [drone.avg_let for drone in drones if drone.cluster_role == 'CH']
        if head_tlets:
            self.metrics.record_average_tlet(sum(head_tlets) / len(head_tlets))

        for drone in self.simulator.drones:
            if hasattr(drone, 'routing_protocol') and drone.routing_protocol is not None:
                update_role = getattr(drone.routing_protocol, 'update_role', None)
                if callable(update_role):
                    update_role(
                        'BR' if getattr(drone, 'is_backbone_connector', False)
                        else drone.cluster_role
                    )

    def _build_neighbor_map(self, drones):
        neighbor_map = {}
        for drone in drones:
            neighbors = []
            for candidate in drones:
                if candidate.identifier == drone.identifier:
                    continue
                if euclidean_distance_3d(drone.coords, candidate.coords) <= config.COMMUNICATION_RANGE:
                    neighbors.append(candidate)
            neighbor_map[drone.identifier] = neighbors
        return neighbor_map

    @staticmethod
    def _is_control_role(drone):
        return (
            getattr(drone, 'cluster_role', None) == 'CH' or
            getattr(drone, 'is_backbone_connector', False)
        )

    def _charge_control_hop(self, source, target):
        tx_energy = (
            config.HELLO_PACKET_LENGTH / config.BIT_RATE *
            config.TRANSMITTING_POWER
        )
        rx_energy = (
            config.HELLO_PACKET_LENGTH / config.BIT_RATE *
            config.RECEIVING_POWER
        )
        source.consume_energy(
            tx_energy,
            source=CONTROL,
            direction=TX,
            role_energy=self._is_control_role(source),
        )
        target.consume_energy(
            rx_energy,
            source=CONTROL,
            direction=RX,
            role_energy=self._is_control_role(target),
        )

    def _account_cluster_control(self, drones, candidate_heads):
        by_id = {drone.identifier: drone for drone in drones}
        for head in candidate_heads:
            tx_energy = (
                config.HELLO_PACKET_LENGTH / config.BIT_RATE *
                config.TRANSMITTING_POWER
            )
            head.consume_energy(
                tx_energy,
                source=CONTROL,
                direction=TX,
                role_energy=True,
            )
            for receiver in drones:
                if receiver.identifier == head.identifier:
                    continue
                if euclidean_distance_3d(
                    head.coords,
                    receiver.coords,
                ) <= config.COMMUNICATION_RANGE:
                    rx_energy = (
                        config.HELLO_PACKET_LENGTH / config.BIT_RATE *
                        config.RECEIVING_POWER
                    )
                    receiver.consume_energy(
                        rx_energy,
                        source=CONTROL,
                        direction=RX,
                        role_energy=self._is_control_role(receiver),
                    )

            for member_id in head.cluster_members:
                if member_id == head.identifier:
                    continue
                member = by_id.get(member_id)
                if member is not None:
                    self._charge_control_hop(member, head)

    def _account_backbone_control(self):
        transmissions = 0
        for path in self.backbone_planner.last_control_paths.values():
            for source_id, target_id in zip(path, path[1:]):
                self._charge_control_hop(
                    self.simulator.drones[source_id],
                    self.simulator.drones[target_id],
                )
                transmissions += 1
        if transmissions:
            self.simulator.metrics.increment_control_packets(
                transmissions,
                category='backbone',
            )

    def _build_graph_inputs(self, drones, neighbor_map):
        feature_rows = []
        adjacency = np.eye(len(drones), dtype=np.float32)
        degree_scores = {}

        for row_idx, drone in enumerate(drones):
            neighbors = neighbor_map.get(drone.identifier, [])
            degree_ratio = clamp01(len(neighbors) / max(1, len(drones) - 1))
            degree_scores[drone.identifier] = degree_ratio
            link_quality = self._average_link_quality(drone, neighbors)
            speed_ratio = clamp01(sum(value ** 2 for value in drone.velocity) ** 0.5 / max(1.0, config.DEFAULT_UAV_SPEED * 2))
            feature_rows.append([
                clamp01(drone.residual_energy / float(
                    getattr(drone, 'initial_energy', config.INITIAL_ENERGY)
                )),
                link_quality,
                degree_ratio,
                speed_ratio,
            ])
            for col_idx, candidate in enumerate(drones):
                if row_idx == col_idx:
                    continue
                if candidate in neighbors:
                    adjacency[row_idx, col_idx] = 1.0
        return feature_rows, adjacency, degree_scores

    def _compute_topology_scores(self, drones, feature_rows, adjacency, degree_scores):
        algorithm = config.CLUSTER_ALGORITHM.upper()
        heuristic_scores = {drone.identifier: degree_scores.get(drone.identifier, 0.0) for drone in drones}
        embeddings = {drone.identifier: [] for drone in drones}

        if algorithm != 'GA_MP_DCA':
            return heuristic_scores, embeddings

        if not config.USE_GAT_FEATURE:
            config.MODEL_STATUS['gat'] = 'ablation_disabled'
            return heuristic_scores, embeddings

        scores, raw_embeddings = self.model_suite.graph_model.encode(feature_rows, adjacency)
        if scores is None:
            status = getattr(self.model_suite.graph_model, 'status', 'unavailable')
            config.MODEL_STATUS['gat'] = f'fallback:{status}'
            return heuristic_scores, embeddings

        result_scores = {}
        for idx, drone in enumerate(drones):
            result_scores[drone.identifier] = clamp01(float(scores[idx]))
            embeddings[drone.identifier] = [float(value) for value in raw_embeddings[idx]]
        config.MODEL_STATUS['gat'] = getattr(self.model_suite.graph_model, 'status', 'loaded')
        return result_scores, embeddings

    def _score_drone(self, drone, neighbors, predictions, topology_score=0.0, tlet=None):
        algorithm = config.CLUSTER_ALGORITHM.upper()
        energy_ratio = clamp01(drone.residual_energy / float(
            getattr(drone, 'initial_energy', config.INITIAL_ENERGY)
        ))
        original_mode = config.MWMP_DECISION_MODE == 'original'
        density_denominator = (
            max(1, len(self.simulator.drones) - 1)
            if original_mode else max(1, config.CH_MAX_LOAD)
        )
        density = clamp01(len(neighbors) / density_denominator)
        link_quality = self._average_link_quality(drone, neighbors)
        if tlet is None:
            tlet = self._average_local_tlet(drone, neighbors, predictions)
        if not config.USE_TLET:
            tlet = 0.0
        tlet_ratio = self.weight_calculator.normalize_tlet(tlet)
        if original_mode:
            trajectory = predictions.get(drone.identifier, ())
            mobility = (
                clamp01(
                    euclidean_distance_3d(drone.coords, trajectory[-1]) /
                    float(config.COMMUNICATION_RANGE)
                )
                if config.USE_MOBILITY_FACTOR and trajectory else 0.0
            )
        else:
            mobility = (
                self._mobility_factor(drone, neighbors, predictions)
                if config.USE_MOBILITY_FACTOR else 0.0
            )
        service_burden = clamp01(
            drone.transmitting_queue.qsize() / max(1, drone.max_queue_size)
        )

        factors = {
            'energy_ratio': energy_ratio,
            'link_quality': link_quality,
            'density': density,
            'tlet_ratio': tlet_ratio,
            'mobility_factor': mobility,
            'service_burden': service_burden,
            'topology_score': topology_score,
        }
        self.metrics.record_weight_factors(factors)
        if not original_mode and config.USE_MOBILITY_FACTOR:
            self.simulator.metrics.record_routing_event(
                'relative_mobility_evaluation_count'
            )
            if mobility > 1e-12:
                self.simulator.metrics.record_routing_event(
                    'relative_mobility_nonzero_count'
                )

        if algorithm == 'GA_MP_DCA':
            return self.weight_calculator.ga_score(
                energy_ratio=energy_ratio,
                link_quality=link_quality,
                tlet_ratio=tlet_ratio,
                topology_score=topology_score,
                mobility_factor=mobility,
            )

        if algorithm == 'MLSC':
            return self._mlsc_score(drone, neighbors, link_quality, density)

        if algorithm == 'MDCS':
            return mdcs_candidate_score(
                drone,
                neighbors,
                config.COMMUNICATION_RANGE,
                config.DEFAULT_UAV_SPEED,
            )

        if algorithm == 'TDC_MOPSO':
            return tdc_candidate_score(
                drone,
                neighbors,
                config.INITIAL_ENERGY,
                config.COMMUNICATION_RANGE,
                config.DEFAULT_UAV_SPEED,
            )

        if not config.USE_HYBRID_WEIGHT:
            return energy_ratio

        if original_mode:
            weights = config.ORIGINAL_MWMP_SCORE_WEIGHTS
            return clamp01(
                weights['energy'] * energy_ratio +
                weights['link_quality'] * link_quality +
                weights['density'] * density +
                weights['tlet'] * tlet_ratio +
                weights['mobility'] * mobility
            )

        network_score = self.weight_calculator.score(
            energy_ratio=energy_ratio,
            link_quality=link_quality,
            density=density,
            tlet_ratio=tlet_ratio,
            mobility_factor=mobility,
        )
        service_score = self.weight_calculator.service_utility(
            network_score, service_burden
        )
        if config.USE_SERVICE_GUARD:
            self.simulator.metrics.record_routing_event(
                'service_guard_evaluation_count'
            )
            if abs(service_score - network_score) > 1e-12:
                self.simulator.metrics.record_routing_event(
                    'service_guard_adjustment_count'
                )
        return service_score

    def _average_link_quality(self, drone, neighbors):
        if not neighbors:
            return 0.0
        qualities = []
        for neighbor in neighbors:
            qualities.append(self._pair_link_quality(drone, neighbor))
        return sum(qualities) / len(qualities)

    def _pair_link_quality(self, drone, neighbor):
        try:
            receive_power = config.TRANSMITTING_POWER * general_path_loss(neighbor, drone)
            snr = 10 * math.log10(receive_power / config.NOISE_POWER)
            if config.MWMP_DECISION_MODE == 'original':
                return clamp01((snr + 10.0) / 40.0)
            return self.weight_calculator.normalize_link_quality(snr)
        except (ValueError, ZeroDivisionError):
            return 0.0

    def _backbone_connectivity(self, candidate_heads):
        base_stations = [
            drone for drone in self.simulator.drones
            if getattr(drone, 'is_base_station', False)
        ]
        backbone_nodes = base_stations + list(candidate_heads)
        if not backbone_nodes:
            return 1.0, 1.0, 1.0, 1.0

        adjacency = {drone.identifier: set() for drone in backbone_nodes}
        for idx, drone in enumerate(backbone_nodes):
            for other in backbone_nodes[idx + 1:]:
                if euclidean_distance_3d(drone.coords, other.coords) <= config.COMMUNICATION_RANGE:
                    adjacency[drone.identifier].add(other.identifier)
                    adjacency[other.identifier].add(drone.identifier)

        components = []
        unseen = set(adjacency)
        while unseen:
            stack = [next(iter(unseen))]
            component = set()
            while stack:
                node_id = stack.pop()
                if node_id in component:
                    continue
                component.add(node_id)
                unseen.discard(node_id)
                stack.extend(adjacency[node_id] - component)
            components.append(component)
        largest_ratio = max(len(component) for component in components) / len(backbone_nodes)
        backbone_component_by_id = {
            node_id: component_idx
            for component_idx, component in enumerate(components)
            for node_id in component
        }

        physical_nodes = list(self.simulator.drones)
        physical_adjacency = {drone.identifier: set() for drone in physical_nodes}
        for idx, drone in enumerate(physical_nodes):
            for other in physical_nodes[idx + 1:]:
                if euclidean_distance_3d(drone.coords, other.coords) <= config.COMMUNICATION_RANGE:
                    physical_adjacency[drone.identifier].add(other.identifier)
                    physical_adjacency[other.identifier].add(drone.identifier)
        physical_component_by_id = {}
        unseen = set(physical_adjacency)
        component_idx = 0
        while unseen:
            stack = [next(iter(unseen))]
            while stack:
                node_id = stack.pop()
                if node_id in physical_component_by_id:
                    continue
                physical_component_by_id[node_id] = component_idx
                unseen.discard(node_id)
                stack.extend(
                    physical_adjacency[node_id] -
                    set(physical_component_by_id)
                )
            component_idx += 1

        eligible_pairs = 0
        preserved_pairs = 0
        backbone_ids = [drone.identifier for drone in backbone_nodes]
        for idx, node_id in enumerate(backbone_ids):
            for other_id in backbone_ids[idx + 1:]:
                if physical_component_by_id.get(node_id) != physical_component_by_id.get(other_id):
                    continue
                eligible_pairs += 1
                if backbone_component_by_id.get(node_id) == backbone_component_by_id.get(other_id):
                    preserved_pairs += 1
        path_preservation = preserved_pairs / eligible_pairs if eligible_pairs else 1.0

        if not base_stations:
            return largest_ratio, largest_ratio, path_preservation, path_preservation
        reachable = set()
        stack = [drone.identifier for drone in base_stations]
        while stack:
            node_id = stack.pop()
            if node_id in reachable:
                continue
            reachable.add(node_id)
            stack.extend(adjacency[node_id] - reachable)
        head_ids = {head.identifier for head in candidate_heads}
        reachable_heads = len(reachable & head_ids)
        bs_reachability = reachable_heads / len(head_ids) if head_ids else 1.0
        bs_component_ids = {
            physical_component_by_id.get(drone.identifier) for drone in base_stations
        }
        physically_reachable_heads = sum(
            1 for head_id in head_ids
            if physical_component_by_id.get(head_id) in bs_component_ids
        )
        bs_efficiency = (
            reachable_heads / physically_reachable_heads
            if physically_reachable_heads else 1.0
        )
        return largest_ratio, bs_reachability, path_preservation, bs_efficiency

    def _mobility_factor(self, drone, neighbors, predictions):
        if not neighbors:
            return 0.0
        my_trajectory = predictions.get(drone.identifier, ())
        if not my_trajectory:
            return 0.0
        changes = []
        for neighbor in neighbors:
            neighbor_trajectory = predictions.get(neighbor.identifier, ())
            if not neighbor_trajectory:
                continue
            current_distance = euclidean_distance_3d(drone.coords, neighbor.coords)
            predicted_distance = euclidean_distance_3d(
                my_trajectory[-1], neighbor_trajectory[-1]
            )
            changes.append(
                clamp01(
                    abs(predicted_distance - current_distance) /
                    float(config.COMMUNICATION_RANGE)
                )
            )
        return sum(changes) / len(changes) if changes else 0.0

    def _member_affinity(self, drone, head, predictions):
        quality = self._pair_link_quality(drone, head)
        link_tlet = trajectory_based_let(
            predictions[drone.identifier],
            predictions[head.identifier],
            config.COMMUNICATION_RANGE,
        )
        tlet = clamp01(link_tlet / max(1.0, float(config.PREDICTION_HORIZON)))
        load = clamp01(len(head.cluster_members) / max(1, config.CH_MAX_LOAD))
        weights = config.MEMBER_AFFINITY_WEIGHTS
        return (
            weights['link_quality'] * quality +
            weights['tlet'] * tlet +
            weights['load'] * (1.0 - load)
        )

    def _relay_hold_eligible(self, drone, current_backbone):
        energy_ratio = drone.residual_energy / float(
            getattr(drone, 'initial_energy', config.INITIAL_ENERGY)
        )
        tlet_ratio = clamp01(
            getattr(drone, 'avg_let', 0.0) /
            max(1.0, float(config.PREDICTION_HORIZON))
        )
        burden = clamp01(
            drone.transmitting_queue.qsize() / max(1, drone.max_queue_size)
        )
        connected = any(
            other.identifier != drone.identifier and
            euclidean_distance_3d(drone.coords, other.coords) <= config.COMMUNICATION_RANGE
            for other in current_backbone
        )
        return (
            energy_ratio > config.BACKBONE_RELAY_MIN_ENERGY_RATIO and
            tlet_ratio > config.BACKBONE_RELAY_MIN_TLET_RATIO and
            burden < config.BACKBONE_RELAY_MAX_BURDEN and
            connected
        )

    def _average_local_tlet(self, drone, neighbors, predictions):
        if not neighbors:
            return 0.0
        my_traj = predictions[drone.identifier]
        values = []
        for neighbor in neighbors:
            neighbor_traj = predictions[neighbor.identifier]
            values.append(trajectory_based_let(my_traj, neighbor_traj, config.COMMUNICATION_RANGE))
        if not values:
            return 0.0
        if config.TLET_AGGREGATION == 'mean':
            return sum(values) / len(values)
        if config.TLET_AGGREGATION == 'min':
            return min(values)
        if config.TLET_AGGREGATION == 'q25':
            return float(np.quantile(values, 0.25))
        raise ValueError(f'Unsupported TLET aggregation: {config.TLET_AGGREGATION}')

    def _smooth_tlets(self, raw_tlets):
        alpha = clamp01(getattr(config, 'TLET_SMOOTHING_ALPHA', 1.0))
        active_ids = set(raw_tlets)
        self.smoothed_tlet = {
            drone_id: value for drone_id, value in self.smoothed_tlet.items()
            if drone_id in active_ids
        }
        result = {}
        for drone_id, raw_value in raw_tlets.items():
            previous = self.smoothed_tlet.get(drone_id, raw_value)
            smoothed = alpha * raw_value + (1.0 - alpha) * previous
            self.smoothed_tlet[drone_id] = smoothed
            result[drone_id] = smoothed
        return result

    def _poi_affinity(self, drone):
        if not config.ENABLE_POI or not getattr(self.simulator, 'pois', None):
            return 0.0
        nearby = 0
        weighted = 0.0
        for poi in self.simulator.pois:
            distance = euclidean_distance_3d(drone.coords, poi.coords)
            if distance <= config.COMMUNICATION_RANGE:
                nearby += 1
                weighted += 1.0 - distance / float(config.COMMUNICATION_RANGE)
        return clamp01(weighted / max(1, nearby)) if nearby else 0.0

    def _elect_cluster_heads(self, drones, neighbor_map, scores, previous_head_ids=None):
        algorithm = config.CLUSTER_ALGORITHM.upper()
        if algorithm == 'LOWEST_ID':
            selected = self._elect_lowest_id(drones, neighbor_map)
            return selected, 0, {}
        if algorithm == 'WCA':
            return self._elect_ranked_baseline(drones, neighbor_map, self._wca_score), 0, {}
        if algorithm == 'MOBIC':
            return self._elect_ranked_baseline(drones, neighbor_map, self._mobic_score), 0, {}
        if algorithm == 'MLSC':
            return self._elect_ranked_baseline(drones, neighbor_map, lambda drone, _: scores[drone.identifier]), 0, {}
        if algorithm == 'LEACH_UAV':
            return self._elect_leach(drones), 0, {}
        if algorithm == 'KMEANS':
            return self._elect_kmeans(drones), 0, {}
        if algorithm == 'MDCS':
            return select_mdcs_heads(
                drones,
                neighbor_map,
                config.COMMUNICATION_RANGE,
                config.DEFAULT_UAV_SPEED,
                config.CLUSTER_BACKOFF_MAX,
                self.rng,
            )
        if algorithm == 'TDC_MOPSO':
            selector = TdcMopsoSelector(
                rng=self.rng,
                swarm_size=config.TDC_MOPSO_SWARM_SIZE,
                iterations=config.TDC_MOPSO_ITERATIONS,
                archive_size=config.TDC_MOPSO_ARCHIVE_SIZE,
                inertia=config.TDC_MOPSO_INERTIA,
                cognitive=config.TDC_MOPSO_COGNITIVE,
                social=config.TDC_MOPSO_SOCIAL,
                mutation_rate=config.TDC_MOPSO_MUTATION_RATE,
            )
            selected = selector.select(
                drones=drones,
                neighbor_map=neighbor_map,
                previous_head_ids=previous_head_ids or set(),
                communication_range=config.COMMUNICATION_RANGE,
                reference_speed=config.DEFAULT_UAV_SPEED,
                initial_energy=config.INITIAL_ENERGY,
                max_load=config.CH_MAX_LOAD,
                objective_weights=config.TDC_MOPSO_OBJECTIVE_WEIGHTS,
            )
            return selected, 0, {}

        if config.USE_BACKOFF_ELECTION:
            if config.MWMP_DECISION_MODE == 'original':
                return self._elect_original_backoff(drones, neighbor_map, scores)
            return self._elect_adaptive_backoff(drones, neighbor_map, scores)

        candidate_heads = sorted(drones, key=lambda d: (scores[d.identifier], d.residual_energy, -d.identifier), reverse=True)
        return candidate_heads[:max(1, len(drones) // 4)], 0, {}

    def _elect_original_backoff(self, drones, neighbor_map, scores):
        score_max = max(max(scores.values()), 1e-9)
        backoff_entries = []
        backoff_map = {}
        for drone in drones:
            normalized = clamp01(scores[drone.identifier] / score_max)
            jitter = self.rng.uniform(0, config.CLUSTER_BACKOFF_MAX * 0.02)
            backoff = config.CLUSTER_BACKOFF_MAX * (1.0 - normalized) + jitter
            drone.cluster_backoff_time = backoff
            backoff_map[drone.identifier] = backoff
            self.metrics.record_backoff_time(backoff)
            backoff_entries.append((backoff, -scores[drone.identifier], drone.identifier, drone))
        return self._select_backoff_winners(backoff_entries, neighbor_map, backoff_map)

    def _select_backoff_winners(self, backoff_entries, neighbor_map, backoff_map):
        selected = []
        covered = set()
        suppressed = 0
        for _, _, _, drone in sorted(backoff_entries):
            if drone.identifier in covered:
                suppressed += 1
                continue
            selected.append(drone)
            covered.add(drone.identifier)
            for neighbor in neighbor_map.get(drone.identifier, []):
                covered.add(neighbor.identifier)
        return selected, suppressed, backoff_map

    def _elect_adaptive_backoff(self, drones, neighbor_map, scores):
        backoff_entries = []
        backoff_map = {}
        for drone in drones:
            local_ids = [drone.identifier] + [
                neighbor.identifier
                for neighbor in neighbor_map.get(drone.identifier, [])
            ]
            local_scores = [scores[node_id] for node_id in local_ids]
            local_min = min(local_scores)
            local_span = max(local_scores) - local_min
            normalized = (
                clamp01((scores[drone.identifier] - local_min) / local_span)
                if local_span > 1e-12 else 0.5
            )
            jitter = self.rng.uniform(0, config.CLUSTER_BACKOFF_MAX * 0.02)
            backoff = config.CLUSTER_BACKOFF_MAX * (1.0 - normalized) + jitter
            drone.cluster_backoff_time = backoff
            backoff_map[drone.identifier] = backoff
            self.metrics.record_backoff_time(backoff)
            backoff_entries.append((backoff, -scores[drone.identifier], drone.identifier, drone))

        return self._select_backoff_winners(
            backoff_entries, neighbor_map, backoff_map
        )

    def _elect_lowest_id(self, drones, neighbor_map):
        selected = []
        covered = set()
        for drone in sorted(drones, key=lambda d: d.identifier):
            neighborhood = [drone] + neighbor_map.get(drone.identifier, [])
            if any(member.identifier in covered for member in neighborhood):
                continue
            selected.append(drone)
            for member in neighborhood:
                covered.add(member.identifier)
        if not selected and drones:
            selected.append(min(drones, key=lambda d: d.identifier))
        return selected

    def _elect_ranked_baseline(self, drones, neighbor_map, score_func):
        selected = []
        covered = set()
        ranked = sorted(drones, key=lambda d: (score_func(d, neighbor_map), -d.identifier), reverse=True)
        for drone in ranked:
            if drone.identifier in covered:
                continue
            selected.append(drone)
            covered.add(drone.identifier)
            for neighbor in neighbor_map.get(drone.identifier, []):
                covered.add(neighbor.identifier)
        return selected

    def _elect_leach(self, drones):
        head_count = max(1, int(round(len(drones) * config.LEACH_CLUSTER_HEAD_RATIO)))
        return self.rng.sample(drones, min(head_count, len(drones)))

    def _elect_kmeans(self, drones):
        if not drones:
            return []
        k = max(1, int(round(len(drones) / max(1, config.KMEANS_CLUSTER_DIVISOR))))
        coords = np.asarray([drone.coords for drone in drones], dtype=np.float32)
        initial_indices = self.rng.sample(range(len(drones)), min(k, len(drones)))
        centroids = coords[initial_indices]

        for _ in range(6):
            distances = np.linalg.norm(coords[:, None, :] - centroids[None, :, :], axis=2)
            labels = np.argmin(distances, axis=1)
            new_centroids = []
            for cluster_id in range(len(centroids)):
                members = coords[labels == cluster_id]
                if len(members) == 0:
                    new_centroids.append(centroids[cluster_id])
                else:
                    new_centroids.append(members.mean(axis=0))
            centroids = np.asarray(new_centroids, dtype=np.float32)

        selected = {}
        distances = np.linalg.norm(coords[:, None, :] - centroids[None, :, :], axis=2)
        labels = np.argmin(distances, axis=1)
        for cluster_id in range(len(centroids)):
            member_indices = [idx for idx, label in enumerate(labels) if label == cluster_id]
            if not member_indices:
                continue
            best_idx = min(member_indices, key=lambda idx: float(np.linalg.norm(coords[idx] - centroids[cluster_id])))
            selected[drones[best_idx].identifier] = drones[best_idx]
        return list(selected.values())

    def _wca_score(self, drone, neighbor_map):
        degree = len(neighbor_map.get(drone.identifier, []))
        degree_fit = 1.0 - abs(degree - config.CH_MAX_LOAD) / max(1, config.CH_MAX_LOAD)
        distance_sum = sum(euclidean_distance_3d(drone.coords, n.coords) for n in neighbor_map.get(drone.identifier, []))
        distance_score = 1.0 - clamp01(distance_sum / max(1.0, degree * config.COMMUNICATION_RANGE))
        mobility = 1.0 - clamp01(sum(v ** 2 for v in drone.velocity) ** 0.5 / max(1.0, config.DEFAULT_UAV_SPEED * 2))
        energy = clamp01(drone.residual_energy / float(
            getattr(drone, 'initial_energy', config.INITIAL_ENERGY)
        ))
        return clamp01(0.35 * degree_fit + 0.25 * distance_score + 0.20 * mobility + 0.20 * energy)

    def _mobic_score(self, drone, neighbor_map):
        neighbors = neighbor_map.get(drone.identifier, [])
        if not neighbors:
            return 0.0
        relative = []
        for neighbor in neighbors:
            rv = sum((drone.velocity[idx] - neighbor.velocity[idx]) ** 2 for idx in range(3)) ** 0.5
            relative.append(rv)
        avg_relative = sum(relative) / len(relative)
        return 1.0 - clamp01(avg_relative / max(1.0, config.DEFAULT_UAV_SPEED * 2))

    def _mlsc_score(self, drone, neighbors, link_quality, density):
        energy = clamp01(drone.residual_energy / float(
            getattr(drone, 'initial_energy', config.INITIAL_ENERGY)
        ))
        if not neighbors:
            return clamp01(0.5 * energy + 0.5 * link_quality)
        avg_distance = sum(euclidean_distance_3d(drone.coords, neighbor.coords) for neighbor in neighbors) / len(neighbors)
        location_stability = 1.0 - clamp01(avg_distance / float(config.COMMUNICATION_RANGE))
        relative_mobility = []
        for neighbor in neighbors:
            relative_velocity = sum((drone.velocity[idx] - neighbor.velocity[idx]) ** 2 for idx in range(3)) ** 0.5
            relative_mobility.append(relative_velocity)
        mobility_stability = 1.0 - clamp01((sum(relative_mobility) / len(relative_mobility)) / max(1.0, config.DEFAULT_UAV_SPEED * 2))
        return clamp01(0.30 * energy + 0.25 * link_quality + 0.20 * density + 0.15 * location_stability + 0.10 * mobility_stability)

    def get_cluster_head(self, drone_id):
        if drone_id < 0 or drone_id >= len(self.simulator.drones):
            return None
        drone = self.simulator.drones[drone_id]
        return drone.cluster_head

    def _apply_rotation(self, candidate_heads, drones, neighbor_map, scores, previous_head_ids):
        if not candidate_heads:
            return candidate_heads

        retained = []
        for head_id in previous_head_ids:
            if head_id < 0 or head_id >= len(self.simulator.drones):
                continue
            previous_head = self.simulator.drones[head_id]
            local_candidates = [previous_head] + neighbor_map.get(previous_head.identifier, [])
            best_candidate = max(local_candidates, key=lambda drone: scores.get(drone.identifier, 0.0))
            if best_candidate.identifier == previous_head.identifier:
                retained.append(previous_head)
                continue
            persistence_key = (previous_head.identifier, best_candidate.identifier)
            persistence = self.better_candidate_persistence.get(persistence_key, 0) + 1
            self.better_candidate_persistence[persistence_key] = persistence
            rotation = (
                self.rotation_manager.should_rotate_original
                if config.MWMP_DECISION_MODE == 'original'
                else self.rotation_manager.should_rotate
            )
            use_candidate = rotation(previous_head, best_candidate, persistence)
            retained.append(best_candidate if use_candidate else previous_head)

        selected = []
        covered_ids = set()
        retained_ids = {head.identifier for head in retained}
        ordered_candidates = (
            sorted(
                retained,
                key=lambda drone: (
                    scores[drone.identifier],
                    drone.residual_energy,
                    -drone.identifier,
                ),
                reverse=True,
            ) +
            sorted(
                (
                    drone for drone in candidate_heads
                    if drone.identifier not in retained_ids
                ),
                key=lambda drone: (
                    scores[drone.identifier],
                    drone.residual_energy,
                    -drone.identifier,
                ),
                reverse=True,
            )
        )
        seen_ids = set()
        for candidate in ordered_candidates:
            if candidate.identifier in seen_ids:
                continue
            seen_ids.add(candidate.identifier)
            if candidate.identifier in covered_ids:
                continue
            selected.append(candidate)
            covered_ids.add(candidate.identifier)
            for neighbor in neighbor_map.get(candidate.identifier, []):
                covered_ids.add(neighbor.identifier)
        return selected
