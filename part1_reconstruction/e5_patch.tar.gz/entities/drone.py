import simpy
import numpy as np
import random
import math
import queue
from simulator.log import logger
from entities.packet import DataPacket
from routing.dsdv.dsdv import Dsdv
from mac.csma_ca import CsmaCa
from mobility.gauss_markov_3d import GaussMarkov3D
from mobility.random_walk_3d import RandomWalk3D
from mobility.random_waypoint_3d import RandomWaypoint3D
from mobility.replay_mobility_3d import ReplayMobility3D
from energy.energy_model import EnergyModel
from energy.energy_accounting import (
    CONTROL, DATA, PROPULSION, RX, TX, acknowledged_packet,
    communication_source, is_role_energy,
)
from allocation.channel_assignment import ChannelAssigner
from utils import config
from utils.util_function import has_intersection
from phy.large_scale_fading import sinr_calculator
from routing.mwmp_dca.mwmp_dca_routing import MwmpDcaRouting
from routing.torp_like.torp_like import TorpLikeRouting


class EventQueue(queue.Queue):
    def __init__(self, env):
        super().__init__()
        self.env = env
        self.item_event = env.event()

    def put(self, item, block=True, timeout=None):
        super().put(item, block=block, timeout=timeout)
        if not self.item_event.triggered:
            self.item_event.succeed()

    def wait_for_item(self):
        if not self.empty():
            return self.env.timeout(0)
        if self.item_event.triggered:
            self.item_event = self.env.event()
        return self.item_event


class Drone:
    """
    Drone implementation

    Drones in the simulation are served as routers. Each drone can be selected as a potential source node, destination
    and relaying node. Each drone needs to install the corresponding routing module, MAC module, mobility module and
    energy module, etc. At the same time, each drone also has its own queue and can only send one packet at a time, so
    subsequent data packets need queuing for queue resources, which is used to reflect the queue delay in the drone
    network

    Attributes:
        simulator: the simulation platform that contains everything
        env: simulation environment created by simpy
        identifier: used to uniquely represent a drone
        coords: the 3-D position of the drone
        start_coords: the initial position of drone
        direction: current direction of the drone
        pitch: current pitch of the drone
        speed: current speed of the drone
        velocity: velocity components in three directions
        direction_mean: mean direction
        pitch_mean: mean pitch
        velocity_mean: mean velocity
        inbox: a "Store" in simpy, used to receive the packets from other drones (calculate SINR)
        buffer: used to describe the queuing delay of sending packet
        transmitting_queue: when the next hop node receives the packet, it should first temporarily store the packet in
                    "transmitting_queue" instead of immediately yield "packet_coming" process. It can prevent the buffer
                    resource of the previous hop node from being occupied all the time
        waiting_list: for reactive routing protocol, if there is no available next hop, it will put the data packet into
                      "waiting_list". Once the routing information bound for a destination is obtained, drone will get
                      the data packets related to this destination, and put them into "transmitting_queue"
        mac_protocol: installed mac protocol (CSMA/CA, ALOHA, etc.)
        mac_process_dict: a dictionary, used to store the mac_process that is launched each time
        mac_process_finish: a dictionary, used to indicate the completion of the process
        mac_process_count: used to distinguish between different "mac_send" processes
        enable_blocking: describe whether the process of waiting for an ACK blocks the delivery of subsequent packets
                         1: stop-and-wait protocol; 0: sliding window (need further implemented)
        routing_protocol: routing protocol installed (GPSR, DSDV, etc.)
        mobility_model: mobility model installed (3-D Gauss-markov, 3-D random waypoint, etc.)
        energy_model: energy consumption model installed
        residual_energy: the residual energy of drone in Joule
        sleep: if the drone is in a "sleep" state, it cannot perform packet sending and receiving operations
        channel_assigner: used to assign sub-channel for transmitting

    Author: Zihao Zhou, eezihaozhou@gmail.com
    Created at: 2024/1/11
    Updated at: 2025/4/16
    """

    def __init__(self,
                 env,
                 node_id,
                 coords,
                 speed,
                 inbox,
                 simulator,
                 is_base_station=False,
                 initial_energy=None,
                 energy_class=None):
        self.simulator = simulator
        self.env = env
        self.identifier = node_id
        self.coords = coords
        self.start_coords = coords
        self.is_base_station = is_base_station

        self.rng_drone = random.Random(self.identifier + self.simulator.seed)

        self.direction = self.rng_drone.uniform(0, 2 * np.pi)
        self.pitch = self.rng_drone.uniform(-0.05, 0.05)
        self.speed = 0 if self.is_base_station else speed  # constant speed throughout the simulation
        self.velocity = [self.speed * math.cos(self.direction) * math.cos(self.pitch),
                         self.speed * math.sin(self.direction) * math.cos(self.pitch),
                         self.speed * math.sin(self.pitch)]

        self.direction_mean = self.direction
        self.pitch_mean = self.pitch
        self.velocity_mean = self.speed

        self.inbox = inbox

        self.buffer = simpy.Resource(env, capacity=1)
        self.max_queue_size = config.MAX_QUEUE_SIZE
        self.transmitting_queue = EventQueue(env)
        self.waiting_list = []
        self.trajectory_history = []
        self.trajectory_trace = []
        self.mobility_trace = []
        self.cluster_role = 'BS' if self.is_base_station else 'CM'
        self.cluster_id = self.identifier if self.is_base_station else None
        self.cluster_head = self if self.is_base_station else None
        self.cluster_members = []
        self.cluster_weight = 0.0
        self.avg_let = 0.0
        self.local_density = 0
        self.avg_link_quality = 0.0
        self.mobility_factor = 0.0
        self.poi_affinity = 0.0
        self.cluster_backoff_time = 0.0
        self.cluster_age = 0
        self.cluster_reselection_score = 0
        self.topology_score = 0.0
        self.graph_embedding = []

        self.mac_protocol = CsmaCa(self)
        self.mac_process_dict = dict()
        self.mac_process_finish = dict()
        self.mac_process_count = 0
        self.enable_blocking = 1  # enable "stop-and-wait" protocol

        if config.TRACE_ONLY:
            self.routing_protocol = None
        elif config.ROUTING_PROTOCOL == 'MWMP_DCA':
            self.routing_protocol = MwmpDcaRouting(self.simulator, self)
        elif config.ROUTING_PROTOCOL == 'TORP_LIKE':
            self.routing_protocol = TorpLikeRouting(self.simulator, self)
        else:
            self.routing_protocol = Dsdv(self.simulator, self)

        self.mobility_model = None if self.is_base_station else self._build_mobility_model()
        # self.motion_controller = VfMotionController(self)

        self.energy_model = EnergyModel(self)
        self.initial_energy = float(
            config.INITIAL_ENERGY if initial_energy is None else initial_energy
        )
        if self.initial_energy <= 0:
            raise ValueError('Initial energy must be positive')
        self.residual_energy = self.initial_energy
        self.energy_class = energy_class
        self.first_sleep_time_us = None
        self.battery_energy_consumed = 0.0
        self.propulsion_energy = 0.0
        self.communication_energy = 0.0
        self.data_energy = 0.0
        self.control_energy = 0.0
        self.tx_energy = 0.0
        self.rx_energy = 0.0
        self.relay_role_energy = 0.0
        self._rx_energy_attempts = set()
        self.sleep = False

        self.channel_assigner = ChannelAssigner(self.simulator, self)

        if not config.TRACE_ONLY:
            self.env.process(self.generate_data_packet())
            self.env.process(self.feed_packet())
            self.env.process(self.receive())
            self.env.process(self.track_state())

    def _build_mobility_model(self):
        if config.MOBILITY_TRACE_MODE == 'replay':
            return ReplayMobility3D(self)
        mobility_name = getattr(config, 'MOBILITY_MODEL', 'GaussMarkov3D')
        if mobility_name == 'RandomWaypoint3D':
            return RandomWaypoint3D(self)
        if mobility_name == 'RandomWalk3D':
            return RandomWalk3D(self)
        return GaussMarkov3D(self)

    def consume_energy(self, energy_consumption, *, source, direction=None, role_energy=False):
        if energy_consumption <= 0:
            return 0.0
        if source not in (PROPULSION, DATA, CONTROL):
            raise ValueError(f'Unsupported energy source: {source}')
        if not hasattr(self, 'initial_energy'):
            accounted = math.fsum((
                getattr(self, 'propulsion_energy', 0.0),
                getattr(self, 'communication_energy', 0.0),
            ))
            self.initial_energy = float(self.residual_energy) + accounted
        available_energy = max(0.0, self.residual_energy)
        consumed_energy = min(float(energy_consumption), available_energy)
        if consumed_energy <= 0:
            self.residual_energy = 0.0
            self.sleep = True
            return 0.0
        if source == PROPULSION:
            if direction is not None:
                raise ValueError('Propulsion energy cannot have a radio direction')
            self.propulsion_energy += consumed_energy
        else:
            if direction not in (TX, RX):
                raise ValueError('Communication energy requires tx or rx direction')
            if source == DATA:
                self.data_energy += consumed_energy
            else:
                self.control_energy += consumed_energy
            self.communication_energy = math.fsum((
                self.data_energy, self.control_energy
            ))
            if direction == TX:
                self.tx_energy += consumed_energy
            else:
                self.rx_energy += consumed_energy
            if role_energy:
                self.relay_role_energy += consumed_energy

        self.battery_energy_consumed = math.fsum((
            self.propulsion_energy, self.communication_energy
        ))
        self.residual_energy = max(
            0.0, self.initial_energy - self.battery_energy_consumed
        )
        sleep_threshold = (
            self.initial_energy * config.ENERGY_THRESHOLD / config.INITIAL_ENERGY
        )
        if self.residual_energy <= sleep_threshold:
            if not self.sleep and hasattr(self, 'env'):
                self.first_sleep_time_us = self.env.now
            self.sleep = True
        return consumed_energy

    def _charge_rx_attempt(self, packet, sender_id):
        if sender_id == self.identifier:
            return
        attempt_id = int(getattr(packet, '_phy_tx_attempt', 0))
        key = (int(packet.packet_id), attempt_id, self.identifier)
        if key in self._rx_energy_attempts:
            return
        self._rx_energy_attempts.add(key)
        energy = packet.packet_length / config.BIT_RATE * config.RECEIVING_POWER
        self.consume_energy(
            energy,
            source=communication_source(packet),
            direction=RX,
            role_energy=is_role_energy(packet, self),
        )

    def _record_ack_success(self, packet, sender_id):
        original = acknowledged_packet(packet)
        if original is None:
            return
        attempt_id = int(getattr(original, '_phy_tx_attempt', 0))
        self.simulator.link_reliability.record_success(
            self.identifier,
            sender_id,
            original.packet_id,
            attempt_id,
            self.env.now,
        )

    def generate_data_packet(self, traffic_pattern='Poisson'):
        """
        Generate one data packet, it should be noted that only when the current packet has been sent can the next
        packet be started. When the drone generates a data packet, it will first put it into the "transmitting_queue",
        the drone reads a data packet from the head of the queue every very short time through "feed_packet()" function.

        Parameters:
            traffic_pattern: characterize the time interval between generating data packets
        """

        while True:
            if self.is_base_station:
                break
            if not self.sleep:
                if traffic_pattern == 'Uniform':
                    # the drone generates a data packet every 0.5s with jitter
                    yield self.env.timeout(self.rng_drone.randint(500000, 505000))
                elif traffic_pattern == 'Poisson':
                    """
                    The process of generating data packets by nodes follows Poisson distribution, thus the generation 
                    interval of data packets follows exponential distribution
                    """

                    rate = max(1e-6, float(getattr(config, 'DATA_PACKET_RATE', 5)))
                    yield self.env.timeout(round(self.rng_drone.expovariate(rate) * 1e6))

                config.GL_ID_DATA_PACKET += 1  # data packet id

                # randomly choose a destination
                all_candidate_list = [i for i in range(config.NUMBER_OF_DRONES)]
                all_candidate_list.remove(self.identifier)
                dst_id = self.rng_drone.choice(all_candidate_list)
                destination = self.simulator.drones[dst_id]  # obtain the destination drone

                # data packet length
                if config.VARIABLE_PAYLOAD_LENGTH:
                    fluctuation = self.rng_drone.randint(-config.MAXIMUM_PAYLOAD_VARIATION, config.MAXIMUM_PAYLOAD_VARIATION)
                    payload_length = config.AVERAGE_PAYLOAD_LENGTH + fluctuation
                else:
                    payload_length = config.AVERAGE_PAYLOAD_LENGTH  # in bit, 1024 bytes

                data_packet_length = (config.IP_HEADER_LENGTH + config.MAC_HEADER_LENGTH +
                                      config.PHY_HEADER_LENGTH + payload_length)

                # channel assignment
                channel_id = self.channel_assigner.channel_assign()

                pkd = DataPacket(self,
                                 dst_drone=destination,
                                 creation_time=self.env.now,
                                 data_packet_id=config.GL_ID_DATA_PACKET,
                                 data_packet_length=data_packet_length,
                                 simulator=self.simulator,
                                 channel_id=channel_id)
                pkd.transmission_mode = 0  # the default transmission mode of data packet is "unicast" (0)

                self.simulator.metrics.datapacket_generated_num += 1
                diagnostics = self.simulator.metrics.packet_diagnostics
                if diagnostics is not None:
                    diagnostics.generated(pkd, self, self.env.now)

                logger.info('At time: %s (us) ++++ UAV: %s generates a data packet (id: %s, dst: %s)',
                            self.env.now, self.identifier, pkd.packet_id, destination.identifier)

                pkd.waiting_start_time = self.env.now

                if self.transmitting_queue.qsize() < self.max_queue_size:
                    self.transmitting_queue.put(pkd)
                    if diagnostics is not None:
                        diagnostics.enqueued(pkd, self, self.env.now)
                else:
                    # the drone has no more room for new packets
                    if diagnostics is not None:
                        diagnostics.dropped(pkd, self, self.env.now, 'QueueOverflow')
                    pass
            else:  # cannot generate packets if "my_drone" is in sleep state
                break

    def blocking(self):
        """
        The process of waiting for an ACK will block subsequent incoming data packets to simulate the
        "head-of-line blocking problem"
        """

        if self.enable_blocking:
            if not self.mac_protocol.wait_ack_process_finish:
                flag = False  # there is currently no waiting process for ACK
            else:
                # get the latest process status
                final_indicator = list(self.mac_protocol.wait_ack_process_finish.items())[-1]

                if final_indicator[1] == 0:
                    flag = True  # indicates that the drone is still waiting
                else:
                    flag = False  # there is currently no waiting process for ACK
        else:
            flag = False

        return flag

    def blocking_event(self):
        if not self.blocking():
            return None
        processes = self.mac_protocol.wait_ack_process_dict
        if not processes:
            return None
        process = list(processes.values())[-1]
        return process if not process.triggered else None

    def feed_packet(self):
        """
        It should be noted that this function is designed for those packets which need to compete for wireless channel

        Firstly, all packets received or generated will be put into the "transmitting_queue", every very short
        time, the drone will read the packet in the head of the "transmitting_queue". Then the drone will check
        if the packet is expired (exceed its maximum lifetime in the network), check the type of packet:
        1) data packet: check if the data packet exceeds its maximum re-transmission attempts. If the above inspection
           passes, routing protocol is executed to determine the next hop drone. If next hop is found, then this data
           packet is ready to transmit, otherwise, it will be put into the "waiting_queue".
        2) control packet: no need to determine next hop, so it will directly start waiting for buffer
        """

        while True:
            if not self.sleep:  # if drone still has enough energy to relay packets
                if self.transmitting_queue.empty():
                    yield self.transmitting_queue.wait_for_item()
                    continue
                yield self.env.timeout(10)

                blocking_event = self.blocking_event()
                if blocking_event is not None:
                    yield blocking_event
                    continue
                if not self.blocking():
                    if not self.transmitting_queue.empty():
                        packet = self.transmitting_queue.get()  # get the packet at the head of the queue
                        diagnostics = self.simulator.metrics.packet_diagnostics
                        if diagnostics is not None and isinstance(packet, DataPacket):
                            diagnostics.dequeued(packet, self, self.env.now)

                        if self.env.now < packet.creation_time + packet.deadline:  # this packet has not expired
                            if isinstance(packet, DataPacket):
                                if packet.number_retransmission_attempt[self.identifier] < config.MAX_RETRANSMISSION_ATTEMPT:
                                    # it should be noted that "final_packet" may be the data packet itself or a control
                                    # packet, depending on whether the routing protocol can find an appropriate next hop
                                    has_route, final_packet, enquire = self.routing_protocol.next_hop_selection(packet)

                                    if has_route:
                                        logger.info('At time: %s (us) ---- UAV: %s obtain the next hop: %s of data'
                                                    ' packet (id: %s)',
                                                    self.env.now, self.identifier, packet.next_hop_id, packet.packet_id)

                                        # in this case, the "final_packet" is actually the data packet
                                        yield self.env.process(self.packet_coming(final_packet))
                                    else:
                                        self.waiting_list.append(packet)
                                        if diagnostics is not None:
                                            diagnostics.route_unavailable(packet, self, self.env.now)
                                        self.remove_from_queue(packet)

                                        if enquire:
                                            # in this case, the "final_packet" is actually the control packet
                                            yield self.env.process(self.packet_coming(final_packet))

                                elif diagnostics is not None:
                                    diagnostics.dropped(packet, self, self.env.now, 'MaxRetry')

                            else:  # control packet but not ack
                                yield self.env.process(self.packet_coming(packet))
                        else:
                            if diagnostics is not None and isinstance(packet, DataPacket):
                                diagnostics.dropped(packet, self, self.env.now, 'PacketLifetime')
                            pass  # means dropping this data packet for expiration
            else:  # this drone runs out of energy
                break  # it is important to break the while loop

    def packet_coming(self, pkd):
        """
        When drone has a packet ready to transmit, yield it.

        The requirement of "ready" is:
            1) this packet is a control packet, or
            2) the valid next hop of this data packet is obtained

        Parameter:
            pkd: packet that waits to enter the buffer of drone
        """

        if not self.sleep:
            arrival_time = self.env.now
            diagnostics = self.simulator.metrics.packet_diagnostics
            if diagnostics is not None and isinstance(pkd, DataPacket):
                diagnostics.buffer_requested(pkd, self, arrival_time)
            logger.info('At time: %s (us) ---- Packet: %s starts waiting for UAV: %s buffer resource',
                        arrival_time, pkd.packet_id, self.identifier)

            with self.buffer.request() as request:
                yield request  # wait to enter to buffer

                logger.info('At time: %s (us) ---- Packet: %s has been added to the buffer of UAV: %s, '
                            'waiting time is: %s',
                            self.env.now, pkd.packet_id, self.identifier, self.env.now - arrival_time)
                if isinstance(pkd, DataPacket):
                    self.simulator.metrics.record_queue_wait(
                        self, self.env.now - arrival_time
                    )

                pkd.number_retransmission_attempt[self.identifier] += 1
                if diagnostics is not None and isinstance(pkd, DataPacket):
                    diagnostics.mac_started(
                        pkd, self, self.env.now,
                        pkd.number_retransmission_attempt[self.identifier],
                    )

                if pkd.number_retransmission_attempt[self.identifier] == 1:
                    pkd.time_transmitted_at_last_hop = self.env.now

                logger.info('At time: %s (us) ---- Re-transmission attempts of pkd: %s at UAV: %s is: %s',
                            self.env.now, pkd.packet_id, self.identifier,
                            pkd.number_retransmission_attempt[self.identifier])

                # every time the drone initiates a data packet transmission, "mac_process_count" will be increased by 1
                self.mac_process_count += 1

                key=''.join(['mac_send', str(self.identifier), '_', str(pkd.packet_id)])

                mac_process = self.env.process(self.mac_protocol.mac_send(pkd))
                self.mac_process_dict[key] = mac_process
                self.mac_process_finish[key] = 0

                yield mac_process
        else:
            pass

    def remove_from_queue(self, data_pkd):
        """
        After receiving the ack packet, drone should remove the data packet that has been acked from its queue

        Parameter:
            data_pkd: the acked data packet
        """
        temp_queue = queue.Queue()

        while not self.transmitting_queue.empty():
            pkd_entry = self.transmitting_queue.get()
            if pkd_entry != data_pkd:
                temp_queue.put(pkd_entry)

        while not temp_queue.empty():
            self.transmitting_queue.put(temp_queue.get())

    def receive(self):
        """
        Core receiving function of drone
        1. the drone checks its "inbox" to see if there is incoming packet every 5 units (in us) from the time it is
           instantiated to the end of the simulation
        2. update the "inbox" by deleting the inconsequential data packet
        3. then the drone will detect if it receives a (or multiple) complete data packet(s)
        4. SINR calculation
        """

        while True:
            if not self.sleep:
                # delete packets that have been processed and do not interfere with
                # the transmission and reception of all current packets
                self.update_inbox()

                flag, all_drones_send_to_me, time_span, potential_packet = self.trigger()

                if flag:
                    for packet, sender_channel in zip(potential_packet, all_drones_send_to_me):
                        self._charge_rx_attempt(packet, sender_channel[0])

                    # find the transmitters of all packets currently transmitted on the channel
                    transmitting_node_list = []
                    for drone in self.simulator.drones:
                        for item in drone.inbox:
                            packet = item[0]
                            insertion_time = item[1]
                            transmitter = item[2]
                            channel_used = item[4]
                            transmitting_time = packet.packet_length / config.BIT_RATE * 1e6
                            interval = [insertion_time, insertion_time + transmitting_time]

                            for interval2 in time_span:
                                if has_intersection(interval, interval2):
                                    transmitting_node_list.append([transmitter, channel_used])

                    # remove duplicates
                    transmitting_node_list = [list(x) for x in {tuple(i) for i in transmitting_node_list}]

                    sinr_list = sinr_calculator(self, all_drones_send_to_me, transmitting_node_list)

                    # receive the packet of the transmitting node corresponding to the maximum SINR
                    max_sinr = max(sinr_list)
                    if max_sinr >= config.SNR_THRESHOLD:
                        which_one = sinr_list.index(max_sinr)

                        pkd = potential_packet[which_one]

                        if pkd.get_current_ttl() < config.MAX_TTL:
                            sender = all_drones_send_to_me[which_one][0]

                            logger.info('At time: %s (us) ---- Packet %s from UAV: %s is received by UAV: %s, sinr is: %s',
                                        self.env.now, pkd.packet_id, sender, self.identifier, max_sinr)

                            self._record_ack_success(pkd, sender)
                            yield self.env.process(self.routing_protocol.packet_reception(pkd, sender))
                        else:
                            logger.info('At time: %s (us) ---- Packet %s is dropped due to exceeding max TTL',
                                        self.env.now, pkd.packet_id)
                            diagnostics = self.simulator.metrics.packet_diagnostics
                            if diagnostics is not None and isinstance(pkd, DataPacket):
                                diagnostics.dropped(pkd, self, self.env.now, 'TTL')
                    else:  # sinr is lower than threshold
                        pass

                channel = getattr(self.simulator, 'channel', None)
                if channel is None or not hasattr(channel, 'arrival_event'):
                    yield self.env.timeout(5)
                    continue
                completion_times = []
                for item in self.inbox:
                    if not item[3]:
                        packet = item[0]
                        completion = (
                            item[1] + packet.packet_length / config.BIT_RATE * 1e6
                        )
                        completion_times.append(math.ceil(completion / 5) * 5)
                arrival_event = channel.arrival_event(self.identifier)
                if completion_times:
                    delay = max(0, min(completion_times) - self.env.now)
                    if delay:
                        yield self.env.timeout(delay) | arrival_event
                    else:
                        yield self.env.timeout(0)
                else:
                    yield arrival_event
            else:
                break

    def track_state(self):
        while True:
            snapshot = {
                'time': self.env.now,
                'coords': tuple(self.coords),
                'velocity': tuple(self.velocity),
                'speed': float(self.speed),
                'residual_energy': float(self.residual_energy),
                'role': self.cluster_role,
                'cluster_id': self.cluster_id,
                'topology_score': float(getattr(self, 'topology_score', 0.0)),
            }
            self.trajectory_history.append(snapshot)
            self.trajectory_trace.append(snapshot.copy())
            if len(self.trajectory_history) > config.TRAJECTORY_HISTORY_SIZE:
                self.trajectory_history.pop(0)
            yield self.env.timeout(1 * 1e6)

    def update_inbox(self):
        """
        Clear the packets that have been processed.
                                           ↓ (current time step)
                              |==========|←- (current incoming packet p1)
                       |==========|←- (packet p2 that has been processed, but also can affect p1, so reserve it)
        |==========|←- (packet p3 that has been processed, no impact on p1, can be deleted)
        --------------------------------------------------------> time
        """

        if config.VARIABLE_PAYLOAD_LENGTH:
            max_transmission_time = ((config.AVERAGE_PAYLOAD_LENGTH + config.MAXIMUM_PAYLOAD_VARIATION)
                                     / config.BIT_RATE) * 1e6  # for a single data packet
        else:
            max_transmission_time = (config.AVERAGE_PAYLOAD_LENGTH / config.BIT_RATE) * 1e6  # for a single data packet

        for item in self.inbox:
            insertion_time = item[1]  # the moment that this packet begins to be sent to the channel
            received = item[3]  # used to indicate if this packet has been processed (1: processed, 0: unprocessed)
            if insertion_time + 2 * max_transmission_time < self.env.now:  # no impact on the current packet
                if received:
                    self.inbox.remove(item)

    def trigger(self):
        """
        Detects whether the drone has received a complete data packet

        Returns:
            flag: bool variable, "1" means a complete data packet has been received by this drone and vice versa
            all_drones_send_to_me: a nested list, whose element is a list including sender id and the channel id
            time_span: a nested list, whose element is a list including the time when the packet is transmitted and the
                time when the packet reached
            potential_packet: a list, including all the instances of the received complete data packet
        """

        flag = 0  # used to indicate if I receive a complete packet
        all_drones_send_to_me = []
        time_span = []
        potential_packet = []

        for item in self.inbox:
            packet = item[0]  # not sure yet whether it has been completely transmitted
            insertion_time = item[1]  # transmission start time
            transmitter = item[2]
            processed = item[3]  # indicate if this packet has been processed
            channel_used = item[4]  # indicate the sub-channel that used to transmit this packet

            transmitting_time = packet.packet_length / config.BIT_RATE * 1e6  # expected transmission time

            if not processed:  # this packet has not been processed yet
                if self.env.now >= insertion_time + transmitting_time:  # it has been transmitted completely
                    flag = 1
                    all_drones_send_to_me.append([transmitter, channel_used])
                    time_span.append([insertion_time, insertion_time + transmitting_time])
                    potential_packet.append(packet)
                    item[3] = 1
                else:
                    pass
            else:
                pass

        return flag, all_drones_send_to_me, time_span, potential_packet
